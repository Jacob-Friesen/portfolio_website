package tests.integration;

import junit.framework.TestCase;
import nutri.application.Services;
import nutri.logic.SuggestionHandler;
import nutri.objects.FoodItem;
import nutri.objects.FoodItemList;
import nutri.persistence.DataAccessStub;
import nutri.persistence.IDataAccess;

/**
 * Tests all possible interactions between Logic to Persistence,
 * involving getting similar foods by category or <code>NutriFact</code>s.
 * <br/><br/>
 * Note: does not use Suggestion handler as its method to get suggestions
 * uses both suggestion algorithms. I want to test both in depth so I did
 * a direct connection to the persistence layer. getSuggestions is tested
 * in get the logic test for <code>suggestionHandler</code>
 */
public class GetSimilarIntegration extends TestCase 
{	
	/**
	 * Tests getting a similar category.
	 */
	public void testSimilarCategory()
	{
		IDataAccess dataAccess = new DataAccessStub();
		
		System.out.println("\nStarting category suggestion integration logic test (REAL)");
		Services.createDataAccess("FOOD_TEST2");
		similarCategoryTest();
		Services.closeDataAccess();
		System.out.println("Ending category suggestion integration logic test (REAL)");
		
		System.out.println("\nStarting nutritional suggestion integration logic test (STUB)");
		Services.changeDataAccess(dataAccess, "STUBDB");
		similarCategoryTest();
		Services.closeDataAccess();
		System.out.println("Ending nutritional suggestion integration logic test (STUB)");
	}
	
	private void similarCategoryTest()
	{
		IDataAccess dataAccess = Services.getDataAccess();
		FoodItemList list;
		FoodItem food;
		
		//test regular food item
		list = dataAccess.getAllFood();
		food = list.get(0);
		list = dataAccess.getSimilarFoodsByCategory(food);
		assertTrue(list.size() > 0);
		//should not return food already selected
		assertTrue(list.getFoodItem(food.getName()) == null);
		
		//test non existent food item
		food = new FoodItem("non-existent", 0, "g");
		list = dataAccess.getSimilarFoodsByCategory(food);
		assertTrue(list.size() == 0);
		assertTrue(list.getFoodItem(food.getName()) == null);
		
		//test null food item
		food = null;
		list = dataAccess.getSimilarFoodsByCategory(food);
		assertTrue(list == null);
	}
	
	/**
	 * Tests getting a similar nutrifact.
	 */
	public void testSimilarNutrifact()
	{
		IDataAccess dataAccess = new DataAccessStub();
		
		System.out.println("\nStarting nutrifact suggestion integration logic test (REAL)");
		Services.createDataAccess("FOOD_TEST2");
		similarNutriTest();
		Services.closeDataAccess();
		System.out.println("Ending nutrifact suggestion integration logic test (REAL)");
		
		System.out.println("\nStarting nutrifact suggestion integration logic test (STUB)");
		Services.changeDataAccess(dataAccess, "STUBDB");
		similarNutriTest();
		Services.closeDataAccess();
		System.out.println("Ending nutrifact suggestion integration logic test (STUB)");
	}
	
	private void similarNutriTest()
	{
		IDataAccess dataAccess = Services.getDataAccess();
		FoodItemList list;
		FoodItem food;
		
		//test regular food item
		list = dataAccess.getAllFood();
		food = list.get(0);
		list = dataAccess.getSimilarFoodsByNutrifacts(food, SuggestionHandler.TOLERANCE);
		assertTrue(list.size() + "", list.size() > 0);
		//should not return food already selected
		assertTrue(list.getFoodItem(food.getName()) == null);
		
		//test non existent food item
		food = new FoodItem("non-existent", 0, "g");
		list = dataAccess.getSimilarFoodsByNutrifacts(food, SuggestionHandler.TOLERANCE);
		assertTrue(list.size() == 0);
		assertTrue(list.getFoodItem(food.getName()) == null);
		
		//test null food item
		food = null;
		list = dataAccess.getSimilarFoodsByNutrifacts(food, SuggestionHandler.TOLERANCE);
		assertTrue(list == null);
	}
}
