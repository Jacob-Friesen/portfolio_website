package tests.integration;

import java.util.ArrayList;

import junit.framework.TestCase;
import nutri.application.Services;
import nutri.logic.IngredientFilterHandler;
import nutri.objects.IngredientFilters;
import nutri.persistence.DataAccessStub;
import nutri.persistence.IDataAccess;

/**
 * Tests all possible interactions between Logic to Persistence,
 * involving ingredients filters. Including getting ingredients
 */
public class IngredientFiltersIntegration extends TestCase 
{	
	/**
	 * Tests adding and getting ingredient filters and getting
	 * all ingredients.
	 */
	public void testIngredients()
	{
		IDataAccess dataAccess = new DataAccessStub();
		
		System.out.println("\nStarting ingredient filters integration logic test (REAL)");
		Services.createDataAccess("FOOD_TEST2");
		ingredientTest();
		Services.closeDataAccess();
		System.out.println("Ending ingredient filters integration logic test (REAL)");
		
		System.out.println("\nStarting ingredient filters integration logic test (STUB)");
		Services.changeDataAccess(dataAccess, "STUBDB");
		ingredientTest();
		Services.closeDataAccess();
		System.out.println("Ending ingredient filters integration logic test (STUB)");
	}
	
	
	private void ingredientTest()
	{
		IngredientFilterHandler ingredientFiltersHdler = new IngredientFilterHandler(Services.getDataAccess());
		IngredientFilters ingredientFilters;
		IngredientFilters tempFilters;
		ArrayList<String> ingredients;
		int ingredientNum = -1;
		String newIngredient = "xxxxxxxxxxxx";
		
		//check if ingredients are loaded correct
		ingredients = ingredientFiltersHdler.getAllIngredients();
		assertFalse(ingredients.isEmpty());
		
		ingredientFilters = ingredientFiltersHdler.getAllIngredientFilters();
		assertFalse(ingredientFilters.getAllIngredients().isEmpty());
		
		//test insertion of a duplicate ingredient filter
		ingredientNum = ingredientFiltersHdler.getAllIngredientFilters().size();
		ingredientFiltersHdler.addIngredient(ingredientFilters.get(0));
		tempFilters = ingredientFiltersHdler.getAllIngredientFilters();
		assertTrue(tempFilters.size() > 0);
		assertTrue(tempFilters.size() == ingredientNum);
		assertTrue(tempFilters.contains(ingredientFilters.get(0)));
		
		//test insertion and of a regular ingredient filter
		ingredientNum = ingredientFiltersHdler.getAllIngredientFilters().size();
		ingredientFiltersHdler.addIngredient(newIngredient);
		tempFilters = ingredientFiltersHdler.getAllIngredientFilters();
		assertTrue(tempFilters.size() == ingredientNum + 1);
		assertTrue(tempFilters.contains(newIngredient));
		
		//test deletion and of a regular ingredient filter
		ingredientFiltersHdler.deleteIngredient(newIngredient);
		tempFilters = ingredientFiltersHdler.getAllIngredientFilters();
		assertTrue(tempFilters.size() == ingredientNum);
		assertFalse(tempFilters.contains(newIngredient));
		
		//test insertion of a null ingredient filter
		ingredientNum = ingredientFiltersHdler.getAllIngredientFilters().size();
		ingredientFiltersHdler.addIngredient(null);
		tempFilters = ingredientFiltersHdler.getAllIngredientFilters();
		assertTrue(tempFilters.size() == ingredientNum);
		assertFalse(tempFilters.contains(null));
		
		//test deletion of a null ingredient filter
		ingredientFiltersHdler.deleteIngredient(null);
		tempFilters = ingredientFiltersHdler.getAllIngredientFilters();
		assertTrue(tempFilters.size() == ingredientNum);
		assertFalse(tempFilters.contains(null));
	}
}
