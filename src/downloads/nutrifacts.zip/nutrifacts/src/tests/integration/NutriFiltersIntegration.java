package tests.integration;

import junit.framework.TestCase;
import nutri.application.Services;
import nutri.enums.NutriType;
import nutri.enums.OperatorType;
import nutri.enums.UnitType;
import nutri.logic.NutriFilterHandler;
import nutri.objects.NutriFilter;
import nutri.objects.NutriFilterList;
import nutri.persistence.DataAccessStub;
import nutri.persistence.IDataAccess;

/**
 * Tests all possible interactions between Logic to Persistence,
 * involving nutritional filters.
 */
public class NutriFiltersIntegration extends TestCase 
{	
	/**
	 * Tests adding and deleting of filters.
	 */
	public void testAddDeleteFilters()
	{
		IDataAccess dataAccess = new DataAccessStub();
		
		System.out.println("\nStarting nutritional filters add/delete integration logic test (REAL)");
		Services.createDataAccess("FOOD_TEST2");
		addDeleteFiltersTest();
		Services.closeDataAccess();
		System.out.println("Ending nutritional filters add/delete integration logic test (REAL)");
		
		System.out.println("\nStarting nutritional filters add/delete integration logic test (STUB)");
		Services.changeDataAccess(dataAccess, "STUBDB");
		addDeleteFiltersTest();
		Services.closeDataAccess();
		System.out.println("Ending nutritional filters add/delete integration logic test (STUB)");
	}
	
	private void addDeleteFiltersTest()
	{
		NutriFilterHandler nutriFilterHdler = new NutriFilterHandler(Services.getDataAccess());
		NutriFilterList nutriFilterList;
		NutriFilterList tempFilters;
		NutriFilter filter;
		int filterNum = -1;
		
		//test if filters are loaded properly
		nutriFilterList = nutriFilterHdler.getAllFilters();
		filterNum = nutriFilterList.size();
		assertTrue(filterNum > 0);
		
		//test insertion of a duplicate filter
		nutriFilterHdler.addFilter(nutriFilterList.getFilter(0));
		tempFilters = nutriFilterHdler.getAllFilters();
		assertTrue(tempFilters.size() == filterNum);
		assertTrue("duplicate value not found", findNutriValue(tempFilters, nutriFilterList.getFilter(0)));
		
		//test insertion of a regular filter
		filterNum = nutriFilterList.size();
		filter = new NutriFilter(NutriType.CARBS,OperatorType.LESS,233.0,UnitType.MILLIGRAMS);
		nutriFilterHdler.addFilter(filter);
		tempFilters = nutriFilterHdler.getAllFilters();
		assertTrue(tempFilters.size() == filterNum + 1);
		assertTrue("inserted value not found", findNutriValue(tempFilters, filter));
		
		//test deletion of a regular filter
		nutriFilterHdler.deleteFilter(filter);
		tempFilters = nutriFilterHdler.getAllFilters();
		assertTrue(tempFilters.size() == filterNum);
		assertFalse("deleted value was found", findNutriValue(tempFilters, filter));
		
		//test insertion of a null ingredient filter
		filterNum = nutriFilterList.size();
		nutriFilterHdler.addFilter(null);
		tempFilters = nutriFilterHdler.getAllFilters();
		assertTrue(tempFilters.size() == filterNum);
		assertFalse("null value was found", findNutriValue(tempFilters, null));
		
		//test deletion of a null ingredient filter
		nutriFilterHdler.deleteFilter(null);
		tempFilters = nutriFilterHdler.getAllFilters();
		assertTrue(tempFilters.size() == filterNum);
		assertFalse("null value was found", findNutriValue(tempFilters, null));
	}
	
	/**
	 * Tests updating of filters.
	 */
	public void testUpdateFilters()
	{
		IDataAccess dataAccess = new DataAccessStub();
		
		System.out.println("\nStarting nutritional filters update integration logic test (REAL)");
		Services.createDataAccess("FOOD_TEST2");
		updateFiltersTest();
		Services.closeDataAccess();
		System.out.println("Ending nutritional filters update integration logic test (REAL)");
		
		System.out.println("\nStarting nutritional filters update integration logic test (STUB)");
		Services.changeDataAccess(dataAccess, "STUBDB");
		updateFiltersTest();
		Services.closeDataAccess();
		System.out.println("Ending nutritional filters update integration logic test (STUB)");
	}
	
	private void updateFiltersTest()
	{
		NutriFilterHandler nutriFilterHdler = new NutriFilterHandler(Services.getDataAccess());
		NutriFilterList nutriFilterList;
		NutriFilterList tempFilters;
		NutriFilter filter;
		NutriFilter swapFilter;
		int filterNum = -1;
		
		//test if filters are loaded properly
		nutriFilterList = nutriFilterHdler.getAllFilters();
		filterNum = nutriFilterList.size();//this should always stay constant
		
		//test update of a duplicate filter
		nutriFilterHdler.updateFilter(nutriFilterList.getFilter(0),nutriFilterList.getFilter(0));
		tempFilters = nutriFilterHdler.getAllFilters();
		assertTrue(tempFilters.size() == filterNum);
		assertTrue("duplicate value not found", findNutriValue(tempFilters, nutriFilterList.getFilter(0)));
		
		//test swapping old and new value around
		swapFilter = nutriFilterList.getFilter(0);
		filter = new NutriFilter(NutriType.CARBS,OperatorType.LESS,233.0,UnitType.MILLIGRAMS);
		nutriFilterHdler.updateFilter(filter,swapFilter);
		tempFilters = nutriFilterHdler.getAllFilters();
		assertTrue(tempFilters.size() == filterNum);
		assertFalse("updated value not found", findNutriValue(tempFilters, filter));
		assertTrue("overrided value was found", findNutriValue(tempFilters, swapFilter));
		
		//test updating a normal value
		swapFilter = nutriFilterList.getFilter(0);
		filter = new NutriFilter(NutriType.CARBS,OperatorType.LESS,233.0,UnitType.MILLIGRAMS);
		nutriFilterHdler.updateFilter(swapFilter, filter);
		tempFilters = nutriFilterHdler.getAllFilters();
		assertTrue(tempFilters.size() == filterNum);
		assertTrue("updated value not found", findNutriValue(tempFilters, filter));
		assertFalse("overrided value was found", findNutriValue(tempFilters, swapFilter));
		
		//test updating to a null value
		swapFilter = nutriFilterHdler.getAllFilters().getFilter(0);
		filter = new NutriFilter(NutriType.CARBS,OperatorType.LESS,233.0,UnitType.MILLIGRAMS);
		nutriFilterHdler.updateFilter(swapFilter, null);
		tempFilters = nutriFilterHdler.getAllFilters();
		assertTrue(tempFilters.size() == filterNum);
		assertTrue("value was not found", findNutriValue(tempFilters, swapFilter));
		
		//test updating from a null value
		filter = new NutriFilter(NutriType.CARBS,OperatorType.LESS,233.0,UnitType.MILLIGRAMS);
		nutriFilterHdler.updateFilter(null, swapFilter);
		tempFilters = nutriFilterHdler.getAllFilters();
		assertTrue(tempFilters.size() == filterNum);
		assertTrue("value was found found", findNutriValue(tempFilters, swapFilter));
	}
	
	/**
	 * finds a given value in a <code>nutriFilterList</code>
	 */
	private boolean findNutriValue(NutriFilterList tempFilters, NutriFilter toFind)
	{
		boolean foundValue = false;
		
		if(toFind != null)
		{
			for (NutriFilter filter : tempFilters.getAllFilters())
			{
				if(filter.toString().equals(toFind.toString()))
				{
					foundValue = true;
					break;
				}
			}
		}
		
		return foundValue;
	}
}
