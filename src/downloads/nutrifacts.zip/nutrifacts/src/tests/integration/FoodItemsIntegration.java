package tests.integration;

import java.util.ArrayList;

import junit.framework.TestCase;
import nutri.application.Services;
import nutri.logic.FoodHandler;
import nutri.objects.FoodItem;
import nutri.objects.FoodItemList;
import nutri.persistence.DataAccessStub;
import nutri.persistence.IDataAccess;

/**
 * Tests all possible interactions between Logic to Persistence,
 * involving <code>FoodItemList</code>
 */
public class FoodItemsIntegration extends TestCase 
{	
	/**
	 * Test ratings on food
	 */
	public void testFoodRating()
	{
		IDataAccess dataAccess = new DataAccessStub();
		
		System.out.println("\nStarting food rating integration logic test (REAL)");
		Services.createDataAccess("FOOD_TEST2");
		foodRatingTest();
		Services.closeDataAccess();
		System.out.println("Ending food rating integration logic test (REAL)");
		
		System.out.println("\nStarting food rating integration logic test (STUB)");
		Services.changeDataAccess(dataAccess, "STUBDB");
		foodRatingTest();
		Services.closeDataAccess();
		System.out.println("Ending food rating integration logic test (STUB)");
	}
	
	public void foodRatingTest()
	{
		ArrayList<FoodItem> foodItems = new ArrayList<FoodItem>();
		FoodHandler foodHandler = new FoodHandler(Services.getDataAccess());
		
		foodHandler.loadData();
		foodItems = foodHandler.getAllFoodItems();
		
		//test a few regular ratings
		foodHandler.setFoodRating(foodItems.get(0), 3);
		assertTrue(foodHandler.getFoodItem(foodItems.get(0).getName()).getRating() == 3);
		foodHandler.setFoodRating(foodItems.get(1), 5);
		assertTrue(foodHandler.getFoodItem(foodItems.get(1).getName()).getRating() == 5);
		foodHandler.setFoodRating(foodItems.get(2), 0);
		assertTrue(foodHandler.getFoodItem(foodItems.get(2).getName()).getRating() == 0);
		
		//test irregular ratings
		foodHandler.setFoodRating(foodItems.get(0), Integer.MIN_VALUE);
		assertTrue(foodHandler.getFoodItem(foodItems.get(0).getName()).getRating() == -1);
		foodHandler.setFoodRating(foodItems.get(0), Integer.MAX_VALUE);
		assertTrue(foodHandler.getFoodItem(foodItems.get(0).getName()).getRating() == 5);
	}
	
	
	/**
	 * Test getting all food items and searching for food items
	 */
	public void testFoodItems()
	{
		IDataAccess dataAccess = new DataAccessStub();
		
		System.out.println("\nStarting food item list integration logic test (REAL)");
		Services.createDataAccess("FOOD_TEST2");
		foodItemTest();
		Services.closeDataAccess();
		System.out.println("Ending food item list integration logic test (REAL)");
		
		System.out.println("\nStarting food item list integration logic test (STUB)");
		Services.changeDataAccess(dataAccess, "STUBDB");
		foodItemTest();
		Services.closeDataAccess();
		System.out.println("Ending food item list integration logic test (STUB)");
	}
	
	private void foodItemTest()
	{
		FoodHandler foodHandler = new FoodHandler(Services.getDataAccess());
		ArrayList<FoodItem> foodItems = new ArrayList<FoodItem>();
		FoodItemList tempList;
		String noEntry = "-------";
		String noEntry2 = "xxxxxxxxxxxxxxxx";
		int count = 0;
		
		//test getting of initial items
		assertTrue(foodHandler.getAllFoodItems().isEmpty());
		foodHandler.loadData();
		foodItems = foodHandler.getAllFoodItems();
		assertFalse(foodItems.isEmpty());
		
		//test that a few values are found using searchFoodItems
		tempList = foodHandler.searchFoodItems(foodItems.get(0).getName());
		assertTrue(tempList.get(0).getName().equals(foodItems.get(0).getName()));
		tempList = foodHandler.searchFoodItems(foodItems.get(1).getName());
		assertTrue(tempList.get(0).getName().equals(foodItems.get(1).getName()));
		tempList = foodHandler.searchFoodItems(foodItems.get(2).getName());
		assertTrue(tempList.get(0).getName().equals(foodItems.get(2).getName()));
		
		//test value that has no entry
		tempList = foodHandler.searchFoodItems(noEntry);
		assertTrue(tempList.size() == 0);
		
		//test value that should return null
		tempList = foodHandler.searchFoodItems(noEntry2);
		assertTrue(tempList.size() == 0);
		
		//test values that will return all foodItems 
		tempList = foodHandler.searchFoodItems(null);
		count = 0;
		for (FoodItem item: foodItems)
		{
			assertTrue(item.getName().equals(tempList.get(count).getName()));
			count++;
		}
		tempList = foodHandler.searchFoodItems("");
		count = 0;
		for (FoodItem item: foodItems)
		{
			assertTrue(item.getName().equals(tempList.get(count).getName()));
			count++;
		}
	}
}
