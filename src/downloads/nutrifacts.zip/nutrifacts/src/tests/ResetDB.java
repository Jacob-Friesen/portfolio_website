package tests;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import junit.framework.TestCase;

/**
 * Resets the test databases to their original states
 */
public class ResetDB extends TestCase 
{	
	/**
	 * All this does is resets all the test databases, MUST
	 * have test in front to run.
	 */
	public void testResetDB()
	{
		String lineFromBat;
		
		//get 3 directories up
		String projectLoc = ResetDB.class.getResource("../").getPath();
		projectLoc = projectLoc.replace("bin/","");
		projectLoc = projectLoc.replace("/","\\").substring(1);//also remove leading /
		projectLoc += "database\\RESTORE_TEST_DBS.bat";
		projectLoc = projectLoc.replace("%20"," ");//convert spaces
		System.out.println(projectLoc);
		
		//execute the .bat file
		System.out.println("Restoring test databases...");
		try {
			Process process = Runtime.getRuntime().exec(projectLoc);
			
			BufferedReader stdInput = new BufferedReader(new 
            InputStreamReader(process.getInputStream()));

            // read the output from the command
            System.out.println("File output:\n");
            lineFromBat = stdInput.readLine();
            while (lineFromBat != null)
            {
                System.out.println(lineFromBat);
                lineFromBat = stdInput.readLine();
            }
            
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Done restoring test databases...");
	}
}
