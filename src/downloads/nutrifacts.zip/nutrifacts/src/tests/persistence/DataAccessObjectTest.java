package tests.persistence;

import java.util.ArrayList;
import java.util.Random;

import junit.framework.TestCase;

import nutri.persistence.DataAccessObject;
import nutri.enums.*;
import nutri.objects.*;

public class DataAccessObjectTest extends TestCase
{
	public static String DB_NAME = "FOOD_TEST";
	private static final int NUM_TEST_VALUES = 50;
	private static final long seed = 1;
	private static Random random = new Random(seed);
	private static DataAccessObject testee = new DataAccessObject();
	
	
	public static void testFood()
	{	
		System.out.println("\nStarting testFood");
		
		testee.open(DB_NAME);
		ArrayList<FoodItem> allFood = new ArrayList<FoodItem>();
		
		//add values
		for(int i = 0; i< NUM_TEST_VALUES; i++)
		{
			FoodItem temp = new FoodItem("Food" + i, random.nextInt(10)+1, "units");
			temp.addFact(NutriType.CALORIES, random.nextInt(10)+1);
			temp.addFact(NutriType.FAT, random.nextInt(10)+1);
			temp.addFact(NutriType.SATURATED_FAT, random.nextInt(10)+1);
			temp.addFact(NutriType.TRANS_FAT,random.nextInt(10)+1);
			temp.addFact(NutriType.CHOLESTEROL,random.nextInt(10)+1);
			temp.addFact(NutriType.SODIUM,random.nextInt(10)+1);
			temp.addFact(NutriType.CARBS,random.nextInt(10)+1);
			temp.addFact(NutriType.FIBRE,random.nextInt(10)+1);
			temp.addFact(NutriType.SUGAR,random.nextInt(10)+1);
			temp.addFact(NutriType.PROTEIN,random.nextInt(10)+1);
			temp.addFact(NutriType.VITAMIN_A, random.nextInt(10)+1);
			temp.addFact(NutriType.VITAMIN_C,random.nextInt(10)+1);
			temp.addFact(NutriType.CALCIUM,random.nextInt(10)+1);
			temp.addFact(NutriType.IRON,random.nextInt(10)+1);
			
			temp.setPortion((random.nextDouble()+1)*10, "box", "bo�te");
			temp.addIngredients(TestHelper.getRandomIngredients());
			
			testee.addFood(temp);
			allFood.add(temp);
		}
		
		//retrieve food
		FoodItemList food = testee.getAllFood();
		assertNotNull(food);
		
		FoodItemList suggestions = testee.getSimilarFoodsByCategory(food.getFoodItem("Food1"));
		assertNotNull(suggestions);
		assertTrue(suggestions.size() == 49);
		
		
		suggestions = testee.getSimilarFoodsByNutrifacts(food.getFoodItem("Food1"), 100);
		assertNotNull(suggestions);
		assertTrue(suggestions.size() == 0);
		
		//retrieve ingredients
		ArrayList<String> allIngredients = testee.getAllIngredients();
		assertNotNull(allIngredients);
				
		//ensure food (and ingredients) was properly retrieved
		for(int i = 0; i< NUM_TEST_VALUES; i++)
		{
			FoodItem temp = food.getFoodItem("Food" + i);
			FoodItem orig = allFood.get(i);
			
			assertNotNull(food.getFoodItem("Food" + i));

			assertTrue(Double.compare(temp.getFact(NutriType.CALCIUM).amount(), temp.getFact(NutriType.CALCIUM).amount()) == 0);
			assertTrue(Double.compare(temp.getFact(NutriType.CALORIES).amount(), temp.getFact(NutriType.CALORIES).amount()) == 0);
			assertTrue(Double.compare(temp.getFact(NutriType.CHOLESTEROL).amount(), temp.getFact(NutriType.CHOLESTEROL).amount()) == 0);
			assertTrue(Double.compare(temp.getFact(NutriType.FAT).amount(), temp.getFact(NutriType.FAT).amount()) == 0);
			assertTrue(Double.compare(temp.getFact(NutriType.FIBRE).amount(), temp.getFact(NutriType.FIBRE).amount()) == 0);
			assertTrue(Double.compare(temp.getFact(NutriType.IRON).amount(), temp.getFact(NutriType.IRON).amount()) == 0);
			assertTrue(Double.compare(temp.getFact(NutriType.PROTEIN).amount(), temp.getFact(NutriType.PROTEIN).amount()) == 0);
			assertTrue(Double.compare(temp.getFact(NutriType.SATURATED_FAT).amount(), temp.getFact(NutriType.SATURATED_FAT).amount()) == 0);
			assertTrue(Double.compare(temp.getFact(NutriType.SODIUM).amount(), temp.getFact(NutriType.SODIUM).amount()) == 0);
			assertTrue(Double.compare(temp.getFact(NutriType.SUGAR).amount(), temp.getFact(NutriType.SUGAR).amount()) == 0);
			assertTrue(Double.compare(temp.getFact(NutriType.TRANS_FAT).amount(), temp.getFact(NutriType.TRANS_FAT).amount()) == 0);
			assertTrue(Double.compare(temp.getFact(NutriType.VITAMIN_A).amount(), temp.getFact(NutriType.VITAMIN_A).amount()) == 0);
			assertTrue(Double.compare(temp.getFact(NutriType.VITAMIN_C).amount(), temp.getFact(NutriType.VITAMIN_C).amount()) == 0);
			assertTrue(orig.getServingUnits().equals(temp.getServingUnits()));
			assertTrue(Double.compare(temp.getServingSize(), orig.getServingSize()) == 0);
			assertTrue(Double.compare(temp.getPortionSize(), orig.getPortionSize()) == 0);
			assertTrue(temp.getPortionTypeEn().equals(orig.getPortionTypeEn()));
			assertTrue(temp.getPortionTypeFr().equals(orig.getPortionTypeFr()));		
			
						
			
			if(temp != null)
			{
				ArrayList<String> ingredients = temp.getIngredientsList();
				
				for(String ingredient : ingredients)
				{
					assertFalse(allIngredients.indexOf(ingredient) == -1);
				}
			}
			
		}
		
		//delete food
		for(int i = 0; i< NUM_TEST_VALUES; i++)
		{	
			testee.deleteFood("Food" + i);			
		}

		food = testee.getAllFood();
		
		//ensure food was properly deleted
		for(int i = 0; i< NUM_TEST_VALUES; i++)
		{
			assertNull(food.getFoodItem("Food" + i));
		}

		testee.close();
		
		System.out.println("Finished testFood");
	}

	
	public static void testFilters()
	{
		System.out.println("\nStarting testFilters");
		
		ArrayList<NutriFilter> filters = new ArrayList<NutriFilter>();
		ArrayList<NutriFilter> updated = new ArrayList<NutriFilter>();
		ArrayList<String> ingredientFilters;
		NutriFilterList dbFilters = new NutriFilterList();
		
		NutriType[] nutritypes = {NutriType.VITAMIN_C, 
				NutriType.VITAMIN_A, 
				NutriType.TRANS_FAT, 
				NutriType.SUGAR, 
				NutriType.SODIUM, 
				NutriType.SATURATED_FAT, 
				NutriType.PROTEIN, 
				NutriType.IRON, 
				NutriType.FIBRE, 
				NutriType.FAT, 
				NutriType.CHOLESTEROL, 
				NutriType.CARBS, 
				NutriType.CALORIES,
				NutriType.CALCIUM};
		
		OperatorType[] operators = {OperatorType.GREATER, OperatorType.GREATER_OR_EQUAL, OperatorType.LESS, OperatorType.LESS_OR_EQUAL};
		
		testee.open(DB_NAME);
		dbFilters = testee.getAllFilters();
		
		for(int i = 0; i < NUM_TEST_VALUES; i++)
		{
			NutriFilter temp = new NutriFilter(nutritypes[random.nextInt(nutritypes.length)], operators[random.nextInt(operators.length)], random.nextInt(10)+1, UnitType.GRAMS);
			
			testee.addFilter(temp);
			filters.add(temp);	
			
		}
		
		dbFilters = testee.getAllFilters();
		
		for(int i = 0; i < NUM_TEST_VALUES; i++)
		{
			NutriFilter temp = dbFilters.getFilter(i);
			NutriFilter orig = filters.get(i);
			
			assertTrue(temp.getNutriType().equals(orig.getNutriType()));
			assertTrue(temp.getOperator().equals(orig.getOperator()));
			assertTrue(Double.compare(temp.getValue(), orig.getValue()) == 0);
			assertTrue(temp.getUnit().equals(orig.getUnit()));
		}
		
		
		for(int i = 0; i < NUM_TEST_VALUES; i++)
		{
			NutriFilter temp = new NutriFilter(nutritypes[random.nextInt(nutritypes.length)], operators[random.nextInt(operators.length)], random.nextInt(10)+1, UnitType.GRAMS);
			NutriFilter orig = filters.get(i);
			
			testee.updateFilter(orig, temp);
			
			updated.add(temp);	
		}
		
		dbFilters = testee.getAllFilters();
		filters = updated;

		for(int i = 0; i < NUM_TEST_VALUES; i++)
		{
			NutriFilter temp = dbFilters.getFilter(i);
			NutriFilter orig = filters.get(i);
			
			assertTrue(temp.getNutriType().name().equals(orig.getNutriType().name()));
			assertTrue(temp.getOperator().name().equals(orig.getOperator().name()));
			assertTrue(Double.compare(temp.getValue(), orig.getValue()) == 0);
			assertTrue(temp.getUnit().name().equals(orig.getUnit().name()));
		}
		
		for(int i = 0; i< NUM_TEST_VALUES; i++)
		{
			testee.deleteFilter(dbFilters.getFilter(i));
		}
		
		dbFilters = testee.getAllFilters();
		
		assertTrue(dbFilters.size() == 0);
		
		testee.addIngredientFilter("spam");
		testee.addIngredientFilter("egg");
		testee.addIngredientFilter("saussauge");
		testee.addIngredientFilter("bacon");
		testee.addIngredientFilter("baked beans");
		testee.addIngredientFilter("steak");
		
		ingredientFilters = testee.getAllIngredientFilters();
		
		assertFalse(ingredientFilters.indexOf("spam") == -1);
		assertFalse(ingredientFilters.indexOf("egg") == -1);
		assertFalse(ingredientFilters.indexOf("saussauge") == -1);
		assertFalse(ingredientFilters.indexOf("bacon") == -1);
		assertFalse(ingredientFilters.indexOf("baked beans") == -1);
		assertFalse(ingredientFilters.indexOf("steak") == -1);
		
		testee.deleteIngredientFilter("spam");
		testee.deleteIngredientFilter("egg");
		testee.deleteIngredientFilter("saussauge");
		testee.deleteIngredientFilter("bacon");
		testee.deleteIngredientFilter("baked beans");
		testee.deleteIngredientFilter("steak");
		
		ingredientFilters = testee.getAllIngredientFilters();
		
		assertTrue(ingredientFilters.size() == 0);
		
		testee.close();		
		
		System.out.println("Finished testFilters");
	}
	
	public void testFoodSearch()
	{
		System.out.println("\nStarting testFoodSearch");
		
		//Note: use test db and not real one, takes much less time to load...
		testee.open("FOOD_TEST2");
		assertNotNull(testee);
		
		FoodItemList list = testee.searchFoodItems("");		// grab all the items
		assertNotNull(list);
		
		list = testee.searchFoodItems("Food");
		assertNotNull(list);								// should find some items
		
		list = testee.searchFoodItems("1234532432");		// should find nothing
		assertEquals(list.size(), 0);
		
		testee.close();
		
		System.out.println("Finished testFoodSearch");
	}

}

class TestHelper
{
	private static String[] ingredients = {"spam", "egg", "saussauge", "bacon", "baked beans", "steak"};
	private static final long seed = 1;
	private static Random random = new Random(seed);
	
	public static ArrayList<String> getRandomIngredients()
	{
		ArrayList<String> result = new ArrayList<String>();
				
		for(int i = 0; i< 6; i++)
		{
			String ingredient = ingredients[random.nextInt(6)];
			if(result.indexOf(ingredient) == -1)
			{
				result.add(ingredient);
			}
		}
		
		return result;
	}
	
}
