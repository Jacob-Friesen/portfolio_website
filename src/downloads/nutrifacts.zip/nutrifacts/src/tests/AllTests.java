package tests;

import junit.framework.Test;
import junit.framework.TestSuite;
import tests.integration.DailyIntakeIntegration;
import tests.integration.FoodItemsIntegration;
import tests.integration.IngredientFiltersIntegration;
import tests.integration.NutriFiltersIntegration;
import tests.logic.*;
import tests.object.*;
import tests.persistence.DataAccessObjectTest;

/**
 * Tests all the features of this application
 */
public class AllTests
{
	public static TestSuite suite;

	public static Test suite()
	{
		suite = new TestSuite("All tests");
		testObjects();
		testLogic();
		testPersistence();
		testIntegration();
		
		resetDB();
		
		return suite;
	}

	/**
	 * Tests all logic based objects of the application
	 */
	private static void testObjects()
	{
		suite.addTestSuite(IngredientsTest.class);
		suite.addTestSuite(NutriFactsTest.class);
		suite.addTestSuite(FoodItemTest.class);
		suite.addTestSuite(FoodItemsListTest.class);
		suite.addTestSuite(NutriFilterListTest.class);
		suite.addTestSuite(NutriFilterTest.class);
		suite.addTestSuite(IngredientFiltersTest.class);
		suite.addTestSuite(RationalTest.class);
		suite.addTestSuite(FilterResultTest.class);
		suite.addTestSuite(FilterResultsTest.class);
	}

	/**
	 * Tests all logic
	 */
	private static void testLogic()
	{
		suite.addTestSuite(FoodHandlerTest.class);
		suite.addTestSuite(SuggestionHandlerTest.class);
		suite.addTestSuite(DailyPercentLogicTest.class);
		suite.addTestSuite(FilterLogicTest.class);
	}
	
	/**
	 * Tests all of the persistence layer
	 */
	private static void testPersistence()
	{
		suite.addTestSuite(DataAccessObjectTest.class);
	}
	
	/**
	 * Runs all integration tests
	 */
	private static void testIntegration()
	{
		suite.addTestSuite(DailyIntakeIntegration.class);
		suite.addTestSuite(IngredientFiltersIntegration.class);
		suite.addTestSuite(NutriFiltersIntegration.class);
		suite.addTestSuite(FoodItemsIntegration.class);
	}
	
	/** 
	 * Method in AllTests would not run last no matter
	 * what, so I had to add a test suite that just
	 * resets the databases.
	 */
	private static void resetDB()
	{
		suite.addTestSuite(ResetDB.class);
	}
}