package tests.logic;

import java.util.ArrayList;
import java.util.Arrays;

import nutri.application.Services;
import nutri.enums.NutriType;
import nutri.enums.OperatorType;
import nutri.enums.UnitType;
import nutri.logic.SuggestionHandler;
import nutri.objects.FoodItem;
import nutri.objects.FoodItemList;
import nutri.objects.NutriFilter;
import nutri.persistence.DataAccessObject;
import junit.framework.TestCase;

public class SuggestionHandlerTest extends TestCase
{
	protected SuggestionHandler suggestionHandler;

	/**
	 * Tests load and constructor because load depends on constructor
	 */
	public void testLoadandConstructor()
	{
		System.out.println("\nStarting testLoadandConstructor");
		
		Services.createDataAccess("FOOD_TEST2");
		suggestionHandler = new SuggestionHandler(Services.getDataAccess());
		
		assertNotNull(suggestionHandler);
		assertTrue(suggestionHandler.getScale() == 1);
		
		assertTrue(suggestionHandler.getAllFoodItems().size() == 0);
		suggestionHandler.loadData();
		assertTrue(suggestionHandler.getAllFoodItems().size() > 0);
		
		Services.closeDataAccess();
		
		System.out.println("Finished testLoadandConstructor");
	}
	
	/**
	 * Try a bunch of gets of a new items
	 */
	public void testGets()
	{
		System.out.println("\nStarting testGets");
		
		Services.createDataAccess("FOOD_TEST2");
		suggestionHandler = new SuggestionHandler(Services.getDataAccess());
		
		ArrayList<FoodItem> foodItems = null;
		
		suggestionHandler.loadData();
		
		foodItems = suggestionHandler.getAllFoodItems();
		assertTrue(foodItems.size() > 0);
		
		for(FoodItem food : foodItems)
		{
			assertTrue(food == suggestionHandler.getFoodItem(food.getName()));
		}	
		
		Services.closeDataAccess();
		
		System.out.println("Finished testGets");
	}
	
	/**
	 * Test to see if all scale values work
	 */
	public void testScale()
	{
		System.out.println("\nStarting testScale");
		
		Services.createDataAccess("FOOD_TEST2");
		suggestionHandler = new SuggestionHandler(Services.getDataAccess());
		
		suggestionHandler.setScale(0);
		assertTrue(suggestionHandler.getScale() == 0);
		
		suggestionHandler.setScale(-1);
		assertTrue(suggestionHandler.getScale() == -1);
		suggestionHandler.setScale(Integer.MIN_VALUE);
		assertTrue(suggestionHandler.getScale() == Integer.MIN_VALUE);
		suggestionHandler.setScale(-100);
		assertTrue(suggestionHandler.getScale() == -100);
		
		suggestionHandler.setScale(6.21);
		assertTrue(suggestionHandler.getScale() == 6.21);
		suggestionHandler.setScale(Integer.MAX_VALUE);
		assertTrue(suggestionHandler.getScale() == Integer.MAX_VALUE);
		suggestionHandler.setScale(Math.PI);
		assertTrue(suggestionHandler.getScale() == Math.PI);
		
		Services.closeDataAccess();
		
		System.out.println("Finished testScale");
	}
	
	/**
	 * Test to see if getting amount as a string works
	 */
	public void testGetAmountString()
	{
		System.out.println("\nStarting testGetAmountString");
		
		Services.createDataAccess("FOOD_TEST2");
		suggestionHandler = new SuggestionHandler(Services.getDataAccess());
		
		FoodItem product = new FoodItem("Kit Kat Bar", 42, "g");

		ArrayList<String> ingredients = new ArrayList<String>(Arrays.asList("Milk Chocolate", "Cocoa", "Butter", "Unsweetened Chocolate", "Lactoce", "Soya Lecithin", "Polyglycerol",
				"Polyricinoleate", "Wheat Flour", "Sugar", "Hydrogenated Soybean Oil or Modified Palm Oil", "Artificial Flavour"));

		product.addIngredients(ingredients);
		
		product.addFact(NutriType.CALORIES, 218);
		product.addFact(NutriType.FAT, 11);
		product.addFact(NutriType.SATURATED_FAT, 8);
		product.addFact(NutriType.TRANS_FAT, 0);
		product.addFact(NutriType.CHOLESTEROL, 0.005);
		product.addFact(NutriType.SODIUM, 0.023);
		product.addFact(NutriType.CARBS, 27);
		product.addFact(NutriType.FIBRE, 0);
		product.addFact(NutriType.SUGAR, 20);
		product.addFact(NutriType.PROTEIN, 3);
		product.addFact(NutriType.VITAMIN_A, 0.01);
		product.addFact(NutriType.VITAMIN_C, 0);
		product.addFact(NutriType.CALCIUM, 0.05);
		product.addFact(NutriType.IRON, 0.02);
		
		product.setPortion(1, "bar", "barre");
		
		product.addFact(NutriType.CALCIUM, .80);
		
		//test no units and milligrams (easier to compare when combined)
		assertTrue(suggestionHandler.getAmountString(product, NutriType.CALORIES, UnitType.NONE).equals("218"));
		assertTrue(suggestionHandler.getAmountString(product, NutriType.FAT, UnitType.NONE).equals("11"));
		assertTrue(suggestionHandler.getAmountString(product, NutriType.SATURATED_FAT, UnitType.NONE).equals("8"));
		assertTrue(suggestionHandler.getAmountString(product, NutriType.TRANS_FAT, UnitType.NONE).equals("0"));
		
		assertTrue(suggestionHandler.getAmountString(product, NutriType.CHOLESTEROL, UnitType.NONE).equals("0"));
		assertTrue(suggestionHandler.getAmountString(product, NutriType.CHOLESTEROL, UnitType.MILLIGRAMS).equals("5 mg"));
		
		assertTrue(suggestionHandler.getAmountString(product, NutriType.SODIUM, UnitType.NONE).equals("0"));
		assertTrue(suggestionHandler.getAmountString(product, NutriType.SODIUM, UnitType.MILLIGRAMS).equals("23 mg"));
		
		assertTrue(suggestionHandler.getAmountString(product, NutriType.CARBS, UnitType.NONE).equals("27"));
		assertTrue(suggestionHandler.getAmountString(product, NutriType.FIBRE, UnitType.NONE).equals("0"));
		assertTrue(suggestionHandler.getAmountString(product, NutriType.SUGAR, UnitType.NONE).equals("20"));
		assertTrue(suggestionHandler.getAmountString(product, NutriType.PROTEIN, UnitType.NONE).equals("3"));
		
		assertTrue(suggestionHandler.getAmountString(product, NutriType.VITAMIN_A, UnitType.NONE).equals("0"));
		assertTrue(suggestionHandler.getAmountString(product, NutriType.VITAMIN_A, UnitType.MILLIGRAMS).equals("10 mg"));
		
		assertTrue(suggestionHandler.getAmountString(product, NutriType.VITAMIN_C, UnitType.NONE).equals("0"));
		
		assertTrue(suggestionHandler.getAmountString(product, NutriType.CALCIUM, UnitType.NONE).equals("0"));
		assertTrue(suggestionHandler.getAmountString(product, NutriType.CALCIUM, UnitType.MILLIGRAMS).equals("800 mg"));
		
		assertTrue(suggestionHandler.getAmountString(product, NutriType.IRON, UnitType.NONE).equals("0"));
		assertTrue(suggestionHandler.getAmountString(product, NutriType.IRON, UnitType.MILLIGRAMS).equals("20 mg"));
		
		//test grams
		assertTrue(suggestionHandler.getAmountString(product, NutriType.CALORIES, UnitType.GRAMS).equals("218 g"));
		assertTrue(suggestionHandler.getAmountString(product, NutriType.FAT, UnitType.GRAMS).equals("11 g"));
		assertTrue(suggestionHandler.getAmountString(product, NutriType.SATURATED_FAT, UnitType.GRAMS).equals("8 g"));
		assertTrue(suggestionHandler.getAmountString(product, NutriType.TRANS_FAT, UnitType.GRAMS).equals("0 g"));	
		assertTrue(suggestionHandler.getAmountString(product, NutriType.CHOLESTEROL, UnitType.GRAMS).equals("0 g"));
		assertTrue(suggestionHandler.getAmountString(product, NutriType.SODIUM, UnitType.GRAMS).equals("0 g"));
		assertTrue(suggestionHandler.getAmountString(product, NutriType.CARBS, UnitType.GRAMS).equals("27 g"));
		assertTrue(suggestionHandler.getAmountString(product, NutriType.FIBRE, UnitType.GRAMS).equals("0 g"));
		assertTrue(suggestionHandler.getAmountString(product, NutriType.SUGAR, UnitType.GRAMS).equals("20 g"));
		assertTrue(suggestionHandler.getAmountString(product, NutriType.PROTEIN, UnitType.GRAMS).equals("3 g"));	
		assertTrue(suggestionHandler.getAmountString(product, NutriType.VITAMIN_A, UnitType.GRAMS).equals("0 g"));
		assertTrue(suggestionHandler.getAmountString(product, NutriType.VITAMIN_C, UnitType.GRAMS).equals("0 g"));
		assertTrue(suggestionHandler.getAmountString(product, NutriType.CALCIUM, UnitType.GRAMS).equals("0 g"));
		assertTrue(suggestionHandler.getAmountString(product, NutriType.IRON, UnitType.GRAMS).equals("0 g"));
		
		Services.closeDataAccess();
		
		System.out.println("Finished testGetAmountString");
	}
	
	/**
	 * Test to see if getting a portion works correctly
	 */
	public void testPortionString()
	{
		System.out.println("\nStarting testPortionString");
		
		Services.createDataAccess("FOOD_TEST2");
		suggestionHandler = new SuggestionHandler(Services.getDataAccess());
		
		FoodItem product = new FoodItem("Kit Kat Bar", 42, "g");
		assertTrue(product.getPortionString(1.0).equals("Per 1 portion (42 g) / par 1 portion (42 g)"));
		assertTrue(product.getPortionString(5.0).equals("Per 5 portion (210 g) / par 5 portion (210 g)"));
		assertTrue(product.getPortionString(10.0).equals("Per 10 portion (420 g) / par 10 portion (420 g)"));
		
		product = new FoodItem("Kit Kat Bar", 0, "g");
		product.setPortion(1, "gf", "g");
		assertTrue(product.getPortionString(1.0), product.getPortionString(1.0).equals("Per 1 gf (0 g) / par 1 g (0 g)"));
		assertTrue(product.getPortionString(5.0).equals("Per 5 gf (0 g) / par 5 g (0 g)"));
		assertTrue(product.getPortionString(10.0).equals("Per 10 gf (0 g) / par 10 g (0 g)"));
		
		product = new FoodItem("Kit Kat Bar", 999999, "kg");
		product.setPortion(99999, "portion", "portion");//notice 1 digit less than above
		assertTrue(product.getPortionString(1.0), product.getPortionString(1.0).equals("Per 99999 portion (999999 kg) / par 99999 portion (999999 kg)"));
		assertTrue(product.getPortionString(5.0),product.getPortionString(5.0).equals("Per 499995 portion (4999995 kg) / par 499995 portion (4999995 kg)"));
		assertTrue(product.getPortionString(10.0).equals("Per 999990 portion (9999990 kg) / par 999990 portion (9999990 kg)"));
		
		product = new FoodItem("Kit Kat Bar", 0, "");
		product.setPortion(0, "", "");
		assertTrue(product.getPortionString(1.0).equals("Per 0  (0 ) / par 0  (0 )"));
		assertTrue(product.getPortionString(5.0).equals("Per 0  (0 ) / par 0  (0 )"));
		assertTrue(product.getPortionString(10.0).equals("Per 0  (0 ) / par 0  (0 )"));
		
		Services.closeDataAccess();
		
		System.out.println("Finished testPortionString");
	}
	
	/**
	 * Tests to see if getting a list of ingredients works
	 */
	public void testIngredientString()
	{
		System.out.println("\nStarting testIngredientString");
		
		Services.createDataAccess("FOOD_TEST2");
		suggestionHandler = new SuggestionHandler(Services.getDataAccess());
		
		FoodItem product = new FoodItem("Kit Kat Bar", 42, "g");
		
		ArrayList<String> ingredients = new ArrayList<String>(Arrays.asList("Milk Chocolate", "Cocoa", "Butter", "Unsweetened Chocolate", "Lactoce", "Soya Lecithin", "Polyglycerol",
				"Polyricinoleate", "Wheat Flour", "Sugar", "Hydrogenated Soybean Oil or Modified Palm Oil", "Artificial Flavour"));

		product.addIngredients(ingredients);
		
		String ingrString = ingredients.toString().replaceFirst("\\[", "").replaceAll("\\]", "");
		assertTrue(product.getIngredientsString().equals(ingrString));
		
		product = new FoodItem("Kit Kat Bar", 42, "g");
		ingredients = new ArrayList<String>();
		product.addIngredients(ingredients);
		ingrString = ingredients.toString().replaceFirst("\\[", "").replaceAll("\\]", "");
		assertTrue(product.getIngredientsString().equals(ingrString));
		
		Services.closeDataAccess();
		
		System.out.println("Finished testIngredientString");
	}
	
	/**
	 * Tests the comparator for suggestions
	 */
	public void testSuggestionCompare()
	{
		System.out.println("\nStarting testSuggestionCompare");
		
		Services.createDataAccess("FOOD_TEST");
		suggestionHandler = new SuggestionHandler(Services.getDataAccess());
		
		SuggestionHandler.SuggestionComparator c = new SuggestionHandler.SuggestionComparator();

		// add some food to database
		FoodItem kitKat = new FoodItem("Kit Kat Bar", 42, "g");
		
		kitKat.addFact(NutriType.CALORIES, 218);
		kitKat.addFact(NutriType.FAT, 11);
		kitKat.addFact(NutriType.SATURATED_FAT, 8);
		kitKat.addFact(NutriType.TRANS_FAT, 0);
		kitKat.addFact(NutriType.CHOLESTEROL, 0.005);
		kitKat.addFact(NutriType.SODIUM, 0.023);
		kitKat.addFact(NutriType.CARBS, 27);
		kitKat.addFact(NutriType.FIBRE, 0);
		kitKat.addFact(NutriType.SUGAR, 20);
		kitKat.addFact(NutriType.PROTEIN, 3);
		kitKat.addFact(NutriType.VITAMIN_A, 0.01);
		kitKat.addFact(NutriType.VITAMIN_C, 0);
		kitKat.addFact(NutriType.CALCIUM, 0.05);
		kitKat.addFact(NutriType.IRON, 0.02);
		
		FoodItem crunchie = new FoodItem("Crunchie", 42, "g");
		
		crunchie.addFact(NutriType.CALORIES, 218);
		crunchie.addFact(NutriType.FAT, 11);
		crunchie.addFact(NutriType.SATURATED_FAT, 8);
		crunchie.addFact(NutriType.TRANS_FAT, 0);
		crunchie.addFact(NutriType.CHOLESTEROL, 0.005);
		crunchie.addFact(NutriType.SODIUM, 0.023);
		crunchie.addFact(NutriType.CARBS, 27);
		crunchie.addFact(NutriType.FIBRE, 0);
		crunchie.addFact(NutriType.SUGAR, 20);
		crunchie.addFact(NutriType.PROTEIN, 3);
		crunchie.addFact(NutriType.VITAMIN_A, 0.01);
		crunchie.addFact(NutriType.VITAMIN_C, 0);
		crunchie.addFact(NutriType.CALCIUM, 0.05);
		crunchie.addFact(NutriType.IRON, 0.02);
		
		assertEquals(c.compare(kitKat, kitKat), 0);
		assertTrue(c.compare(kitKat, crunchie) > 0);
		assertTrue(c.compare(crunchie, kitKat) < 0);
		
		// add some ratings
		kitKat.setRating(3);
		
		assertEquals(c.compare(kitKat, kitKat), 0);
		assertTrue(c.compare(kitKat, crunchie) < 0);
		assertTrue(c.compare(crunchie, kitKat) > 0);
		
		crunchie.setRating(1);
		
		assertEquals(c.compare(kitKat, kitKat), 0);
		assertTrue(c.compare(kitKat, crunchie) < 0);
		assertTrue(c.compare(crunchie, kitKat) > 0);
		
		// add some filters
		NutriFilter filter = new NutriFilter(NutriType.FAT, OperatorType.LESS, 10, UnitType.GRAMS);
		
		Services.getDataAccess().addFilter(filter);
		
		assertEquals(c.compare(kitKat, kitKat), 0);
		assertTrue(c.compare(kitKat, crunchie) < 0);
		assertTrue(c.compare(crunchie, kitKat) > 0);
		
		crunchie.addFact(NutriType.FAT, 9);
		
		assertEquals(c.compare(kitKat, kitKat), 0);
		assertTrue(c.compare(kitKat, crunchie) > 0);
		assertTrue(c.compare(crunchie, kitKat) < 0);
		
		Services.getDataAccess().deleteFilter(filter);
		Services.closeDataAccess();
		
		System.out.println("Finished testSuggestionCompare");
	}
	
	public void testSuggestions()
	{
		System.out.println("\nStarting testSuggestions");
		
		Services.createDataAccess("FOOD_TEST");
		DataAccessObject dataAccess = (DataAccessObject)Services.getDataAccess();
		suggestionHandler = new SuggestionHandler(Services.getDataAccess());
		
		// to test suggestions, need to have three foods in the database
		
		// add some food to database
		FoodItem kitKat = new FoodItem("Kit Kat Bar", 42, "g");
		
		kitKat.addFact(NutriType.CALORIES, 218);
		kitKat.addFact(NutriType.FAT, 11);
		kitKat.addFact(NutriType.SATURATED_FAT, 8);
		kitKat.addFact(NutriType.TRANS_FAT, 0);
		kitKat.addFact(NutriType.CHOLESTEROL, 0.005);
		kitKat.addFact(NutriType.SODIUM, 0.023);
		kitKat.addFact(NutriType.CARBS, 27);
		kitKat.addFact(NutriType.FIBRE, 0);
		kitKat.addFact(NutriType.SUGAR, 20);
		kitKat.addFact(NutriType.PROTEIN, 3);
		kitKat.addFact(NutriType.VITAMIN_A, 0.01);
		kitKat.addFact(NutriType.VITAMIN_C, 0);
		kitKat.addFact(NutriType.CALCIUM, 0.05);
		kitKat.addFact(NutriType.IRON, 0.02);
		
		FoodItem crunchie = new FoodItem("Crunchie", 42, "g");
		
		crunchie.addFact(NutriType.CALORIES, 218);
		crunchie.addFact(NutriType.FAT, 11);
		crunchie.addFact(NutriType.SATURATED_FAT, 8);
		crunchie.addFact(NutriType.TRANS_FAT, 0);
		crunchie.addFact(NutriType.CHOLESTEROL, 0.005);
		crunchie.addFact(NutriType.SODIUM, 0.023);
		crunchie.addFact(NutriType.CARBS, 27);
		crunchie.addFact(NutriType.FIBRE, 0);
		crunchie.addFact(NutriType.SUGAR, 20);
		crunchie.addFact(NutriType.PROTEIN, 3);
		crunchie.addFact(NutriType.VITAMIN_A, 0.01);
		crunchie.addFact(NutriType.VITAMIN_C, 0);
		crunchie.addFact(NutriType.CALCIUM, 0.05);
		crunchie.addFact(NutriType.IRON, 0.02);
		
		FoodItem aero = new FoodItem("Aero", 42, "g");
		
		aero.addFact(NutriType.CALORIES, 218);
		aero.addFact(NutriType.FAT, 11);
		aero.addFact(NutriType.SATURATED_FAT, 8);
		aero.addFact(NutriType.TRANS_FAT, 0);
		aero.addFact(NutriType.CHOLESTEROL, 0.005);
		aero.addFact(NutriType.SODIUM, 0.023);
		aero.addFact(NutriType.CARBS, 27);
		aero.addFact(NutriType.FIBRE, 0);
		aero.addFact(NutriType.SUGAR, 20);
		aero.addFact(NutriType.PROTEIN, 3);
		aero.addFact(NutriType.VITAMIN_A, 0.01);
		aero.addFact(NutriType.VITAMIN_C, 0);
		aero.addFact(NutriType.CALCIUM, 0.05);
		aero.addFact(NutriType.IRON, 0.02);
		
		dataAccess.addFood(kitKat);
		dataAccess.addFood(crunchie);
		dataAccess.addFood(aero);
		
		// all food is equal - should return in alphabetical order
		FoodItemList result = suggestionHandler.getSuggestions(kitKat);
		
		assertTrue(result.size() == 2);
		assertEquals(result.get(0).getName(), aero.getName());
		assertEquals(result.get(1).getName(), crunchie.getName());
		
		result = suggestionHandler.getSuggestions(aero);
		
		assertTrue(result.size() == 2);
		assertEquals(result.get(0).getName(), crunchie.getName());
		assertEquals(result.get(1).getName(), kitKat.getName());
		
		// test with a higher rating
		dataAccess.updateFoodRating(kitKat.getName(), 5);
		
		result = suggestionHandler.getSuggestions(aero);
		
		assertTrue(result.size() == 2);
		assertEquals(result.get(1).getName(), crunchie.getName());
		assertEquals(result.get(0).getName(), kitKat.getName());
		
		NutriFilter filter = new NutriFilter(NutriType.FAT, OperatorType.LESS, 10, UnitType.GRAMS);
		dataAccess.addFilter(filter);
		
		result = suggestionHandler.getSuggestions(aero);
		
		assertTrue(result.size() == 2);
		assertEquals(result.get(1).getName(), crunchie.getName());
		assertEquals(result.get(0).getName(), kitKat.getName());
		
		crunchie.addFact(NutriType.FAT, 5);
		dataAccess.deleteFood(crunchie.getName());
		dataAccess.addFood(crunchie);
		
		result = suggestionHandler.getSuggestions(kitKat);
		
		assertTrue(result.size() == 2);
		assertEquals(result.get(1).getName(), aero.getName());
		assertEquals(result.get(0).getName(), crunchie.getName()); // passes all the filters
		
		// clean up
		dataAccess.deleteFood(kitKat.getName());
		dataAccess.deleteFood(crunchie.getName());
		dataAccess.deleteFood(aero.getName());
		
		dataAccess.deleteFilter(filter);
		
		Services.closeDataAccess();
		
		System.out.println("Finished testSuggestions");
	}
}
