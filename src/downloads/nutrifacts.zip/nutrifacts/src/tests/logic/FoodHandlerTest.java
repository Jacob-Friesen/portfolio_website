package tests.logic;


import java.util.ArrayList;
import java.util.Arrays;

import nutri.application.Services;
import nutri.enums.NutriType;
import nutri.enums.UnitType;
import nutri.logic.FoodHandler;
import nutri.objects.FoodItem;
import junit.framework.TestCase;

public class FoodHandlerTest extends TestCase 
{
	protected FoodHandler foodHandler;

	/**
	 * Tests load and constructor because load depends on constructor
	 */
	public void testLoadandConstructor()
	{
		System.out.println("\nStarting testLoadandConstructor");
		
		Services.createDataAccess("FOOD_TEST2");
		foodHandler = new FoodHandler(Services.getDataAccess());
		
		assertNotNull(foodHandler);
		assertTrue(foodHandler.getScale() == 1);
		
		assertTrue(foodHandler.getAllFoodItems().size() == 0);
		foodHandler.loadData();
		assertTrue(foodHandler.getAllFoodItems().size() > 0);
		
		Services.closeDataAccess();
		
		System.out.println("Finished testLoadandConstructor");
	}
	
	/**
	 * Try a bunch of gets of a new items
	 */
	public void testGets()
	{
		System.out.println("\nStarting testGets");
		
		Services.createDataAccess("FOOD_TEST2");
		foodHandler = new FoodHandler(Services.getDataAccess());
		
		ArrayList<FoodItem> foodItems = null;
		
		foodHandler.loadData();
		
		foodItems = foodHandler.getAllFoodItems();
		assertTrue(foodItems.size() > 0);
		
		for(FoodItem food : foodItems)
		{
			assertTrue(food == foodHandler.getFoodItem(food.getName()));
		}	
		
		Services.closeDataAccess();
		
		System.out.println("Finished testGets");
	}
	
	/**
	 * Test to see if all scale values work
	 */
	public void testScale()
	{
		System.out.println("\nStarting testScale");
		
		Services.createDataAccess("FOOD_TEST2");
		foodHandler = new FoodHandler(Services.getDataAccess());
		
		foodHandler.setScale(0);
		assertTrue(foodHandler.getScale() == 0);
		
		foodHandler.setScale(-1);
		assertTrue(foodHandler.getScale() == -1);
		foodHandler.setScale(Integer.MIN_VALUE);
		assertTrue(foodHandler.getScale() == Integer.MIN_VALUE);
		foodHandler.setScale(-100);
		assertTrue(foodHandler.getScale() == -100);
		
		foodHandler.setScale(6.21);
		assertTrue(foodHandler.getScale() == 6.21);
		foodHandler.setScale(Integer.MAX_VALUE);
		assertTrue(foodHandler.getScale() == Integer.MAX_VALUE);
		foodHandler.setScale(Math.PI);
		assertTrue(foodHandler.getScale() == Math.PI);
		
		Services.closeDataAccess();
		
		System.out.println("Finished testScale");
	}
	
	/**
	 * Test to see if getting amount as a string works
	 */
	public void testGetAmountString()
	{
		System.out.println("\nStarting testGetAmountString");
		
		Services.createDataAccess("FOOD_TEST2");
		foodHandler = new FoodHandler(Services.getDataAccess());
		
		FoodItem product = new FoodItem("Kit Kat Bar", 42, "g");

		ArrayList<String> ingredients = new ArrayList<String>(Arrays.asList("Milk Chocolate", "Cocoa", "Butter", "Unsweetened Chocolate", "Lactoce", "Soya Lecithin", "Polyglycerol",
				"Polyricinoleate", "Wheat Flour", "Sugar", "Hydrogenated Soybean Oil or Modified Palm Oil", "Artificial Flavour"));

		product.addIngredients(ingredients);
		
		product.addFact(NutriType.CALORIES, 218);
		product.addFact(NutriType.FAT, 11);
		product.addFact(NutriType.SATURATED_FAT, 8);
		product.addFact(NutriType.TRANS_FAT, 0);
		product.addFact(NutriType.CHOLESTEROL, 0.005);
		product.addFact(NutriType.SODIUM, 0.023);
		product.addFact(NutriType.CARBS, 27);
		product.addFact(NutriType.FIBRE, 0);
		product.addFact(NutriType.SUGAR, 20);
		product.addFact(NutriType.PROTEIN, 3);
		product.addFact(NutriType.VITAMIN_A, 0.01);
		product.addFact(NutriType.VITAMIN_C, 0);
		product.addFact(NutriType.CALCIUM, 0.05);
		product.addFact(NutriType.IRON, 0.02);
		
		product.setPortion(1, "bar", "barre");
		
		product.addFact(NutriType.CALCIUM, .80);
		
		//test no units and milligrams (easier to compare when combined)
		assertTrue(foodHandler.getAmountString(product, NutriType.CALORIES, UnitType.NONE).equals("218"));
		assertTrue(foodHandler.getAmountString(product, NutriType.FAT, UnitType.NONE).equals("11"));
		assertTrue(foodHandler.getAmountString(product, NutriType.SATURATED_FAT, UnitType.NONE).equals("8"));
		assertTrue(foodHandler.getAmountString(product, NutriType.TRANS_FAT, UnitType.NONE).equals("0"));
		
		assertTrue(foodHandler.getAmountString(product, NutriType.CHOLESTEROL, UnitType.NONE).equals("0"));
		assertTrue(foodHandler.getAmountString(product, NutriType.CHOLESTEROL, UnitType.MILLIGRAMS).equals("5 mg"));
		
		assertTrue(foodHandler.getAmountString(product, NutriType.SODIUM, UnitType.NONE).equals("0"));
		assertTrue(foodHandler.getAmountString(product, NutriType.SODIUM, UnitType.MILLIGRAMS).equals("23 mg"));
		
		assertTrue(foodHandler.getAmountString(product, NutriType.CARBS, UnitType.NONE).equals("27"));
		assertTrue(foodHandler.getAmountString(product, NutriType.FIBRE, UnitType.NONE).equals("0"));
		assertTrue(foodHandler.getAmountString(product, NutriType.SUGAR, UnitType.NONE).equals("20"));
		assertTrue(foodHandler.getAmountString(product, NutriType.PROTEIN, UnitType.NONE).equals("3"));
		
		assertTrue(foodHandler.getAmountString(product, NutriType.VITAMIN_A, UnitType.NONE).equals("0"));
		assertTrue(foodHandler.getAmountString(product, NutriType.VITAMIN_A, UnitType.MILLIGRAMS).equals("10 mg"));
		
		assertTrue(foodHandler.getAmountString(product, NutriType.VITAMIN_C, UnitType.NONE).equals("0"));
		
		assertTrue(foodHandler.getAmountString(product, NutriType.CALCIUM, UnitType.NONE).equals("0"));
		assertTrue(foodHandler.getAmountString(product, NutriType.CALCIUM, UnitType.MILLIGRAMS).equals("800 mg"));
		
		assertTrue(foodHandler.getAmountString(product, NutriType.IRON, UnitType.NONE).equals("0"));
		assertTrue(foodHandler.getAmountString(product, NutriType.IRON, UnitType.MILLIGRAMS).equals("20 mg"));
		
		//test grams
		assertTrue(foodHandler.getAmountString(product, NutriType.CALORIES, UnitType.GRAMS).equals("218 g"));
		assertTrue(foodHandler.getAmountString(product, NutriType.FAT, UnitType.GRAMS).equals("11 g"));
		assertTrue(foodHandler.getAmountString(product, NutriType.SATURATED_FAT, UnitType.GRAMS).equals("8 g"));
		assertTrue(foodHandler.getAmountString(product, NutriType.TRANS_FAT, UnitType.GRAMS).equals("0 g"));	
		assertTrue(foodHandler.getAmountString(product, NutriType.CHOLESTEROL, UnitType.GRAMS).equals("0 g"));
		assertTrue(foodHandler.getAmountString(product, NutriType.SODIUM, UnitType.GRAMS).equals("0 g"));
		assertTrue(foodHandler.getAmountString(product, NutriType.CARBS, UnitType.GRAMS).equals("27 g"));
		assertTrue(foodHandler.getAmountString(product, NutriType.FIBRE, UnitType.GRAMS).equals("0 g"));
		assertTrue(foodHandler.getAmountString(product, NutriType.SUGAR, UnitType.GRAMS).equals("20 g"));
		assertTrue(foodHandler.getAmountString(product, NutriType.PROTEIN, UnitType.GRAMS).equals("3 g"));	
		assertTrue(foodHandler.getAmountString(product, NutriType.VITAMIN_A, UnitType.GRAMS).equals("0 g"));
		assertTrue(foodHandler.getAmountString(product, NutriType.VITAMIN_C, UnitType.GRAMS).equals("0 g"));
		assertTrue(foodHandler.getAmountString(product, NutriType.CALCIUM, UnitType.GRAMS).equals("0 g"));
		assertTrue(foodHandler.getAmountString(product, NutriType.IRON, UnitType.GRAMS).equals("0 g"));
		
		Services.closeDataAccess();
		
		System.out.println("Finished testGetAmountString");
	}
	
	/**
	 * Test to see if getting a portion works correctly
	 */
	public void testPortionString()
	{
		System.out.println("\nStarting testPortionString");
		
		Services.createDataAccess("FOOD_TEST2");
		foodHandler = new FoodHandler(Services.getDataAccess());
		
		FoodItem product = new FoodItem("Kit Kat Bar", 42, "g");
		assertTrue(product.getPortionString(1.0).equals("Per 1 portion (42 g) / par 1 portion (42 g)"));
		assertTrue(product.getPortionString(5.0).equals("Per 5 portion (210 g) / par 5 portion (210 g)"));
		assertTrue(product.getPortionString(10.0).equals("Per 10 portion (420 g) / par 10 portion (420 g)"));
		
		product = new FoodItem("Kit Kat Bar", 0, "g");
		product.setPortion(1, "gf", "g");
		assertTrue(product.getPortionString(1.0), product.getPortionString(1.0).equals("Per 1 gf (0 g) / par 1 g (0 g)"));
		assertTrue(product.getPortionString(5.0).equals("Per 5 gf (0 g) / par 5 g (0 g)"));
		assertTrue(product.getPortionString(10.0).equals("Per 10 gf (0 g) / par 10 g (0 g)"));
		
		product = new FoodItem("Kit Kat Bar", 999999, "kg");
		product.setPortion(99999, "portion", "portion");//notice 1 digit less than above
		assertTrue(product.getPortionString(1.0), product.getPortionString(1.0).equals("Per 99999 portion (999999 kg) / par 99999 portion (999999 kg)"));
		assertTrue(product.getPortionString(5.0),product.getPortionString(5.0).equals("Per 499995 portion (4999995 kg) / par 499995 portion (4999995 kg)"));
		assertTrue(product.getPortionString(10.0).equals("Per 999990 portion (9999990 kg) / par 999990 portion (9999990 kg)"));
		
		product = new FoodItem("Kit Kat Bar", 0, "");
		product.setPortion(0, "", "");
		assertTrue(product.getPortionString(1.0).equals("Per 0  (0 ) / par 0  (0 )"));
		assertTrue(product.getPortionString(5.0).equals("Per 0  (0 ) / par 0  (0 )"));
		assertTrue(product.getPortionString(10.0).equals("Per 0  (0 ) / par 0  (0 )"));
		
		Services.closeDataAccess();
		
		System.out.println("Finished testPortionString");
	}
	
	/**
	 * Tests to see if getting a list of ingredients works
	 */
	public void testIngredientString()
	{
		System.out.println("\nStarting testIngredientString");
		
		Services.createDataAccess("FOOD_TEST2");
		foodHandler = new FoodHandler(Services.getDataAccess());
		
		FoodItem product = new FoodItem("Kit Kat Bar", 42, "g");
		
		ArrayList<String> ingredients = new ArrayList<String>(Arrays.asList("Milk Chocolate", "Cocoa", "Butter", "Unsweetened Chocolate", "Lactoce", "Soya Lecithin", "Polyglycerol",
				"Polyricinoleate", "Wheat Flour", "Sugar", "Hydrogenated Soybean Oil or Modified Palm Oil", "Artificial Flavour"));

		product.addIngredients(ingredients);
		
		String ingrString = ingredients.toString().replaceFirst("\\[", "").replaceAll("\\]", "");
		assertTrue(product.getIngredientsString().equals(ingrString));
		
		product = new FoodItem("Kit Kat Bar", 42, "g");
		ingredients = new ArrayList<String>();
		product.addIngredients(ingredients);
		ingrString = ingredients.toString().replaceFirst("\\[", "").replaceAll("\\]", "");
		assertTrue(product.getIngredientsString().equals(ingrString));
		
		Services.closeDataAccess();
		
		System.out.println("Finished testIngredientString");
	}
}
