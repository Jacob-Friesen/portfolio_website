package tests.logic;

import nutri.application.Services;
import nutri.enums.NutriType;
import nutri.objects.FoodItem;
import nutri.logic.DailyPercentLogic;
import junit.framework.TestCase;

public class DailyPercentLogicTest extends TestCase 
{
	/**
	 * Goes through a the case of making a nutritional values daily
	 * percentages equivalent to 0% of using a default scale
	 */
	public void testZeroPercent()
	{		
		System.out.println("\nStarting testZeroPercent");
		
		Services.createDataAccess("FOOD_TEST2");

		DailyPercentLogic logic = new DailyPercentLogic();
		double scale = 1.0;
		
		// create a food item with 0 for everything, expect 0%
		FoodItem food = new FoodItem("Test Item", 226, "g");

		food.addFact(NutriType.CALORIES, 0);
		food.addFact(NutriType.FAT, 0);
		food.addFact(NutriType.SATURATED_FAT, 0);
		food.addFact(NutriType.TRANS_FAT, 0);
		food.addFact(NutriType.CHOLESTEROL, 0);
		food.addFact(NutriType.SODIUM, 0);
		food.addFact(NutriType.CARBS, 0);
		food.addFact(NutriType.FIBRE, 0);
		food.addFact(NutriType.SUGAR, 0);
		food.addFact(NutriType.PROTEIN, 0);
		food.addFact(NutriType.VITAMIN_A, 0);
		food.addFact(NutriType.VITAMIN_C, 0);
		food.addFact(NutriType.CALCIUM, 0);
		food.addFact(NutriType.IRON, 0);
		food.setPortion(1, "serving", "serving");		
		
		assertTrue(logic.calcDailyPercentage(food, NutriType.CALORIES, scale) == 0);
		assertTrue(logic.calcDailyPercentage(food, NutriType.FAT, scale) == 0);
		assertTrue(logic.calcDailyPercentage(food, NutriType.SATURATED_FAT, scale) == 0);

		assertTrue(logic.calcDailyPercentage(food, NutriType.CHOLESTEROL, scale) == 0);
		assertTrue(logic.calcDailyPercentage(food, NutriType.SODIUM, scale) == 0);
		assertTrue(logic.calcDailyPercentage(food, NutriType.CARBS, scale) == 0);
		assertTrue(logic.calcDailyPercentage(food, NutriType.FIBRE, scale) == 0);

		assertTrue(logic.calcDailyPercentage(food, NutriType.PROTEIN, scale) == 0);
		assertTrue(logic.calcDailyPercentage(food, NutriType.VITAMIN_A, scale) == 0);
		assertTrue(logic.calcDailyPercentage(food, NutriType.VITAMIN_C, scale) == 0);
		assertTrue(logic.calcDailyPercentage(food, NutriType.CALCIUM, scale) == 0);
		assertTrue(logic.calcDailyPercentage(food, NutriType.IRON, scale) == 0);
	
		Services.closeDataAccess();
		
		System.out.println("Finished testZeroPercent");
	}
	
	/**
	 * Goes through a the case of making a nutritional values daily
	 * percentages equivalent to 100% of using a default scale
	 */
	public void testHundredPercent()
	{
		System.out.println("\nStarting testHundredPercent");
		
		Services.createDataAccess("FOOD_TEST2");
		
		DailyPercentLogic logic = new DailyPercentLogic();
		double scale = 1.0;
		
		// now test for 100%, by creating a food item with all the requirements
		// super nutrition!
		FoodItem food = new FoodItem("Test Item 2", 226, "g");

		food.addFact(NutriType.CALORIES, 2000);
		food.addFact(NutriType.FAT, 65);
		food.addFact(NutriType.SATURATED_FAT, 20);
		food.addFact(NutriType.TRANS_FAT, 0);
		food.addFact(NutriType.CHOLESTEROL, 0.3);
		food.addFact(NutriType.SODIUM, 2.3);
		food.addFact(NutriType.CARBS, 300);
		food.addFact(NutriType.FIBRE, 25);
		food.addFact(NutriType.SUGAR, 0);
		food.addFact(NutriType.PROTEIN, 50);
		food.addFact(NutriType.VITAMIN_A, 5000);
		food.addFact(NutriType.VITAMIN_C, 0.06);
		food.addFact(NutriType.CALCIUM, 1);
		food.addFact(NutriType.IRON, 0.018);
		food.setPortion(1, "serving", "serving");
		
		assertTrue(logic.calcDailyPercentage(food, NutriType.CALORIES, scale) == 100);
		assertTrue(logic.calcDailyPercentage(food, NutriType.FAT, scale) == 100);
		assertTrue(logic.calcDailyPercentage(food, NutriType.SATURATED_FAT, scale) == 100);

		assertTrue(logic.calcDailyPercentage(food, NutriType.CHOLESTEROL, scale) == 100);
		assertTrue(logic.calcDailyPercentage(food, NutriType.SODIUM, scale) == 100);
		assertTrue(logic.calcDailyPercentage(food, NutriType.CARBS, scale) == 100);
		assertTrue(logic.calcDailyPercentage(food, NutriType.FIBRE, scale) == 100);

		assertTrue(logic.calcDailyPercentage(food, NutriType.PROTEIN, scale) == 100);
		assertTrue(logic.calcDailyPercentage(food, NutriType.VITAMIN_A, scale) == 100);
		assertTrue(logic.calcDailyPercentage(food, NutriType.VITAMIN_C, scale) == 100);
		assertTrue(logic.calcDailyPercentage(food, NutriType.CALCIUM, scale) == 100);
		assertTrue(logic.calcDailyPercentage(food, NutriType.IRON, scale) == 100);
		
		Services.closeDataAccess();
		
		System.out.println("Finished testHundredPercent");
	}
	
	/**
	 * Gives nutritional values equal to half the daily intake and then sets the
	 * scale to 2.
	 */
	public void testScale()
	{
		System.out.println("\nStarting testScale");
		Services.createDataAccess("FOOD_TEST2");
		
		DailyPercentLogic logic = new DailyPercentLogic();
		double scale = 2.0;
		
		// now test for 100%, by creating a food with half the nutrition, and double scale
		// super nutrition!
		FoodItem food = new FoodItem("Test Item 2", 226, "g");

		food.addFact(NutriType.CALORIES, 1000);
		food.addFact(NutriType.FAT, 32.5);
		food.addFact(NutriType.SATURATED_FAT, 10);
		food.addFact(NutriType.TRANS_FAT, 0);
		food.addFact(NutriType.CHOLESTEROL, 0.15);
		food.addFact(NutriType.SODIUM, 1.15);
		food.addFact(NutriType.CARBS, 150);
		food.addFact(NutriType.FIBRE, 12.5);
		food.addFact(NutriType.SUGAR, 0);
		food.addFact(NutriType.PROTEIN, 25);
		food.addFact(NutriType.VITAMIN_A, 2500);
		food.addFact(NutriType.VITAMIN_C, 0.03);
		food.addFact(NutriType.CALCIUM, 0.5);
		food.addFact(NutriType.IRON, 0.009);
		food.setPortion(1, "serving", "serving");
		
		assertTrue(logic.calcDailyPercentage(food, NutriType.CALORIES, scale) == 100);
		assertTrue(logic.calcDailyPercentage(food, NutriType.FAT, scale) == 100);
		assertTrue(logic.calcDailyPercentage(food, NutriType.SATURATED_FAT, scale) == 100);

		assertTrue(logic.calcDailyPercentage(food, NutriType.CHOLESTEROL, scale) == 100);
		assertTrue(logic.calcDailyPercentage(food, NutriType.SODIUM, scale) == 100);
		assertTrue(logic.calcDailyPercentage(food, NutriType.CARBS, scale) == 100);
		assertTrue(logic.calcDailyPercentage(food, NutriType.FIBRE, scale) == 100);

		assertTrue(logic.calcDailyPercentage(food, NutriType.PROTEIN, scale) == 100);
		assertTrue(logic.calcDailyPercentage(food, NutriType.VITAMIN_A, scale) == 100);
		assertTrue(logic.calcDailyPercentage(food, NutriType.VITAMIN_C, scale) == 100);
		assertTrue(logic.calcDailyPercentage(food, NutriType.CALCIUM, scale) == 100);
		assertTrue(logic.calcDailyPercentage(food, NutriType.IRON, scale) == 100);	
		
		Services.closeDataAccess();
		
		System.out.println("Finished testScale");
	}
}
