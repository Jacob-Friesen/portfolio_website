package tests.logic;

import junit.framework.TestCase;
import nutri.logic.FilterLogic;
import nutri.objects.NutriFact;
import nutri.objects.NutriFilter;
import nutri.objects.NutriFilterList;
import nutri.objects.FoodItem;
import nutri.objects.FilterResult;
import nutri.objects.FilterResults;
import nutri.application.Services;
import nutri.enums.*;

public class FilterLogicTest extends TestCase {

	/**
	 * testing the evaluate filters function
	 */
	public void testEvaluateFilter()
	{
		System.out.println("\nStarting testEvaluateFilter");
		Services.createDataAccess("FOOD_TEST2");
		
		FilterLogic logic = new FilterLogic();
		NutriFact fact = new NutriFact(20);
		
		// test the less than operator
		NutriFilter filter = new NutriFilter(NutriType.FAT, OperatorType.LESS, 20, UnitType.GRAMS);
		assertFalse(logic.evaluateFilter(fact, filter));
		
		// test less than or equal to
		filter = new NutriFilter(NutriType.FAT, OperatorType.LESS_OR_EQUAL, 20, UnitType.GRAMS);
		assertTrue(logic.evaluateFilter(fact, filter));
		fact = new NutriFact(20.1);
		assertFalse(logic.evaluateFilter(fact, filter));
		fact = new NutriFact(19.9);
		assertTrue(logic.evaluateFilter(fact, filter));
		
		// test with milligrams, should do a conversion
		filter = new NutriFilter(NutriType.FAT, OperatorType.LESS_OR_EQUAL, 20000, UnitType.MILLIGRAMS);
		assertTrue(logic.evaluateFilter(fact, filter));
		filter = new NutriFilter(NutriType.FAT, OperatorType.LESS_OR_EQUAL, 20, UnitType.MILLIGRAMS);
		assertFalse(logic.evaluateFilter(fact, filter));
		
		Services.closeDataAccess();
		
		System.out.println("Finished testEvaluateFilter");
	}
	
	/**
	 * test any types that have unit type exceptions, like vitamin a and calories
	 */
	public void testEvalFilterExceptions()
	{
		System.out.println("\nStarting testEvalFilterExceptions");
		Services.createDataAccess("FOOD_TEST2");
		
		FilterLogic logic = new FilterLogic();
		NutriFact fact = new NutriFact(2000);
		
		// testing vitamin A
		NutriFilter filter = new NutriFilter(NutriType.VITAMIN_A, OperatorType.LESS, 2000, UnitType.GRAMS);
		assertFalse(logic.evaluateFilter(fact, filter));
		
		// testing calories
		filter = new NutriFilter(NutriType.CALORIES, OperatorType.GREATER, 2000, UnitType.GRAMS);
		assertFalse(logic.evaluateFilter(fact, filter));
		
		Services.closeDataAccess();
		
		System.out.println("Finished testEvalFilterExceptions");
	}
	
	/**
	 * test applying one filter and getting back a result set
	 */
	public void testApplyOneFilter()
	{
		System.out.println("\nStarting testApplyOneFilter");
		Services.createDataAccess("FOOD_TEST2");
		
		FilterLogic logic = new FilterLogic();
		FilterResults results = new FilterResults();
		FoodItem food = new FoodItem("Test Food", 200, "g");
		food.addFact(NutriType.FAT, 20);
		
		NutriFilterList filters = new NutriFilterList();
		filters.addFilter(new NutriFilter(NutriType.FAT, OperatorType.LESS, 20, UnitType.GRAMS));
		
		assertTrue(results.getFilterCalc() == 100);
		
		logic.applyFilters(food, filters, results);
		assertTrue(results.getFilterCalc() == 0);
		
		// pull out the result and check it
		FilterResult result = results.getResult(NutriType.FAT);
		
		assertNotNull(result);
		assertFalse(result.passed());
		
		Services.closeDataAccess();
		
		System.out.println("Finished testApplyOneFilter");
	}
}
