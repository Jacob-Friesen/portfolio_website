package tests.logic;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import junit.framework.TestCase;
import nutri.application.Services;
import nutri.enums.NutriType;
import nutri.logic.DailyPercentLogic;
import nutri.objects.NutriFacts;
import nutri.persistence.DataAccessStub;
import nutri.persistence.IDataAccess;

/**
 * Tests all possible interactions between Logic to Persistence
 */
public class LogicToPersistence extends TestCase 
{	
	/**
	 * Test getting and setting Daily intake from logic, tests 2
	 * way interaction because each get of daily intake queries the
	 * database
	 */
	public void testDailyIntakeLogic()
	{
		IDataAccess dataAccess = new DataAccessStub();
		
		System.out.println("\nStarting daily intake integration logic test (REAL)");
		Services.createDataAccess("FOOD_TEST2");
		dailyIntakeTest();
		Services.closeDataAccess();
		System.out.println("Ending daily intake integration logic test (REAL)");
		
		System.out.println("\nStarting daily intake integration logic test (STUB)");
		Services.changeDataAccess(dataAccess, "STUBDB");
		dailyIntakeTest();
		Services.closeDataAccess();
		System.out.println("Ending daily intake integration logic test (STUB)");
	}
	
	
	private void dailyIntakeTest()
	{
		DailyPercentLogic logic = new DailyPercentLogic();
		NutriFacts test1;
		NutriFacts test2;
		
		//set to default values and see if this still works
		logic.updateIntakeAmounts(logic.getDefaultIntakeAmounts());
		test1 = logic.getDefaultIntakeAmounts();
		test2 = logic.getIntakeAmounts();
		assertTrue(test1.getAmount(NutriType.CALORIES) == test2.getAmount(NutriType.CALORIES));
		assertTrue(test1.getAmount(NutriType.FAT) == test2.getAmount(NutriType.FAT));
		assertTrue(test1.getAmount(NutriType.SATURATED_FAT) == test2.getAmount(NutriType.SATURATED_FAT));
		assertTrue(test1.getAmount(NutriType.TRANS_FAT) == test2.getAmount(NutriType.TRANS_FAT));
		assertTrue(test1.getAmount(NutriType.CHOLESTEROL) == test2.getAmount(NutriType.CHOLESTEROL));
		assertTrue(test1.getAmount(NutriType.SODIUM) == test2.getAmount(NutriType.SODIUM));
		assertTrue(test1.getAmount(NutriType.CARBS) == test2.getAmount(NutriType.CARBS));
		assertTrue(test1.getAmount(NutriType.FIBRE) == test2.getAmount(NutriType.FIBRE));
		assertTrue(test1.getAmount(NutriType.SUGAR) == test2.getAmount(NutriType.SUGAR));
		assertTrue(test1.getAmount(NutriType.PROTEIN) == test2.getAmount(NutriType.PROTEIN));
		assertTrue(test1.getAmount(NutriType.VITAMIN_A) == test2.getAmount(NutriType.VITAMIN_A));
		assertTrue(test1.getAmount(NutriType.VITAMIN_C) == test2.getAmount(NutriType.VITAMIN_C));
		assertTrue(test1.getAmount(NutriType.CALCIUM) == test2.getAmount(NutriType.CALCIUM));
		assertTrue(test1.getAmount(NutriType.IRON) == test2.getAmount(NutriType.IRON));
		
		//set to null, should give default values, and see if it still works
		logic.updateIntakeAmounts(null);
		test1 = logic.getDefaultIntakeAmounts();
		test2 = logic.getIntakeAmounts();
		assertTrue(test1.getAmount(NutriType.CALORIES) == test2.getAmount(NutriType.CALORIES));
		assertTrue(test1.getAmount(NutriType.FAT) == test2.getAmount(NutriType.FAT));
		assertTrue(test1.getAmount(NutriType.SATURATED_FAT) == test2.getAmount(NutriType.SATURATED_FAT));
		assertTrue(test1.getAmount(NutriType.TRANS_FAT) == test2.getAmount(NutriType.TRANS_FAT));
		assertTrue(test1.getAmount(NutriType.CHOLESTEROL) == test2.getAmount(NutriType.CHOLESTEROL));
		assertTrue(test1.getAmount(NutriType.SODIUM) == test2.getAmount(NutriType.SODIUM));
		assertTrue(test1.getAmount(NutriType.CARBS) == test2.getAmount(NutriType.CARBS));
		assertTrue(test1.getAmount(NutriType.FIBRE) == test2.getAmount(NutriType.FIBRE));
		assertTrue(test1.getAmount(NutriType.SUGAR) == test2.getAmount(NutriType.SUGAR));
		assertTrue(test1.getAmount(NutriType.PROTEIN) == test2.getAmount(NutriType.PROTEIN));
		assertTrue(test1.getAmount(NutriType.VITAMIN_A) == test2.getAmount(NutriType.VITAMIN_A));
		assertTrue(test1.getAmount(NutriType.VITAMIN_C) == test2.getAmount(NutriType.VITAMIN_C));
		assertTrue(test1.getAmount(NutriType.CALCIUM) == test2.getAmount(NutriType.CALCIUM));
		assertTrue(test1.getAmount(NutriType.IRON) == test2.getAmount(NutriType.IRON));
		
		//now set all nutrifacts (in the Nutrifact object) to minimum int and see how this fares)
		test1.updateFact(NutriType.CALORIES, Double.MIN_VALUE);
		test1.updateFact(NutriType.FAT, Double.MIN_VALUE);
		test1.updateFact(NutriType.SATURATED_FAT, Double.MIN_VALUE);
		test1.updateFact(NutriType.TRANS_FAT, Double.MIN_VALUE);
		test1.updateFact(NutriType.CHOLESTEROL, Double.MIN_VALUE);
		test1.updateFact(NutriType.SODIUM, Double.MIN_VALUE);
		test1.updateFact(NutriType.CARBS, Double.MIN_VALUE);
		test1.updateFact(NutriType.FIBRE, Double.MIN_VALUE);
		test1.updateFact(NutriType.SUGAR, Double.MIN_VALUE);
		test1.updateFact(NutriType.PROTEIN, Double.MIN_VALUE);
		test1.updateFact(NutriType.VITAMIN_A, Double.MIN_VALUE);
		test1.updateFact(NutriType.VITAMIN_C, Double.MIN_VALUE);
		test1.updateFact(NutriType.CALORIES, Double.MIN_VALUE);
		test1.updateFact(NutriType.CALCIUM, Double.MIN_VALUE);
		test1.updateFact(NutriType.IRON, Double.MIN_VALUE);
		logic.updateIntakeAmounts(test1);
		
		test2 = logic.getIntakeAmounts();
		assertTrue(test1.getAmount(NutriType.CALORIES) == test2.getAmount(NutriType.CALORIES));
		assertTrue(test1.getAmount(NutriType.FAT) == test2.getAmount(NutriType.FAT));
		assertTrue(test1.getAmount(NutriType.SATURATED_FAT) == test2.getAmount(NutriType.SATURATED_FAT));
		assertTrue(test1.getAmount(NutriType.TRANS_FAT) == test2.getAmount(NutriType.TRANS_FAT));
		assertTrue(test1.getAmount(NutriType.CHOLESTEROL) == test2.getAmount(NutriType.CHOLESTEROL));
		assertTrue(test1.getAmount(NutriType.SODIUM) == test2.getAmount(NutriType.SODIUM));
		assertTrue(test1.getAmount(NutriType.CARBS) == test2.getAmount(NutriType.CARBS));
		assertTrue(test1.getAmount(NutriType.FIBRE) == test2.getAmount(NutriType.FIBRE));
		assertTrue(test1.getAmount(NutriType.SUGAR) == test2.getAmount(NutriType.SUGAR));
		assertTrue(test1.getAmount(NutriType.PROTEIN) == test2.getAmount(NutriType.PROTEIN));
		assertTrue(test1.getAmount(NutriType.VITAMIN_A) == test2.getAmount(NutriType.VITAMIN_A));
		assertTrue(test1.getAmount(NutriType.VITAMIN_C) == test2.getAmount(NutriType.VITAMIN_C));
		assertTrue(test1.getAmount(NutriType.CALCIUM) == test2.getAmount(NutriType.CALCIUM));
		assertTrue(test1.getAmount(NutriType.IRON) == test2.getAmount(NutriType.IRON));
	}
	
	/**
	 * All this does is resets the database, no tests
	 */
	public void testReset()
	{
		String lineFromBat;
		
		//get 3 directories up
		String projectLoc = LogicToPersistence.class.getResource("../../").getPath();
		projectLoc = projectLoc.replace("bin/","");
		projectLoc = projectLoc.replace("/","\\").substring(1);//also remove leading /
		projectLoc = projectLoc.replace("%20"," ") + "database";//convert space
		projectLoc += "\\RESTORE_TEST_DBS.bat";
		System.out.println(projectLoc);
		
		//execute the .bat file
		System.out.println("Restoring test databases...");
		try {
			Process process = Runtime.getRuntime().exec(projectLoc);
			
			BufferedReader stdInput = new BufferedReader(new 
            InputStreamReader(process.getInputStream()));

            // read the output from the command
            System.out.println("File output:\n");
            lineFromBat = stdInput.readLine();
            while (lineFromBat != null)
            {
                System.out.println(lineFromBat);
                lineFromBat = stdInput.readLine();
            }
            
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Done restoring test databases...");
	}
}
