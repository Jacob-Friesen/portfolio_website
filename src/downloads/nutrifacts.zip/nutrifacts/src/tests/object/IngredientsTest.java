package tests.object;

import java.util.ArrayList;
import java.util.Arrays;

import junit.framework.TestCase;
import nutri.objects.Ingredients;

public class IngredientsTest extends TestCase
{
	/**
	 * large test of ingredients
	 */
	public void testIngredients1()
	{		
		Ingredients ingredients;
		ArrayList<String> foods;

		String salt = "table salt", milk = "milk", butter = "butter";
		String ingredStr = "";

		System.out.println("\nStarting testIngredients1");

		// Testing with 1 item in the list
		ingredients = new Ingredients();
		assertNotNull(ingredients);

		foods = ingredients.getList();
		assertNotNull(foods);

		ingredients.add(salt);
		foods = ingredients.getList();
		assertTrue(foods.indexOf(salt) >= 0);
		assertTrue(foods.size() == 1);

		ingredStr = ingredients.toString();
		assertTrue(ingredStr.equals(salt));

		// Now adding multiple things to the list
		foods = new ArrayList<String>();
		foods.add(milk);
		foods.add(butter);

		ingredients.add(foods);
		assertTrue(ingredients.contains(salt));
		assertTrue(ingredients.contains(milk));
		assertTrue(ingredients.contains(butter));

		foods = ingredients.getList();
		assertTrue(foods.size() == 3);

		ingredStr = ingredients.toString();
		System.out.println("Here is a list of ingredients, it should contain butter, milk and salt.");
		System.out.println(ingredStr);

		System.out.println("Finished testIngredients1");
	}

	/**
	 * small test of ingredients
	 */
	public void testIngredients2()
	{
		Ingredients ingredients;
		ArrayList<String> foods;

		String salt = "table salt", milk = "milk", butter = "butter";
		String ingredStr = "";

		System.out.println("\nStarting testIngredients2");

		foods = new ArrayList<String>(Arrays.asList(salt, milk, butter));
		ingredients = new Ingredients(foods);
		assertNotNull(ingredients);

		foods = ingredients.getList();
		assertNotNull(foods);
		assertTrue(ingredients.contains(salt));
		assertTrue(ingredients.contains(milk));
		assertTrue(ingredients.contains(butter));
		assertTrue(foods.size() == 3);

		ingredStr = ingredients.toString();
		System.out.println("Here is a list of ingredients, it should contain butter, milk and salt.");
		System.out.println(ingredStr);

		System.out.println("Finished testIngredients2");
	}
}