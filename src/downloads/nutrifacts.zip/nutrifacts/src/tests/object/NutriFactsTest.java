package tests.object;

import java.util.HashMap;

import junit.framework.TestCase;
import nutri.objects.NutriFact;
import nutri.objects.NutriFacts;
import nutri.enums.NutriType;

public class NutriFactsTest extends TestCase
{

	/**
	 * Test fact amount value
	 */
	public void testNutriFact()
	{
		System.out.println("\nStarting testNutriFacts1");

		NutriFact fact = new NutriFact();

		double amount = 4.5435;
		//double dailyValue = 0.2345;

		assertNotNull(fact);
		assertTrue(fact.amount() == 0);

		fact.update(amount);
		assertTrue(fact.amount() == amount);

		fact = new NutriFact(amount);
		assertNotNull(fact);
		assertTrue(fact.amount() == amount);

		System.out.println("Finished testNutriFacts1");
	}

	/**
	 * Test all other elements of <code>NutriFact</code>s
	 */
	public void testNutriFacts2()
	{
		System.out.println("\nStarting testNutriFacts2");

		NutriFacts facts = new NutriFacts();
		assertNotNull(facts);

		for (NutriType type : NutriType.values())
		{
			assertNotNull(facts.getFact(type));
			assertNotNull(facts.getFactName(type));
		}

		NutriType calc = NutriType.CALCIUM;
		double calcAmount = 50;
		//double calcValue = .30;

		facts.updateFact(calc, calcAmount);
		assertTrue(facts.getAmount(calc) == calcAmount);
		assertTrue(facts.getFactName(calc).equals("calcium"));

		HashMap<NutriType, NutriFact> map = new HashMap<NutriType, NutriFact>();
		NutriType fat = NutriType.FAT, iron = NutriType.IRON;
		double fatAmount = 2300, ironAmount = 32;
		//double fatValue = 2.4, ironValue = .09;

		map.put(fat, new NutriFact(fatAmount));
		map.put(iron, new NutriFact(ironAmount));

		facts.updateFacts(map);
		assertTrue(facts.getAmount(calc) == calcAmount);
		assertTrue(facts.getAmount(fat) == fatAmount);
		assertTrue(facts.getAmount(iron) == ironAmount);

		map.put(calc, new NutriFact(calcAmount));
		facts = new NutriFacts(map);
		assertNotNull(facts);

		assertTrue(facts.getAmount(calc) == calcAmount);
		assertTrue(facts.getAmount(fat) == fatAmount);
		assertTrue(facts.getAmount(iron) == ironAmount);

		System.out.println("Finished testNutriFacts2");
	}
}