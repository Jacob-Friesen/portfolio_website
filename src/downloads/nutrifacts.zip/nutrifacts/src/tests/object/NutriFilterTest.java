package tests.object;

import nutri.enums.*;
import nutri.objects.NutriFilter;
import junit.framework.TestCase;

public class NutriFilterTest extends TestCase {
	
	protected NutriFilter filter;
	protected final NutriType NUTRI_TYPE = NutriType.CALORIES;
	protected final OperatorType OPERATOR = OperatorType.GREATER;
	protected final String VALUE_STR = "200";
	protected final int VALUE_INT = 200;
	protected final UnitType UNIT = UnitType.GRAMS;

	/**
	 * 3 different constructors so constructors must be tested. Does a basic
	 * test on each of the constructors.
	 */
	public void testConstructor()
	{
		System.out.println("\nStarting testConstructor");
		
		filter = new NutriFilter(null, null, 0, null);	// create an empty object
		assertNotNull(filter);
		
		filter = new NutriFilter(NUTRI_TYPE, OPERATOR, VALUE_INT, UNIT);
		assertNotNull(filter);
		assertTrue(filter.getNutriType().equals(NUTRI_TYPE));
		assertTrue(filter.getOperator().equals(OPERATOR));
		assertTrue(filter.getValue() == VALUE_INT);
		assertTrue(filter.getUnit().equals(UNIT));
		
		
		filter = new NutriFilter(NUTRI_TYPE,OPERATOR,VALUE_STR,UNIT);
		assertNotNull(filter);
		assertTrue(filter.getNutriType().equals(NUTRI_TYPE));
		assertTrue(filter.getOperator().equals(OPERATOR));
		assertTrue(filter.getValue() == VALUE_INT);
		assertTrue(filter.getUnit().equals(UNIT));
		
		filter = new NutriFilter(NUTRI_TYPE,OPERATOR,"not_int",UNIT);
		assertNotNull(filter);
		assertNotNull(filter.getValue() == -1);
		
		System.out.println("Finished testConstructor");
	}
	
	/**
	 * testing the less than operator of toString
	 */
	public void testToStringLessThan()
	{
		System.out.println("\nStarting testToStringLessThan");
		
		filter = new NutriFilter(NutriType.FAT, OperatorType.LESS, 20, UnitType.GRAMS);
		assertTrue(filter.toString(),filter.toString().equals("@Total Fat < 20 g"));
		
		System.out.println("Finished testToStringLessThan");
	}
	
	/**
	 * testing the less or equal than operator of toString
	 */
	public void testToStringLessThanEqual()
	{
		System.out.println("\nStarting testToStringLessThanEqual");
		
		filter = new NutriFilter(NutriType.PROTEIN, OperatorType.LESS_OR_EQUAL, 20, UnitType.GRAMS);
		assertTrue(filter.toString(),filter.toString().equals("@Protein <= 20 g"));
		
		System.out.println("Finished testToStringLessThanEqual");
	}	
	
	/**
	 * testing the setActive flag of filters
	 */
	public void testToStringSetActive()
	{
		System.out.println("\nStarting testToStringSetActive");
		
		filter = new NutriFilter(NutriType.FAT, OperatorType.LESS, 20, UnitType.GRAMS);
		filter.setActive(true);
		assertTrue(filter.toString().equals("@Total Fat < 20 g"));
		filter.setActive(false);	
		assertTrue(filter.toString().equals("Total Fat < 20 g"));
		
		System.out.println("Finished testToStringSetActive");
	}

	/**
	 * testing the toString of calories, as it's an exception
	 */
	public void testToStringCalories()
	{
		System.out.println("\nStarting testLoadandConstructor");
		
		filter = new NutriFilter(NutriType.CALORIES, OperatorType.GREATER, 200, UnitType.GRAMS);
		assertTrue(filter.toString().equals("@Calories > 200"));
		
		System.out.println("Finished testToStringCalories");
	}
	
	/**
	 * testing the toString of vitamin a, as it's an exception
	 */
	public void testToStringVitaminA()
	{
		System.out.println("\nStarting testToStringVitaminA");
		
		filter = new NutriFilter(NutriType.VITAMIN_A, OperatorType.GREATER, 1000, UnitType.GRAMS);
		assertTrue(filter.toString().equals("@Vitamin A > 1000 iu"));
		
		System.out.println("Finished testToStringVitaminA");
	}
}
