package tests.object;

import junit.framework.TestCase;
import nutri.objects.Rational;

public class RationalTest extends TestCase {

	/**
	 * Tests various double to rational number
	 * conversions.
	 */
	public void testRational()
	{
		System.out.println("\nTesting Rational Class.");
		
		//generic cases
		Rational r = new Rational(1);
		assertTrue(r.toString().equals("1"));
		r = new Rational(0.5);
		assertTrue(r.toString().equals("1/2"));
		r = new Rational(2.0);
		assertTrue(r.toString().equals("2"));
		r = new Rational(1.5);
		assertTrue(r.toString().equals("1 1/2"));
		r = new Rational(1.8);
		assertTrue(r.toString().equals("1 4/5"));
		
		//boundary and too many decimal positive cases
		r = new Rational(0);
		assertTrue(r.toString().equals("0"));
		r = new Rational(10);
		assertTrue(r.toString().equals("10"));
		r = new Rational(9.75);
		assertTrue(r.toString().equals("9 4/5"));
		r = new Rational(9.74);
		assertTrue(r.toString().equals("9 3/5"));
		r = new Rational(9.99999999999999999);
		assertTrue(r.toString().equals("10"));
		
		//negative cases
		r = new Rational(-9.99999999999999999);
		assertTrue(r.toString().equals("10"));
		r = new Rational(-10);
		assertTrue(r.toString().equals("10"));
		
		System.out.println("Finished Rational Class Tests.");
	}
}
