package tests.object;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import junit.framework.TestCase;
import nutri.enums.NutriType;
import nutri.objects.FoodItem;
import nutri.objects.NutriFact;
import nutri.objects.NutriFacts;

public class FoodItemTest extends TestCase
{
	protected final int MAX_RATING = 5;

	/**
	 * test facts, portions servings and comparisons between them. Also
	 * tests rating.
	 */
	public void testFoodItem1()
	{
		System.out.println("\nStarting testFoodItem1");
		
		FoodItem product = new FoodItem("Kit Kat Bar", 42, "g");
		FoodItem product2;

		assertNotNull(product);
		assertTrue(product.getRating() == -1);
		assertNotNull(product.getIngredients());
		
		//ingredient testing
		ArrayList<String> ingredients = new ArrayList<String>(Arrays.asList("Milk Chocolate", "Cocoa", "Butter", "Unsweetened Chocolate", "Lactoce", "Soya Lecithin", "Polyglycerol",
				"Polyricinoleate", "Wheat Flour", "Sugar", "Hydrogenated Soybean Oil or Modified Palm Oil", "Artificial Flavour"));

		product.addIngredients(ingredients);
		assertTrue(product.containsIngredient("Wheat Flour"));

		product.addFact(NutriType.CALORIES, 218);
		product.addFact(NutriType.FAT, 11);
		product.addFact(NutriType.SATURATED_FAT, 8);
		product.addFact(NutriType.TRANS_FAT, 0);
		product.addFact(NutriType.CHOLESTEROL, 0.005);
		product.addFact(NutriType.SODIUM, 0.023);
		product.addFact(NutriType.CARBS, 27);
		product.addFact(NutriType.FIBRE, 0);
		product.addFact(NutriType.SUGAR, 20);
		product.addFact(NutriType.PROTEIN, 3);
		product.addFact(NutriType.VITAMIN_A, 0.01);
		product.addFact(NutriType.VITAMIN_C, 0);
		product.addFact(NutriType.CALCIUM, 0.05);
		assertTrue(product.getFact(NutriType.CALCIUM).amount() == 0.05);
		product.addFact(NutriType.IRON, 0.02);
		assertTrue(product.getFact(NutriType.IRON).amount() == 0.02);

		product.setPortion(1, "bar", "barre");

		assertTrue(product.getName().equals("Kit Kat Bar"));
		assertTrue(product.getPortionSize() == 1);
		assertTrue(product.getServingSize() == 42);

		product.addFact(NutriType.CALCIUM, .80);
		assertTrue(product.getFact(NutriType.CALCIUM).amount() == 0.80);
		assertTrue(product.getAmount(NutriType.CALCIUM, 1) == .80);
		
		assertTrue(product.getRating() == -1);
		product.setRating(5);
		assertTrue(product.getRating() == 5);
		product.setRating(7);
		assertTrue(product.getRating() == 5);
		
		//compareTo test
		product2 = product;
		assertTrue(product.compareTo(product2) == 0);
		product2 = new FoodItem("", 42, "g");
		assertTrue(product.compareTo(product2) != 0);
		product2 = new FoodItem("kit kat", 42, "g");
		assertTrue(product.compareTo(product2) != 0);
		product2 = new FoodItem("kit kat bar", 42, "g");//notice this is lower case
		assertTrue(product.compareTo(product2) != 0);
		product2 = new FoodItem("Kit Kat Bar", 42, "g");
		assertTrue(product.compareTo(product2) == 0);
		
		//just making sure rating wasn't modified
		assertTrue(product.getRating() == 5);

		System.out.println("Finished testFoodItem1");
	}

	/**
	 * test facts, portions servings with a focus on ingredients. Also
	 * tests rating.
	 */
	public void testFoodItem2()
	{
		System.out.println("\nStarting testFoodItem2");

		FoodItem product;
		FoodItem product2;
		NutriFacts facts = new NutriFacts();

		ArrayList<String> ingredients = new ArrayList<String>(Arrays.asList("Milk Chocolate", "Cocoa", "Butter", "Unsweetened Chocolate", "Lactoce", "Soya Lecithin", "Polyglycerol",
				"Polyricinoleate", "Wheat Flour", "Sugar", "Hydrogenated Soybean Oil or Modified Palm Oil", "Artificial Flavour"));

		HashMap<NutriType, NutriFact> factsMap = new HashMap<NutriType, NutriFact>();

		for (NutriType type : NutriType.values())
		{
			factsMap.put(type, new NutriFact(0.6));
		}

		facts.updateFacts(factsMap);

		product = new FoodItem("Kit Kat Bar", 42, "g", facts, ingredients);
		assertTrue(product.getRating() == -1);
		assertNotNull(product);
		assertNotNull(product.getIngredients());
		assertNotNull(product.getFacts());

		assertTrue(product.getPortionSize() == 1.0);
		product.setPortion(2, "bar", "barre");
		assertTrue(product.getPortionSize() == 2);

		assertTrue(product.containsIngredient("Cocoa"));
		assertEquals(product.getServingUnits(), "g");
		
		//test getIngredientsString 
		assertTrue(product.getIngredientsString().equals(ingredients.toString().replaceAll("\\[","").replaceAll("\\]","")));
		
		//test addIngredients
		product2 = new FoodItem("Kit Kat Bar", 42, "g");
		product2.addIngredient("Milk Chocolate");
		product2.addIngredient("Cocoa");
		product2.addIngredient("Butter");
		product2.addIngredient("Unsweetened Chocolate");
		product2.addIngredient("Lactoce");
		product2.addIngredient("Soya Lecithin");
		product2.addIngredient("Polyglycerol");
		product2.addIngredient("Polyricinoleate");
		product2.addIngredient("Wheat Flour");
		product2.addIngredient("Sugar");
		product2.addIngredient("Hydrogenated Soybean Oil or Modified Palm Oil");
		product2.addIngredient("Artificial Flavour");
		assertTrue(product2.getIngredientsString().equals(product.getIngredientsString()));
		
		//test get portion string
		assertTrue(product.getPortionString(1).equals("Per 2 bar (42 g) / par 2 barre (42 g)"));
		
		//test ratings
		assertTrue(product.getRating() == -1);
		product.setRating(-1);
		assertTrue(product.getRating() == -1);
		product.setRating(-12);
		assertTrue(product.getRating() == -1);
		
		//test get portion type french or english
		product.setPortion(1, "food", "fd");
		assertTrue(product.getPortionTypeEn().equals("food"));
		assertTrue(product.getPortionTypeFr().equals("fd"));
		product.setPortion(1, null, "fd");
		assertTrue(product.getPortionTypeEn() == null);
		assertTrue(product.getPortionTypeFr().equals("fd"));
		product.setPortion(1, "fd", null);
		assertTrue(product.getPortionTypeEn().equals("fd"));
		assertTrue(product.getPortionTypeFr() == null);
		
		assertTrue(product.getRating() == -1);

		System.out.println("Finished testFoodItem2");
	}
}
