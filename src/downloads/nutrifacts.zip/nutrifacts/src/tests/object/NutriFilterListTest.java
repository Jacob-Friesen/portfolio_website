package tests.object;

import junit.framework.TestCase;
import nutri.objects.NutriFilter;
import nutri.objects.NutriFilterList;
import nutri.persistence.IDataAccess;
import nutri.application.Services;
import nutri.enums.*;

public class NutriFilterListTest extends TestCase{
	protected IDataAccess dataAccess;
	protected NutriFilterList nutriFilters;
	protected final NutriFilter FILTER = new NutriFilter(
			NutriType.CALORIES, OperatorType.GREATER,"370", UnitType.GRAMS);
	protected final NutriFilter FILTER2 = new NutriFilter(
			NutriType.CALORIES, OperatorType.GREATER,"10,000", UnitType.GRAMS);
	protected final NutriFilter FILTER_DEL = new NutriFilter(
			NutriType.CALORIES, OperatorType.GREATER,"10,000", UnitType.GRAMS);
	
	/**
	 * Test adding and deleting filters
	 */
	public void testModifications()
	{
		System.out.println("\nStarting testModifications");
		
		Services.createDataAccess("FOOD_TEST2");
		dataAccess = Services.getDataAccess();
		nutriFilters = new NutriFilterList();
		
		nutriFilters.addFilter(FILTER);
		assertTrue(nutriFilters.getAllFilters().size() == 1);
		assertTrue(nutriFilters.getAllFilters().get(0) == FILTER);
		
		nutriFilters.addFilter(null);
		assertTrue(nutriFilters.getAllFilters().size() == 1);
		
		nutriFilters.addFilter(FILTER2);
		assertTrue(nutriFilters.getAllFilters().size() == 2);
		assertTrue(nutriFilters.getAllFilters().get(1) == FILTER2);
		
		nutriFilters.deleteFilter(null);
		assertTrue(nutriFilters.getAllFilters().size() == 2);
		nutriFilters.deleteFilter(FILTER_DEL);
		assertTrue(nutriFilters.getAllFilters().size() == 2);
		
		nutriFilters.deleteFilter(FILTER);
		assertTrue(nutriFilters.getAllFilters().size() == 1);
		assertTrue(nutriFilters.getAllFilters().get(0) == FILTER2);
		nutriFilters.deleteFilter(FILTER2);
		assertTrue(nutriFilters.getAllFilters().size() == 0);
		
		nutriFilters.deleteFilter(FILTER_DEL);
		assertTrue(nutriFilters.getAllFilters().size() == 0);
		
		Services.closeDataAccess();
		
		System.out.println("Finished testModifications");
	}
	
	/**
	 * Test updating the filters
	 */
	public void updateTest()
	{
		System.out.println("\nStarting updateTest");
		
		Services.createDataAccess("FOOD_TEST2");
		dataAccess = Services.getDataAccess();
		nutriFilters = new NutriFilterList();
		
		nutriFilters.addFilter(FILTER);
		assertTrue(nutriFilters.getAllFilters().size() == 1);
		assertTrue(nutriFilters.getAllFilters().get(0) == FILTER);
		
		nutriFilters.updateFilter(0, FILTER2);
		assertTrue(nutriFilters.getAllFilters().size() == 1);
		assertTrue(nutriFilters.getAllFilters().get(0) == FILTER2);
		
		nutriFilters.updateFilter(1, FILTER);
		assertTrue(nutriFilters.getAllFilters().size() == 1);
		assertTrue(nutriFilters.getAllFilters().get(0) == FILTER2);
		
		nutriFilters.updateFilter(0, null);
		assertTrue(nutriFilters.getAllFilters().size() == 1);
		assertTrue(nutriFilters.getAllFilters().get(0) == FILTER2);
		
		//make sure the null or incorrect position add didn't screw anything up
		nutriFilters.updateFilter(0, FILTER);
		assertTrue(nutriFilters.getAllFilters().size() == 1);
		assertTrue(nutriFilters.getAllFilters().get(0) == FILTER);
		
		Services.closeDataAccess();
		
		System.out.println("Finished updateTest");
	}
}
