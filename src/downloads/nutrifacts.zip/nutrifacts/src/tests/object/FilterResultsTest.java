package tests.object;

import junit.framework.TestCase;
import nutri.objects.FilterResults;
import nutri.objects.FilterResult;
import nutri.enums.*;

public class FilterResultsTest extends TestCase {

	/**
	 * test a completely empty result set, no filters were specified
	 */
	public void testEmptyResult()
	{
		System.out.println("\nStarting testEmptyResult");
		
		FilterResults results = new FilterResults();
		
		assertNotNull(results);
		assertTrue(results.getFilterCalc() == 100);
		assertNull(results.getResult(NutriType.FAT));
		assertNull(results.getResult(NutriType.PROTEIN));	
		
		System.out.println("Finished testEmptyResult");
	}
	
	/**
	 * test the pass/fail methods and the score calculation
	 */
	public void testScoreCalculation()
	{
		System.out.println("\nStarting testScoreCalculation");
		
		FilterResults results = new FilterResults();
		
		assertTrue(results.getFilterCalc() == 100);
		results.pass();
		assertTrue(results.getFilterCalc() == 100);
		results.pass();
		assertTrue(results.getFilterCalc() == 100);
		
		results = new FilterResults();
		results.fail();
		assertTrue(results.getFilterCalc() == 0);
		results.fail();
		assertTrue(results.getFilterCalc() == 0);
		results.pass();
		results.pass();
		assertTrue(results.getFilterCalc() == 50);
		
		System.out.println("Finished testScoreCalculation");
	}
	
	/**
	 * test updating the results, and retrieving results
	 * testing accessing elements in the result, are tested
	 * in FilterResultTest
	 */
	public void testUpdateResult()
	{
		System.out.println("\nStarting testUpdateResult");
		
		FilterResults results = new FilterResults();
		
		results.updateResult(NutriType.FAT, new FilterResult());
		assertNotNull(results.getResult(NutriType.FAT));
		assertNull(results.getResult(NutriType.PROTEIN));
		
		System.out.println("Finished testUpdateResult");
	}
}
