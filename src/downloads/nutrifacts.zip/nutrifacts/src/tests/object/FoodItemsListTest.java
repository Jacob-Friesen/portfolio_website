package tests.object;

import java.util.ArrayList;
import java.util.Arrays;

import nutri.objects.FoodItem;
import nutri.objects.FoodItemList;
import junit.framework.TestCase;

public class FoodItemsListTest extends TestCase{
	
	protected final String TEST_PRODUCT = "Test Cereal";
	protected final ArrayList<String> INGREDIENTS = new ArrayList<String>(Arrays.asList("Sugar", "Whole grain corn flour", "Wheat flour"));
	protected FoodItemList itemList;
	protected FoodItem food;
	
	/**
	 * Doesn't test ingredient or food item adds just tests if an item
	 * was inserted and if its gettable.
	 */
	public void testAddAndGet()
	{
		System.out.println("\nStarting testAddAndGet");
		
		FoodItem food2 = null;
		
		itemList = new FoodItemList();
		
		food = new FoodItem(TEST_PRODUCT, 33, "g");
		
		itemList.addFood(food);
		assertTrue(itemList.getFoodList().size() == 1);
		
		food2 = itemList.getFoodItem(TEST_PRODUCT);
		assertTrue(itemList.getFoodList().size() == 1);
		assertTrue(food2 != null);
		assertTrue(food2 == food);
		
		System.out.println("Finished testAddAndGet");
	}
	
	/**
	 * Tests food item getting and setting ingredients
	 */
	public void testGetIngredients()
	{
		System.out.println("\nStarting testGetIngredients");
		
		String ingredients = null;
		String[] ingrSplit;
		int count = 0;
		
		itemList = new FoodItemList();
		
		food = new FoodItem(TEST_PRODUCT, 33, "g");
		food.addIngredients(INGREDIENTS);
		
		itemList.addFood(food);//add tested above
		
		ingredients = food.getIngredientsString();
		assertTrue(ingredients != null);
		
		//keep in mind a double for each would not test order
		ingrSplit = ingredients.split(",");
		for (String ingredient : INGREDIENTS)
		{
			assertTrue(ingrSplit.length > count);
			assertTrue(ingrSplit[count].trim().equals(ingredient));
			count++;
		}
		
		System.out.println("Finished testGetIngredients");
	}
}
