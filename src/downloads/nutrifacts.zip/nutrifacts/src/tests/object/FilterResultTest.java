package tests.object;

import junit.framework.TestCase;
import nutri.objects.FilterResult;

public class FilterResultTest extends TestCase {
	
	/**
	 * test getters and setters of the fail method
	 */
	public void testFail()
	{
		System.out.println("\nStarting testFail");
		
		FilterResult result = new FilterResult();
		assertTrue(result.passed());
		result.fail();
		assertTrue(!result.passed());
		result.fail();
		assertTrue(!result.passed());		// two wrongs don't make a right
		
		System.out.println("Finished testFail");
	}
	
	/**
	 * test the storage of filters that failed as a string
	 * and their retrieval
	 */
	public void testGetFails()
	{
		System.out.println("\nStarting testGetFails");
		
		FilterResult result = new FilterResult();
		assertTrue(result.getFails().equals("Fact failed on:\n"));
		result.addFilterString("test failed");
		assertTrue(result.getFails().equals("Fact failed on:\ntest failed\n"));
		result.addFilterString("test 2 failed");
		assertTrue(result.getFails().equals("Fact failed on:\ntest failed\ntest 2 failed\n"));
		
		System.out.println("Finished testGetFails");
	}
}
