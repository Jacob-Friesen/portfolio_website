package tests.object;

import nutri.objects.IngredientFilters;
import junit.framework.TestCase;

public class IngredientFiltersTest extends TestCase
{

	protected IngredientFilters ingredientHandler;
	//the empty ingredient is intentional
	protected final String[] TEST_INGS = {"jacofruit","Lard","Sugar","More Lard,Chocolate","^[[A","","Even more lard!"};
	protected final String OTHER = "other";
	protected int ingrLength;
	
	/**
	 * Add a bunch of data and test if it all added correctly
	 */
	public void testAdd()
	{
		System.out.println("\nStarting testAdd");
		
		int count = 0;
		
		ingredientHandler = new IngredientFilters();
		ingrLength = 0;
		
		for(String ingredient : TEST_INGS)
		{
			assertTrue(ingredientHandler.getAllIngredients().size() == count);
			ingredientHandler.addIngredient(ingredient);
			
			count++;
		}
		
		count = 0;
		for(String ingredient : ingredientHandler.getAllIngredients())
		{
			assertTrue(ingredient.equals(TEST_INGS[count]));
			count++;
		}
		ingrLength = count;
		
		ingredientHandler.addIngredient(null);
		assertTrue(ingredientHandler.getAllIngredients().size() == ingrLength);
		ingredientHandler.addIngredient(OTHER);
		assertTrue(ingredientHandler.getAllIngredients().size() == ingrLength + 1);
		ingrLength++;
		
		System.out.println("Finished testAdd");
	}
	
	/**
	 * Add a bunch of data then delete it one by one to see if it deleted correctly
	 */
	public void testDelete()
	{
		System.out.println("\nStarting testDelete");
		
		ingredientHandler = new IngredientFilters();
		ingrLength = 0;
		
		for(String ingredient : TEST_INGS)
		{
			ingredientHandler.addIngredient(ingredient);
			ingrLength++;
		}
		ingredientHandler.addIngredient(OTHER);
		ingrLength++;
		
		ingredientHandler.deleteIngredient(null);
		assertTrue(ingredientHandler.getAllIngredients().size() == ingrLength);
		ingredientHandler.deleteIngredient(OTHER);
		assertTrue(ingredientHandler.getAllIngredients().size() == ingrLength - 1);
		ingrLength --;
		
		for (String ingredient : TEST_INGS)
		{
			ingredientHandler.deleteIngredient(ingredient);
			assertTrue(ingredientHandler.getAllIngredients().size() == ingrLength - 1);
			ingrLength--;
		}
		
		assertTrue(ingredientHandler.getAllIngredients().size() == 0);
		ingredientHandler.deleteIngredient("any");
		assertTrue(ingredientHandler.getAllIngredients().size() == 0);
		
		System.out.println("Finished testDelete");
	}
}
