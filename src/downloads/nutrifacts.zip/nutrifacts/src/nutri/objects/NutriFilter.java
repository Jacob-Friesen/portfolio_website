package nutri.objects;

import nutri.enums.*;		// import all the enums

/**
 * Stores a single filter with is its nutrient type
 * its operator, unit and value.
 */
public class NutriFilter 
{	
	private int databaseID;
	private NutriType nutriType;
	private OperatorType operator;
	private UnitType unit;
	private double value;			// units in grams
	private boolean active;

	public final static String[] NutriNames = {"Calories", "Total Fat", "Saturated Fat", 
		"Trans Fat", "Cholesterol", "Sodium", "Total Carbohydrate", "Dietary Fibre", "Sugars", "Protein", "Vitamin A",
		"Vitamin C", "Calcium", "Iron"};
	
	public final static String[] OperatorTypes = {"<", "<=", ">", ">="};
	public final static String[] UnitTypes = {"g", "mg"};
	
	/**
	 * Converts String value to integer value
	 */
	public NutriFilter(NutriType nutriType, OperatorType operator, String value, UnitType unit)
	{
		this(nutriType, operator, convertDouble(value), unit);
	}
	
	public NutriFilter(NutriType nutriType, OperatorType operator, double value, UnitType unit)
	{
		this.nutriType = nutriType;
		this.operator = operator;
		this.value = value;
		this.unit = unit;
		active = true;		// defaults true
		
		//not in db yet
		databaseID = -1;
	}
	
	/**
	 * create a filter from the database
	 * an id (primary key in db) is passed
	 */
	public NutriFilter(int databaseID, NutriType nutriType, OperatorType operator, double value, UnitType unit)
	{
		this(nutriType, operator, value, unit);
		this.databaseID = databaseID;
	}
	
	/**
	 * convert a string to a double value
	 * 
	 * @param value the string value
	 * @return converted double value
	 */
	private static double convertDouble(String value)
	{
		double valueDbl = -1;
		
		try {
			valueDbl = Double.parseDouble(value);
		}
		catch (NumberFormatException e)
		{
			e.getCause();
		}
		
		return valueDbl;
	}

	/**
	 * @param nutriType to set
	 */
	public void setNutriType(NutriType nutriType) 
	{
		this.nutriType = nutriType;
	}

	/**
	 * @return nutriType to get
	 */
	public NutriType getNutriType() 
	{
		return nutriType;
	}

	/**
	 * @param operator to set
	 */
	public void setOperator(OperatorType operator) 
	{
		this.operator = operator;
	}

	/**
	 * @return operator to get
	 */
	public OperatorType getOperator() 
	{
		return operator;
	}
	
	/**
	 * @param value to set
	 */
	public void setValue(int value) 
	{
		this.value = value;
	}

	/**
	 * @return value to get
	 */
	public double getValue() 
	{
		return value;
	}
	
	/**
	 * @param unit type to set
	 */
	public void setUnit(UnitType unit) 
	{
		this.unit = unit;
	}

	/**
	 * @return unit type to get
	 */
	public UnitType getUnit() 
	{
		return unit;
	}

	/**
	 * @param active set whether this filter is active in the GUI
	 */
	public void setActive(boolean active) 
	{
		this.active = active;
	}

	/**
	 * @return whether this filter is active in the GUI
	 */
	public boolean isActive() 
	{
		return active;
	}
	
	/**
	 * called when a filter is inserted to the database
	 * gets and sets the id that was assigned by the db
	 * 
	 * @param value int value of the filter
	 */
	public void setDatabaseID(int value)
	{
		this.databaseID = value;
	}
	
	/**
	 * get the database id of this object
	 * 
	 * @return an int value of the id
	 */
	public int getDatabaseID()
	{
		// database ID will be -1 if not in DB
		// unique primary key otherwise
		return this.databaseID;
	}
	
	/**
	 * returns the string representation of this object
	 * 
	 * @return string representation of this object
	 */
	public String toString()
	{
		String result = "";
		
		if (active)
			result += "@";
		
		result += NutriNames[nutriType.ordinal()];
		result += " " + OperatorTypes[operator.ordinal()];
		
		// clean up the decimals
		if (value % 1 > 0)
			result += " " + value;
		else
			result += " " + (int)(value);
		
		// display some specific unit types
		if (nutriType == NutriType.VITAMIN_A)
			result += " " + "iu";
		else if (nutriType != NutriType.CALORIES)	// calories have no unit type
			result += " " + UnitTypes[unit.ordinal()];
		
		return result;
	}
}
