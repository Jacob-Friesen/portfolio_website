package nutri.objects;

import java.util.ArrayList;

/**
 * Manages a list of ingredients in string form
 */
public class IngredientFilters 
{
	private ArrayList<String> ingredients;
	
	public IngredientFilters()
	{
		ingredients = new ArrayList<String>();
	}
	
	/**
	 * adds an ingredient
	 * 
	 * @param ingredient ingredient to be added
	 */
	public void addIngredient(String ingredient)
	{
		if (ingredient != null)
			ingredients.add(ingredient);
	}
	
	/**
	 * deletes an ingredient
	 * 
	 * @param ingredient to be deleted
	 */
	public void deleteIngredient(String ingredient)
	{
		if (!ingredients.isEmpty() && ingredient != null)
			ingredients.remove(ingredient);
	}
	
	/**
	 * returns all of the ingredients
	 * 
	 * @return all of the ingredients
	 */
	public ArrayList<String> getAllIngredients()
	{
		return ingredients;
	}
	
	/**
	 * gets the number of ingredients
	 * 
	 * @return number of ingredients
	 */
	public int size()
	{
		return ingredients.size();
	}
	
	/**
	 * get ingredient at specified index
	 * 
	 * @param index location of ingredient
	 * @return ingredient at index
	 */
	public String get(int index)
	{
		return ingredients.get(index);
	}
	
	/**
	 * checks if the ingredient is stored in this object
	 * 
	 * @param ingredient to search for
	 * @return true if the string is in this object
	 */
	public boolean contains(String ingredient)
	{
		return ingredients.contains(ingredient);
	}
}
