package nutri.objects;

import java.util.ArrayList;

/**
 * Stores a list of <code>NutriFilter</code>s and how to manage them
 */
public class NutriFilterList 
{
	ArrayList<NutriFilter> filters;
	
	public NutriFilterList()
	{
		filters = new ArrayList<NutriFilter>();
	}
	/**
	 * adds a filter
	 * 
	 * @param filter to add
	 */
	public void addFilter(NutriFilter filter)
	{
		if (filter != null)
			filters.add(filter);
	}
	
	/**
	 * deletes a filter
	 * 
	 * @param filter to delete
	 */
	public void deleteFilter(NutriFilter filter)
	{
		if (filter != null)
			filters.remove(filter);
	}
	
	/**
	 * gets the filter at the specified location
	 * 
	 * @param index location to get the filter at
	 * @param <code>NutriFilter</code> at index
	 */
	public NutriFilter getFilter(int index)
	{
		return filters.get(index);
	}
	
	/**
	 * gets the list of filters
	 * 
	 * @return list of filters
	 */
	public ArrayList<NutriFilter> getAllFilters()
	{
		return filters;
	}
	
	/**
	 * changes the filter at index to the filter sent in
	 * 
	 * @param index of filter to replace
	 * @param fitler to replace filter at index with
	 */
	public void updateFilter(int index, NutriFilter filter)
	{
		if(filter != null && filters.size() > index)
			filters.set(index, filter);
	}

	/**
	 * returns the number of filters currently stored
	 * 
	 * @return number of filters currently stored
	 */
	public int size()
	{
		return filters.size();
	}
	
	/**
	 * gets the index of a specified filter
	 * 
	 * @param filter to finde index of
	 * @return index of specified filter
	 */
	public int indexOf(NutriFilter filter)
	{
		int count = 0;
		int found = -1;
		
		//must search for a string
		for (NutriFilter thisFilter : filters)
		{
			if(thisFilter.toString().equals(filter.toString()))
			{
				found = count;
				break;
			}
			count++;
		}
		
		return found;
	}
}
