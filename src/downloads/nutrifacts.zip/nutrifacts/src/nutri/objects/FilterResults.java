package nutri.objects;

import java.util.HashMap;
import java.util.Set;

import nutri.enums.*;
import nutri.objects.FilterResult;

/**
 * This class stores the complete collection of the results of filtering
 * a food item.
 */
public class FilterResults
{
	private HashMap<NutriType, FilterResult> results;
	private Set<String> ingredientResults;
	
	// keep track of passes and fails
	int pass;
	int fail;
	
	public FilterResults()
	{
		this.results = new HashMap<NutriType, FilterResult>();
		
		this.pass = 0;
		this.fail = 0;
	}

	/**
	 * update the <code>nutriType</code> result
	 * 
	 * @param name the nutritype
	 * @param result the filter result object
	 */
	public void updateResult(NutriType name, FilterResult result)
	{
		results.put(name, result);
	}
	
	/**
	 * update the ingredient filters result
	 * 
	 * @param ingredient to update the ingredient results with
	 */
	public void filterIngredient(String ingredient)
	{
		ingredientResults.add(ingredient);
	}

	/**
	 * return the result of a filter
	 * 
	 * @param name the name of the <code>nutriType</code>
	 * @return the result object
	 */
	public FilterResult getResult(NutriType name)
	{
		return results.get(name);
	}
	
	/**
	 * check if an ingredient exists in the filters
	 * 
	 * @param ingredient the ingredient string
	 * @return true if the ingredient exists in the filters
	 */
	public boolean checkIngredient(String ingredient)
	{
		return (ingredientResults.contains(ingredient));
	}
	
	/**
	 * pass/fail increment methods
	 */
	public void pass()
	{
		pass++;
	}
	public void fail() 
	{
		fail++;
	}
	
	/**
	 * calculates and returns a percentage of how well the filters
	 * fit the food item.  may need some tweaking
	 * 
	 * @return an <code>int</code>, of the percentage of filters that applied
	 */
	public int getFilterCalc()
	{
		int result = 100;
		
		if (pass > 0 || fail > 0)	// if there are filters to apply, calculate them
			result = (int)Math.round(((float)pass / ((float)pass + (float)fail)) * 100);
		
		return result;
	}
}