package nutri.objects;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Stores a list of <code>FoodItem</code>s.
 */

public class FoodItemList 
{

	private ArrayList<FoodItem> foodItems;
	
	public FoodItemList()
	{
		foodItems = new ArrayList<FoodItem>();
	}
	
	public FoodItemList(Collection<FoodItem> c)
	{
		foodItems = new ArrayList<FoodItem>(c);
	}
	
	/**
	 * Adds a food item to the end of the list
	 * 
	 * @param food the food item to add
	 */
	public void addFood(FoodItem food)
	{
		foodItems.add(food);
	}
	
	/**
	 * Removes a food item from the list
	 * 
	 * @param food: the food item to remove
	 */
	public void removeFood(FoodItem food)
	{
		foodItems.remove(getFoodItem(food.getName()));
	}
	
	/**
	 * returns a FoodItem object from the list of food items
	 * 
	 * @param productName the name of the <code>FoodItem</code> to be returned
	 * @return a <code>FoodItem</code>, if not found <code>null</code>
	 */
	public FoodItem getFoodItem(String productName)
	{
		FoodItem found = null;

		for(FoodItem food : foodItems)
		{
			if (food.getName().equals(productName))
			{
				found = food;
				break;
			}
		}
		
		return found;
	}
	
	/**
	 * returns the stored <code>FoodItem</code>s list
	 * 
	 * @return an <code>ArrayList<code> of <code>FoodItem</code>s
	 */
	public ArrayList<FoodItem> getFoodList()
	{
		return foodItems;
	}
	
	/**
	 * a simple iterator
	 * 
	 * @param i: index of food item
	 * @return: a fooditem
	 */
	public FoodItem get(int i)
	{
		return foodItems.get(i);
	}
	
	/**
	 * get the size of the foodlist
	 * 
	 * @return: an int, the size
	 */
	public int size()
	{
		return foodItems.size();
	}
}
