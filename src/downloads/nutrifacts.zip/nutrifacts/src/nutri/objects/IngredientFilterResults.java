package nutri.objects;

import java.util.ArrayList;

/**
 * this class contains a set of ingredients that were evaluated by FilterLogic as being
 * in the ingredient list of a <code>FoodItem</code>, and the ingredient filter list
 * specified by the user.  Is used to change the display of the ingredient labels on the
 * GUI.
 *
 */
public class IngredientFilterResults 
{
	
	private ArrayList<String> filters;
	
	public IngredientFilterResults()
	{
		filters = new ArrayList<String>();
	}

	/**
	 * add an ingredient to be filtered
	 * 
	 * @param ingredientName an ingredient name
	 */
	public void filterIngredient(String ingredientName)
	{
		filters.add(ingredientName);
	}
	
	/**
	 * check if the set contains an ingredient
	 * 
	 * @param ingredientName an ingredient name
	 */
	public boolean containsIngredient(String ingredientName)
	{
		return filters.contains(ingredientName);
	}
	
	/**
	 * get the number of ingredients that were evaluated by FilterLogic
	 * 
	 * @return size of the set
	 */
	public int size()
	{
		return filters.size();
	}
}
