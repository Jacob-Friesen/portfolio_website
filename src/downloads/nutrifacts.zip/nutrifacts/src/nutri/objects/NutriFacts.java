package nutri.objects;

import nutri.enums.NutriType;
import java.util.HashMap;
import java.util.Map;

/**
 * Object that stores all nutritional information about a product.
 */

public class NutriFacts
{
	public static int NumTypes = 14;

	public final static String[] NutriNames = {"calories", "total fat", "saturated fat", "trans fat", "cholesterol", "sodium", "total carbohydrate", "dietary fibre", "sugars", "protein", "vitamin A",
			"vitamin C", "calcium", "iron"};

	private Map<NutriType, NutriFact> facts;

	/**
	 * Constructor: creates hashmap with empty values
	 */
	public NutriFacts()
	{
		facts = new HashMap<NutriType, NutriFact>();
		createMissingFacts();
	}

	/**
	 * Constructor: sets facts to the input parameter and fills in any missing
	 * values
	 */
	public NutriFacts(Map<NutriType, NutriFact> facts)
	{
		this.facts = facts;

		if (this.facts.size() != NumTypes)
		{
			createMissingFacts();
		}
	}

	/**
	 * Creates default values for any missing <code>NutriType</code>s in facts.
	 */
	private void createMissingFacts()
	{
		for (NutriType type : NutriType.values())
		{
			if (!facts.containsKey(type))
			{
				facts.put(type, new NutriFact());
			}
		}
	}

	/**
	 * Change the information about a fact.
	 * 
	 * @param name name of fact
	 * @param amount serving amount
	 * @param dailyValue recommended daily intake
	 */
	public void updateFact(NutriType name, double amount)
	{
		facts.put(name, new NutriFact(amount));
	}

	/**
	 * Update facts list with all values in map.
	 * 
	 * @param newFacts
	 */
	public void updateFacts(Map<NutriType, NutriFact> newFacts)
	{
		for (NutriType type : newFacts.keySet())
		{
			facts.put(type, newFacts.get(type));
		}
	}

	/**
	 * Return the nutriFact for this name.
	 * 
	 * @param name of fact to get
	 * @return nutriFact for this name.
	 */
	public NutriFact getFact(NutriType name)
	{
		return facts.get(name);
	}

	/**
	 * Return the string representation of the type.
	 * 
	 * @param name of fact to convert
	 * @return equivalent name of enum sent in
	 */
	public String getFactName(NutriType name)
	{
		return NutriNames[name.ordinal()];
	}

	/**
	 * Grab the amount of fact name.
	 * 
	 * @param name of fact to get
	 * @return amount for the type specified
	 */
	public double getAmount(NutriType name)
	{
		return facts.get(name).amount();
	}
}