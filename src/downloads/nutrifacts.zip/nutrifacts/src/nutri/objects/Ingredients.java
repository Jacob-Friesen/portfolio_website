package nutri.objects;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

/**
 * A collection of ingredients, and methods to manipulate them
 * 
 */
public class Ingredients
{
	private ArrayList<String> ingredientList;

	public Ingredients()
	{
		ingredientList = new ArrayList<String>();
	}

	public Ingredients(Collection<String> c)
	{
		ingredientList = new ArrayList<String>(c);
	}

	/**
	 * add an ingredient to the ingredients list
	 * 
	 * @param ingredientName ingredient string
	 */
	public void add(final String ingredientName)
	{
		// Not checking for duplicates
		ingredientList.add(ingredientName);
	}

	/**
	 * adds a collection of ingredients to the list
	 * 
	 * @param collection of ingredients
	 */
	public void add(final Collection<String> collection)
	{
		ingredientList.addAll(collection);
	}

	/**
	 * checks if an ingredients list contains a string element
	 * 
	 * @param ingredientName ingredient string
	 * @return: true if the ingredient is in this object
	 */
	public boolean contains(String ingredientName)
	{
		Boolean result = false;
		int index = ingredientList.indexOf(ingredientName);

		if (index != -1)
		{
			result = true;
		}

		return result;
	}

	/**
	 * returns an <code>AraryList</code> format of the ingredients list
	 * 
	 * @return an <code>AraryList</code> of strings
	 */
	public ArrayList<String> getList()
	{
		return ingredientList;
	}

	/**
	 * returns a string representation of the ingredients list
	 * for printing
	 * 
	 * @return string representation of the ingredients list
	 */
	public String toString()
	{
		String result = "";

		for (Iterator<String> i = ingredientList.iterator(); i.hasNext();)
		{
			result = result.concat(i.next());

			if (i.hasNext())
			{
				/*JF removed space, this tends to make getting the toString of this
				and parsing awkward.*/
				result = result.concat(", ");
			}
		}

		return result;
	}
}