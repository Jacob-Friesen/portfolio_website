package nutri.objects;

/**
 * Stores all important information about a serving;
 * the serving size and units.
 */
public class Serving {
	
	private double servingSize;
	private String servingUnits;
	
	public Serving(double servingSize, String servingUnits)
	{
		this.servingSize = servingSize;
		this.servingUnits = servingUnits;
	}
	
	/**
	 * @return serving size
	 */
	public double getServingSize()
	{
		return servingSize;
	}

	/**
	 * @return units of the serving
	 */
	public String getServingUnits()
	{
		return servingUnits;
	}
	
}
