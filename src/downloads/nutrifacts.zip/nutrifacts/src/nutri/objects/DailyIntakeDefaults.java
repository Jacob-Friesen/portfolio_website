package nutri.objects;

/**
 * Class of static constants of the regular default standard
 * daily intake amounts, used for calculating percentages
 * until user customizes their own.
 *
 */
public class DailyIntakeDefaults 
{
	
	final public static int CALORIES = 2000;
	
	// all units in grams
	final public static double FAT = 65;
	final public static double SATURATED_FAT = 20;
	final public static double CHOLESTEROL = 0.3;
	final public static double SODIUM = 2.3;
	final public static double POTASSIUM = 3.5;
	final public static double CARBS = 300;
	final public static double FIBRE = 25;
	final public static double PROTEIN = 50;
		
	// vitamins
	final public static int VITAMIN_A = 5000;		// UI
	final public static double VITAMIN_C = 0.06;
	final public static double CALCIUM = 1;
	final public static double IRON = 0.018;
}