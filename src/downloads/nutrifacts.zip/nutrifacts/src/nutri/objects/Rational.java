package nutri.objects;

import java.text.DecimalFormat;

/**
 * Converts a double to a rational in string form
 */
public class Rational 
{
	private double value;
	
	public Rational(double d)
	{
		this.value = d;
		if(value < 0)
			value = value * -1;
		makeOneDecimal();
	}
	
	/**
	 * make a fractional display from a float or double
	 * 
	 * @return a string in the form like "1 1/2"
	 */
	public String toString()
	{	
		String result = "";
		
		int i = (int)(value);		// get the whole part
		int rem = (int)((value % 1) * 10);	// to one decimal point
		int gdc = GCD(rem, 10);
		
		rem = rem / gdc;
		int den = 10 / gdc;
		
		if (i > 0)
		{
			result = "" + i;
			if (rem > 0)	// include a space if there is a remainder
				result += " ";
		}
		
		if (rem > 0)
			result += rem + "/" + den;
		else if (i == 0)
			result = "0";		// extra case
		
		return result;
	}
	
	/**
	 * rounds value to one decimal place if more
	 * than one decimal place.
	 */
	private void makeOneDecimal()
	{
		DecimalFormat decForm = new DecimalFormat("#.#");
		value =  Double.valueOf(decForm.format(value));
	}
	
	/**
	 * get the gcd of 2 <code>int</code> values
	 * 
	 * @param a first <code>int</code>
	 * @param b second <code>int</code>
	 * @return the gdc
	 */
	private int GCD(int a, int b)
	{
	   if (b == 0) 
		   return a;
	   return GCD(b, a % b);
	}	
}
