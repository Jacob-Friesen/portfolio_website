package nutri.objects;

/**
 * The result of applying a filters onto a nutritional fact
 * keeps a boolean representing whether or not a filter failed
 * and a string of the toString values of filters that failed
 * 
 */

public class FilterResult 
{
	
	private boolean pass;
	private String fails;
	
	public FilterResult()
	{
		pass = true;
		fails = "Fact failed on:\n";		// initialize the tooltip
	}
	
	/**
	 * fails the nutritional fact
	 */
	public void fail() 
	{
		pass = false;
	}
	
	/**
	 * returns whether or not this aspect passed all it's filters
	 * 
	 * @return whether object passed filters
	 */
	public boolean passed() 
	{
		return pass;
	}
	
	/**
	 * adds a string to the fails reason string
	 * 
	 * @param reason a reason added for failure
	 */
	public void addFilterString(String reason)
	{
		fails += reason + "\n";
	}
	
	/**
	 * returns the failure message
	 * 
	 * @return the failure message
	 */
	public String getFails()
	{
		return fails;
	}
}
