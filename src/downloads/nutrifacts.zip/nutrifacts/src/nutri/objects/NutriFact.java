package nutri.objects;

/**
 * Stores the amount of a specified nutritional aspect, such as Protein, Fat, etc.
 */

public class NutriFact
{
	private double amount; // in grams

	public NutriFact()
	{
		amount = 0.0;
	}

	public NutriFact(double amount)
	{
		update(amount);
	}

	/**
	 * update the nutrifact amount
	 * 
	 * @param amount a double of an amount
	 */
	public void update(double amount)
	{
		this.amount = amount;
	}

	/**
	 * returns the amount
	 * 
	 * @return amount, as a double
	 */
	public double amount()
	{
		return amount;
	}
}