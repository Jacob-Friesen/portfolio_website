package nutri.objects;

/**
 * Stores all important information about a portion;
 * the portion size and portion types, can also
 * generate a string representing a portion size.
 */
public class Portion {
	
	private double portionSize;
	private String portionTypeEnglish;
	private String portionTypeFrench;
	
	public Portion()
	{
		portionSize = 1;
		portionTypeEnglish = "portion";
		portionTypeFrench = "portion";
	}
	
	/**
	 * used to initialize the portion type and size
	 * 
	 * @param portionSize
	 *            1 bun, 1 cup, etc
	 * @param portionTypeEnglish name of English portion type
	 * @param portionTypeFrench name of French portion type
	 */
	public void setPortion(double portionSize, String portionTypeEnglish, String portionTypeFrench)
	{
		this.portionSize = portionSize;
		this.portionTypeEnglish = portionTypeEnglish;
		this.portionTypeFrench = portionTypeFrench;
	}
	
	/**
	 * generates the string for the portion sizes
	 * 
	 * @param scale the scale to scale the portion amount to
	 * @return the string list that describes the portion size
	 */
	public String[] getPortionString(double scale)
	{
		Rational r = new Rational(portionSize * scale);
		String portion = r.toString();
		String[] returns = new String[2];//french then english
		
		returns[0] = "Per " + portion + " " + portionTypeEnglish;
		returns[1] = "par " + portion + " " + portionTypeFrench;

		return returns;
	}
	
	/**
	 * @return size of portion
	 */
	public double getPortionSize()
	{
		return portionSize;
	}
	
	/**
	 * @return name of French portion type
	 */
	public String getPortionTypeFr()
	{
		return portionTypeFrench;
	}
	
	/**
	 * @return name of English portion type
	 */
	public String getPortionTypeEn()
	{
		return portionTypeEnglish;
	}
}
