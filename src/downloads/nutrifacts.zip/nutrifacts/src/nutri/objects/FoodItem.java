package nutri.objects;

import java.util.ArrayList;
import java.util.Collection;

import nutri.enums.NutriType;


/**
 * Defined by a name, a list of nutritional facts, a list of ingredients
 * and the portion and serving amounts for it.
 */
public class FoodItem
{
	private final int MAX_RATING = 5;
	private final int NOT_SET_RATING = -1;
	
	private String name;
	private Portion portion;
	private Serving serving;
	private NutriFacts nutritionFacts;
	private Ingredients ingredients;
	private int rating;

	public FoodItem(String name, double servingSize, String servingUnits)
	{
		this(name, servingSize, servingUnits, new NutriFacts(), null);
	}

	public FoodItem(String name, double servingSize, String servingUnits, NutriFacts facts, Collection<String> ingredients)
	{
		this.name = name;
		portion = new Portion();
		serving = new Serving(servingSize, servingUnits);
		
		nutritionFacts = facts;
		if(ingredients == null)
			this.ingredients = new Ingredients();
		else
			this.ingredients = new Ingredients(ingredients);
		
		rating = NOT_SET_RATING;
	}
	
	/**
	 * compares two FoodItems by their name
	 * 
	 * @param other a <code>FoodItem</code> to compare to
	 * @return the result of the compareTo of the sent
	 * <code>FoodItem</code>and  the current <code>FoodItem</code>
	 */
	public int compareTo(FoodItem other)
	{
		return this.name.compareTo(other.name);
	}
	
	/**
	 * returns the name of the fooditem
	 * 
	 * @return fooditem name as a string
	 */
	public String getName()
	{
		return name;
	}
	
	/**
	 * @return the rating of the current food item, -1
	 * if not set.
	 */
	public int getRating()
	{
		return rating;
	}
	
	/**
	 * Set the rating to the specified value. 2 exceptions
	 * if the rating is over MAX_VALUE then the rating is
	 * set to MAX_VALUE, if the rating is less than -1 it
	 * is set to -1. (All negative values indicate not set)
	 * 
	 * @param rating the rating to set the food item to
	 */
	public void setRating(int rating)
	{
		if (rating < -1)
			this.rating = NOT_SET_RATING;
		else if (rating > MAX_RATING)
			this.rating = MAX_RATING;
		else
			this.rating = rating;
	}
	
	/**
	 * adds a nutritional fact to the <code>FoodItem</code>
	 * 
	 * @param name the nutritional type name (ex, PROTEIN)
	 * @param amount the amount of the type
	 */
	public void addFact(NutriType name, double amount)
	{
		nutritionFacts.updateFact(name, amount);
	}
	
	/**
	 * retrieves a nutritional fact
	 * 
	 * @param name the name of a nutritional fact
	 * @return the <code>NutriFact</code> object
	 */
	public NutriFact getFact(NutriType name)
	{
		return nutritionFacts.getFact(name);
	}
	
	/**
	 * retrieves the NutritionalFacts object
	 * 
	 * @return all of the nutritional facts
	 */
	public NutriFacts getFacts()
	{
		return nutritionFacts;
	}
	
	/**
	 * gets the amount specified under a nutritional fact name, and returns it
	 * more details in serving
	 * 
	 * @param name the name of a nutritional fact 
	 * @param scale the current scale being used
	 * 
	 * @return the fact of the name specified with the scale taken into account
	 */
	public double getAmount(NutriType name, double scale)
	{
		NutriFact fact = getFact(name);
		return fact.amount() * scale;
	}
	
	/**
	 * generates a comma delimited string of the ingredients for display in the
	 * UI
	 * 
	 * @return a string of the ingredients, comma delimited
	 */
	public String getIngredientsString()
	{
		return ingredients.toString();
	}
	
	/**
	 * returns a list of ingredients
	 * 
	 * @return a string list of ingredients
	 */
	public ArrayList<String> getIngredientsList()
	{
		return ingredients.getList();
	}

	/**
	 * checks if the current ingredient is in the ingredient list
	 * 
	 * @param ingredientName name of ingredient to check
	 * @return true if the ingredient specified is in the ingredients
	 */
	public boolean containsIngredient(String ingredientName)
	{
		return ingredients.contains(ingredientName);
	}

	/**
	 * returns a list of ingredients
	 * 
	 * @return a <code>Ingredient</code> type
	 */
	public Ingredients getIngredients()
	{
		return ingredients;
	}

	/**
	 * adds an ingredient to the ingredient list
	 * 
	 * @param name the ingredients name in string form
	 */
	public void addIngredient(String name)
	{
		ingredients.add(name);
	}

	/**
	 * adds all ingredients from a <code>Collection</code> of
	 * strings.
	 * 
	 * @param collection the collection to add
	 */
	public void addIngredients(Collection<String> collection)
	{
		ingredients.add(collection);
	}
	
	/**
	 * gets serving size
	 * 
	 * @return serving size
	 */
	public double getServingSize()
	{
		return serving.getServingSize();
	}

	/**
	 * gets serving units
	 * 
	 * @return serving units
	 */
	public String getServingUnits()
	{
		return serving.getServingUnits();
	}
	
	/**
	 * generates the string for the portion sizes. More
	 * details in {@link Portion}
	 * 
	 * @param scale to scale the portion by
	 * 
	 * @return a formatted string of the English and French
	 * portion size and units
	 */
	public String getPortionString(double scale)
	{
		String servStr = "(" + (int) (serving.getServingSize() * scale) + " " + serving.getServingUnits() + ")";
		String[] portionStrs = portion.getPortionString(scale);
		
		portionStrs[0] += " " + servStr;
		portionStrs[1] += " " + servStr;
		
		return portionStrs[0] + " / " + portionStrs[1];
	}
	
	/**
	 * used to initialize the portion type and size for
	 * more details see portion.
	 * 
	 * @param portionSize size of portion
	 * @param portionTypeEnglish name of English portion
	 * @param portionTypeFrench name of French portion
	 */
	public void setPortion(double portionSize, String portionTypeEnglish, String portionTypeFrench)
	{
		portion.setPortion(portionSize, portionTypeEnglish, portionTypeFrench);
	}

	/**
	 * get the default portion size
	 * 
	 * @return a double of the default portion size
	 */
	public double getPortionSize()
	{
		return portion.getPortionSize();
	}

	/**
	 * returns the portion type, en francais
	 * 
	 * @return a string of the portion type
	 */
	public String getPortionTypeFr()
	{
		return portion.getPortionTypeFr();
	}
	
	/**
	 * returns the portion type, in english
	 * 
	 * @return a string of the portion type
	 */
	public String getPortionTypeEn()
	{
		return portion.getPortionTypeEn();
	}
}
