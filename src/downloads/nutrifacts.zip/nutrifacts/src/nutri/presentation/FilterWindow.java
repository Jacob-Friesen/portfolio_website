package nutri.presentation;

import nutri.enums.*;
import nutri.objects.NutriFilter;
import nutri.objects.NutriFilterList;
import nutri.objects.IngredientFilters;

import java.text.DecimalFormat;
import java.util.ArrayList;

import nutri.logic.NutriFilterHandler;
import nutri.logic.IngredientFilterHandler;

import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Monitor;
import org.eclipse.swt.widgets.TabItem;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Event;
import org.eclipse.wb.swt.SWTResourceManager;

import ctunit.EventLoop;
import ctunit.Register;

public class FilterWindow 
{
	private DecimalFormat decimal = new DecimalFormat("#.#");
	
	private FactsWindow factsWindow;		// pointer back to the main window
	protected Shell shell;
	private Display display;
	private Text txtUnits;
	
	// handlers for logic
	private IngredientFilterHandler ingrHandler;
	private NutriFilterHandler filterHandler;

	// data structure to store the filter lists
	private NutriFilterList filterList;
	private IngredientFilters ingredFilterList;
	
	// the accessible fields on the filter screen
	private TabItem tbtmEditCustomFilters;
	private Combo comboAspects;
	private List lstCurrentFilters;
	private Combo comboCompare;
	private Combo comboUnits;
	private Button btnActiveFilter;
	private Button btnSaveFilter;
	private Button btnCreateNewFilter;
	private Button btnRemoveFilter;
	
	// the accessible fields on the ingredients screen
	private TabItem tab_ingredients;
	private List list_ingredientFilters;
	private Combo combo_ingredients;
	private Button btnRemoveSelectedIngredient;
	private Button btnFilterIngredient;
	
	public FilterWindow(IngredientFilterHandler ingrHandler, NutriFilterHandler filterHandler, FactsWindow factsWindow)
	{
		Register.newWindow(this);
		
		this.ingrHandler = ingrHandler;
		this.filterHandler = filterHandler;
		this.factsWindow = factsWindow;
	}
	
	/**
	 * Open the window.
	 * @wbp.parser.entryPoint
	 */
	public void open() 
	{
		if (shell == null || shell.isDisposed())		// create a new window
		{
			display = Display.getDefault();
			createContents();
			
			initDisplay();
	
			// center the window
		    Monitor primary = display.getPrimaryMonitor();
		    Rectangle bounds = primary.getBounds();
		    Rectangle rect = shell.getBounds();
		    
		    int x = bounds.x + (bounds.width - rect.width) / 2;
		    int y = bounds.y + (bounds.height - rect.height) / 2;
		    
		    shell.setLocation(x, y);	
			
			shell.open();
			shell.layout();
			runWindow();
		}
		else		// there is already a window, show it
			shell.forceFocus();
	}
	
	/**
	 * Used for CTUnit to run events or just runs the normal
	 * display loop
	 */
	public void runWindow()
    {
    	if (EventLoop.isEnabled())
    	{
			while (!shell.isDisposed())
			{
				if (!display.readAndDispatch())
				{
					display.sleep();
				}
			}
    	}
    }
	
	/**
	 * parent windows can close this window if they have to
	 */
	public void close()
	{
		if (shell != null && !shell.isDisposed())
			shell.close();
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() 
	{
		shell = new Shell(SWT.TITLE | SWT.MIN | SWT.CLOSE | SWT.BORDER);
		shell.setImage(SWTResourceManager.getImage(FilterWindow.class, "/fruit.png"));
		shell.setSize(740, 356);
		shell.setText("Edit Custom Filters");
		shell.setLayout(null);
		
		TabFolder tabFolder = new TabFolder(shell, SWT.NONE);
		tabFolder.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.NORMAL));
		tabFolder.setBackground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_BACKGROUND));
		tabFolder.setBounds(10, 10, 704, 278);
		
		createFilterTabContents(tabFolder);
		createIngredientsFilterTabContents(tabFolder);
	}

	/**
	 * initialize the display with data from the database
	 */
	private void initDisplay()
	{
		refreshFilterList();
		refreshIngredientFilterList();
		
		// initialize the ingredients in the combo box
		ArrayList<String> ingredients = ingrHandler.getAllIngredients();
		combo_ingredients.removeAll();
		
		for(int i = 0; i < ingredients.size(); i++)
		{
			combo_ingredients.add(ingredients.get(i));
		}
		
		doFactsException();
	}
	
/**********************************************************************************
 ******************************* NutriFact Filters	*******************************
 **********************************************************************************/
	
	/**
	 * creates the objects in filter tab window
	 * 
	 * @param tabFolder the tab to create the contents in
	 */
	private void createFilterTabContents(TabFolder tabFolder)
	{	
		tbtmEditCustomFilters = new TabItem(tabFolder, SWT.NONE);
		tbtmEditCustomFilters.setImage(SWTResourceManager.getImage(FilterWindow.class, "/calculator--plus.png"));
		tbtmEditCustomFilters.setText("Nutritional Filters");
		
		Composite nutritionalComposite = new Composite(tabFolder, SWT.NONE);
		nutritionalComposite.setBackground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_BACKGROUND));
		tbtmEditCustomFilters.setControl(nutritionalComposite);
		
		Label lblCurrentFilters = new Label(nutritionalComposite, SWT.NONE);
		lblCurrentFilters.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.NORMAL));
		lblCurrentFilters.setBounds(10, 10, 84, 15);
		lblCurrentFilters.setText("Current Filters:");
		
		lstCurrentFilters = new List(nutritionalComposite, SWT.BORDER | SWT.V_SCROLL | SWT.MULTI);
		lstCurrentFilters.setBounds(10, 31, 187, 174);
		lstCurrentFilters.addSelectionListener(new SelectionListener()
		{

			public void widgetSelected(SelectionEvent e)
			{
				// repopulate the form with the current selection
				refreshCurrentFilter();
			}

			public void widgetDefaultSelected(SelectionEvent e)
			{
				// even after reading the docs, still not sure what's the reason
				// for forcing me
				// to implement this...
			}
		});
		lstCurrentFilters.addKeyListener(new KeyListener()
		{
			public void keyPressed(KeyEvent e)
			{
			}
			
			public void keyReleased(KeyEvent e)
			{
				// if the key was delete, delete!
				int val = e.character;
				
				if (val == 127)	// delete key
					removeFilter();
			}
		});
		
		Group grpFilterDetails = new Group(nutritionalComposite, SWT.NONE);
		grpFilterDetails.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.NORMAL));
		grpFilterDetails.setText("Filter Details");
		grpFilterDetails.setBounds(217, 21, 469, 217);
		
		Label lblNutritionalAspect = new Label(grpFilterDetails, SWT.NONE);
		lblNutritionalAspect.setBounds(10, 24, 99, 15);
		lblNutritionalAspect.setText("Nutritional Aspect:");
		
		comboAspects = new Combo(grpFilterDetails, SWT.READ_ONLY);
		comboAspects.setBounds(115, 21, 155, 23);
		comboAspects.setItems(new String[] {"Calories", "Fat", "Saturated Fat", "Trans Fat", "Cholesterol", "Sodium", "Carbohydrates", "Fibre", "Sugars", "Protein", "Vitamin A", "Vitamin C", "Calcium", "Iron"});
		comboAspects.select(0);
		comboAspects.addListener(SWT.Selection, new Listener()
		{
			public void handleEvent(Event event) 
			{
				doFactsException();
			}
		});
		
		Label lblMustBe = new Label(grpFilterDetails, SWT.NONE);
		lblMustBe.setBounds(10, 55, 46, 15);
		lblMustBe.setText("Must be ");
		
		comboCompare = new Combo(grpFilterDetails, SWT.READ_ONLY);
		comboCompare.setItems(new String[] {"Less Than", "Less Than/Equal", "Greater Than", "Greater Than/Equal"});
		comboCompare.setBounds(60, 52, 128, 23);
		comboCompare.select(0);
		
		txtUnits = new Text(grpFilterDetails, SWT.BORDER);
		txtUnits.setBounds(194, 54, 76, 21);
		
		comboUnits = new Combo(grpFilterDetails, SWT.READ_ONLY);
		comboUnits.setItems(new String[] {"Grams", "Milligrams"});
		comboUnits.setBounds(276, 52, 91, 23);
		comboUnits.select(0);
		
		// the buttons
		
		btnSaveFilter = new Button(grpFilterDetails, SWT.NONE);
		btnSaveFilter.setBounds(250, 172, 75, 25);
		btnSaveFilter.setText("Save Filter");
		btnSaveFilter.addListener(SWT.Selection, new Listener()
		{
			public void handleEvent(Event event) 
			{
				saveFilter();
			}
		});
		
		// this is actually not a button, it's a checkbox
		btnActiveFilter = new Button(grpFilterDetails, SWT.CHECK);
		btnActiveFilter.setSelection(true);
		btnActiveFilter.setBounds(10, 176, 93, 16);
		btnActiveFilter.setText("Active Filter");
		
		btnCreateNewFilter = new Button(grpFilterDetails, SWT.NONE);
		btnCreateNewFilter.setImage(SWTResourceManager.getImage(FilterWindow.class, "/new.png"));
		btnCreateNewFilter.setBounds(331, 172, 128, 25);
		btnCreateNewFilter.setText("New Empty Filter");
		btnCreateNewFilter.addListener(SWT.Selection, new Listener()
		{
			public void handleEvent(Event event)
			{
				createNewFilter();
			}
		});
		
		btnRemoveFilter = new Button(nutritionalComposite, SWT.NONE);
		btnRemoveFilter.setBounds(104, 213, 93, 25);
		btnRemoveFilter.setText("Remove Filter");		
		btnRemoveFilter.addListener(SWT.Selection, new Listener()
		{
			public void handleEvent(Event event)
			{
				removeFilter();
			}
		});
	}
	
	/**
	 * check the nutritional aspect, and disable the unit type if necessary
	 */
	private void doFactsException()
	{
		// pull out the nutritional aspect
		NutriType type = NutriType.values()[comboAspects.getSelectionIndex()];
		
		// some types don't have a standard unit type
		if (type == NutriType.CALORIES || type == NutriType.VITAMIN_A)
		{
			comboUnits.select(0);
			comboUnits.setEnabled(false);
		}
		else
			comboUnits.setEnabled(true);
	}

	/**
	 * updates the filter list with information from the data layer
	 */
	private void refreshFilterList()
	{
		// clear any previous list
		lstCurrentFilters.removeAll();
		
		// initialize the filter list
		filterList = filterHandler.getAllFilters();
		
		// populate the display list
		for (int i = 0; i < filterList.size(); i++)
		{
			lstCurrentFilters.add(filterList.getFilter(i).toString());
		}
	}

	/**
	 * refreshes the filter information with the current selection
	 */
	private void refreshCurrentFilter()
	{
		// get the current selection, and pull it out of the list
		int[] selection = lstCurrentFilters.getSelectionIndices();
		
		if (selection.length == 1)		// 1 or less selections
		{
			NutriFilter filter = filterList.getFilter(selection[0]);
			
			// activate all the fields
			setEnabled(true);
			
			// update the fields to display it
			comboAspects.select(filter.getNutriType().ordinal());
			comboCompare.select(filter.getOperator().ordinal());
			txtUnits.setText(decimal.format(filter.getValue()) + "");
			comboUnits.select(filter.getUnit().ordinal());
			
			if (filter.isActive())
				btnActiveFilter.setSelection(true);
			else
				btnActiveFilter.setSelection(false);
			
			doFactsException();		// check the selected item, disable unit types if necessary
		}
		else
			setEnabled(false);
			
	}
	
	/**
	 * set editable elements to be enabled or disabled
	 * 
	 * @param val: true or false
	 */
	private void setEnabled(boolean val)
	{
		comboAspects.setEnabled(val);
		comboCompare.setEnabled(val);
		txtUnits.setEnabled(val);
		comboUnits.setEnabled(val);
		btnActiveFilter.setEnabled(val);
		btnSaveFilter.setEnabled(val);		
	}
	
	/**
	 * create new filter button handler method
	 */
	private void createNewFilter()
	{
		// reset the selection, and all of the fields
		lstCurrentFilters.deselectAll();
		comboAspects.select(0);
		comboCompare.select(0);
		txtUnits.setText("");
		comboUnits.select(0);
		btnActiveFilter.setSelection(true);
	}
	
	/**
	 * save filter button handler method
	 */
	private void saveFilter()
	{
		int selection = -1;
		
		// do some error checking
		if (!isDouble(txtUnits.getText()) || Double.parseDouble(txtUnits.getText()) < 0)
		{
			MessageBox messageBox = new MessageBox(shell, SWT.ICON_INFORMATION);
			messageBox.setText("Error");
			messageBox.setMessage("Please enter a valid amount.");
			messageBox.open();			
		}
		else	// update/create a filter
		{
			
			// build up the filter object, probably a really inefficient way of doing it...
			NutriFilter filter = new NutriFilter(NutriType.values()[comboAspects.getSelectionIndex()],
					OperatorType.values()[comboCompare.getSelectionIndex()],
					txtUnits.getText(), UnitType.values()[comboUnits.getSelectionIndex()]);
			
			// check if active
			if (btnActiveFilter.getSelection())
				filter.setActive(true);
			else
				filter.setActive(false);
				
			// if there is a selection, update it
			selection = lstCurrentFilters.getSelectionIndex();
			
			if (selection >= 0)
				filterHandler.updateFilter(filterList.getFilter(selection), filter);
			else	// add it as a new filter
				filterHandler.addFilter(filter);
			
			// refresh the list
			refreshFilterList();
			
			if (selection >= 0)		// reselect it in the list
				lstCurrentFilters.setSelection(selection);
			else					// refresh to a blank filter
				createNewFilter();
			
			factsWindow.refreshDisplay();		// refresh the main display
		}
	}

	/**
	 * a simple method to check if input is an integer
	 * 
	 * @param input: string input
	 * @return: true or false
	 */
	public boolean isDouble(String input)
	{
		try
		{
			Double.parseDouble(input);
			return true;  
		}
		catch (Exception e)
		{
			return false;
		}
	}  
	
	/**
	 * removeFilter button handler method
	 */
	public void removeFilter()
	{
		int[] selected = lstCurrentFilters.getSelectionIndices();
		
		// delete in reverse order, as the list will shrink
		for (int i = selected.length - 1; i >= 0; i--)
			filterHandler.deleteFilter(filterList.getFilter(selected[i]));
		
		refreshFilterList();
		createNewFilter();
		setEnabled(true);		// set editable fields to enabled
		
		factsWindow.refreshDisplay();
	}
	
	
/**********************************************************************************
 ******************************* Ingredient Filters	*******************************
 **********************************************************************************/

	/**
	 * creates the viewport on the tab for the ingredients filter editor
	 * 
	 * @param tabFolder the tab folder to create inside
	 */
	private void createIngredientsFilterTabContents(TabFolder tabFolder)
	{
		tab_ingredients = new TabItem(tabFolder, SWT.NONE);
		tab_ingredients.setImage(SWTResourceManager.getImage(FilterWindow.class, "/cookies.png"));
		tab_ingredients.setText("Ingredient Filters");
		
		Composite comp_ingredients = new Composite(tabFolder, SWT.NONE);
		comp_ingredients.setBackground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_BACKGROUND));
		tab_ingredients.setControl(comp_ingredients);
		
		Label label_currentFilters = new Label(comp_ingredients, SWT.NONE);
		label_currentFilters.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.NORMAL));
		label_currentFilters.setBounds(10, 10, 84, 15);
		label_currentFilters.setText("Current Filters:");
		
		list_ingredientFilters = new List(comp_ingredients, SWT.BORDER | SWT.V_SCROLL | SWT.MULTI);
		list_ingredientFilters.setBounds(10, 31, 229, 180);
		list_ingredientFilters.addKeyListener(new KeyListener()
		{
			public void keyPressed(KeyEvent e)
			{
			}
			
			public void keyReleased(KeyEvent e)
			{
				// if the key was delete, delete!
				int val = e.character;
				
				if (val == 127)	// delete key
					removeIngredientFilter();
			}
		});
		
		btnRemoveSelectedIngredient = new Button(comp_ingredients, SWT.NONE);
		btnRemoveSelectedIngredient.setBounds(67, 217, 172, 25);
		btnRemoveSelectedIngredient.setText("Remove Ingredient Filter");
		btnRemoveSelectedIngredient.addListener(SWT.Selection, new Listener()
		{
			public void handleEvent(Event event) 
			{
				removeIngredientFilter();
			}
		});
		
		Group grpCreateNewIngredient = new Group(comp_ingredients, SWT.NONE);
		grpCreateNewIngredient.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.NORMAL));
		grpCreateNewIngredient.setBackground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_BACKGROUND));
		grpCreateNewIngredient.setText("Create New Ingredient Filter");
		grpCreateNewIngredient.setBounds(257, 21, 429, 190);
		
		Label lblIngredientsList = new Label(grpCreateNewIngredient, SWT.NONE);
		lblIngredientsList.setBounds(10, 30, 83, 15);
		lblIngredientsList.setText("Ingredients List:");
		
		combo_ingredients = new Combo(grpCreateNewIngredient, SWT.NONE);
		combo_ingredients.setBounds(99, 27, 242, 23);
		combo_ingredients.setItems(new String[] {"Cheese", "High-Fructose Corn Syrup", "Sodium Benzoate", "Potassium Sulfate", "Fructose"});
		combo_ingredients.addKeyListener(new KeyListener()
		{
			public void keyPressed(KeyEvent e)
			{
			}
			
			public void keyReleased(KeyEvent e)
			{
				// if the key was enter, enter a new ingredient
				int val = e.character;
				
				if (val == 13)	// enter key
					saveIngredientFilter();
			}
		});
		
		btnFilterIngredient = new Button(grpCreateNewIngredient, SWT.NONE);
		btnFilterIngredient.setBounds(172, 56, 169, 25);
		btnFilterIngredient.setText("Add Ingredient Filter");
		btnFilterIngredient.addListener(SWT.Selection, new Listener()
		{
			public void handleEvent(Event event)
			{
				saveIngredientFilter();
			}
		});
		
		Button btnCloseFilters = new Button(shell, SWT.NONE);
		btnCloseFilters.setBounds(597, 295, 117, 25);
		btnCloseFilters.setText("Close Filter Window");
		btnCloseFilters.addListener(SWT.Selection, new Listener()
		{
			public void handleEvent(Event event) 
			{
				// close the window
				shell.close();
			}
		});
	}

	/**
	 * updates the ingredient filter list with information from the data layer
	 */
	private void refreshIngredientFilterList()
	{
		// clear list
		list_ingredientFilters.removeAll();
		
		ingredFilterList = ingrHandler.getAllIngredientFilters();
		
		for (int i=0; i < ingredFilterList.size(); i++)
		{
			list_ingredientFilters.add(ingredFilterList.get(i));
		}
	}
	
	/**
	 * save ingredient filter button handler method
	 */
	private void saveIngredientFilter()
	{
		String ingredient = combo_ingredients.getText();
		combo_ingredients.setText("");
		
		if (!ingredient.isEmpty() && !ingredFilterList.contains(ingredient))
		{
			list_ingredientFilters.add(ingredient);
			ingrHandler.addIngredient(ingredient);
			
			factsWindow.refreshDisplay();
		}
	}
	
	/**
	 * remove ingredient filter handler method
	 */
	public void removeIngredientFilter()
	{
		String[] selected = list_ingredientFilters.getSelection();
		
		for (int i = selected.length - 1; i >= 0; i--)
			ingrHandler.deleteIngredient(selected[i]);
		
		refreshIngredientFilterList();
		factsWindow.refreshDisplay();
	}
}
