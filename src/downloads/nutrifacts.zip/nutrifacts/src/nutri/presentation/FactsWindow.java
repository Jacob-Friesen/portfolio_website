package nutri.presentation;

import java.lang.reflect.Field;
import java.util.ArrayList;

import nutri.logic.*;
import nutri.objects.FilterResults;
import nutri.objects.FilterResult;
import nutri.objects.FoodItem;
import nutri.objects.FoodItemList;
import nutri.objects.IngredientFilterResults;
import nutri.objects.Rational;
import nutri.enums.NutriType;
import nutri.enums.UnitType;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Monitor;
import org.eclipse.swt.widgets.Scale;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.ToolBar;
import org.eclipse.swt.widgets.ToolItem;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;

import ctunit.EventLoop;
import ctunit.Register;

/**
 * Main window that the user first sees. After the items are loaded in all
 * progress in the application starts here or in another window.
 */
public class FactsWindow
{
	private FoodItem product;	// the selected food item
	
	protected Shell shell;
	private List lstProducts;

	//objects that provide all logic functionality
	private FoodHandler foodHandler;
	private SuggestionHandler suggestionHandler;
	private FilterLogic filterLogic;
	
	//logic used to generate daily percentages
	private DailyPercentLogic dailyPercent;

	// the updateable labels
	private Label lblProductName; // the product name headers
	private Label lblPortionSize; // portion info
	
	// the highlight colour when a filter fails
	private Color highlight;
	
	// for the ingredients composite
	private ScrolledComposite scrolledComposite;
	private Composite cmpIngredients;
	private Label[] i_labels[];			// the ingredient labels

	// the amounts
	private Label 	lblCaloriesAmount,
					lblFatAmount,
					lblSaturatedAmount,
					lblTransAmount,
					lblCholesterolAmount,
					lblSodiumAmount,
					lblCarbohydratesAmount,
					lblFibreAmount,
					lblSugarsAmount,
					lblProteinAmount,
					lblVitaminAAmount,
					lblVitaminCAmount,
					lblCalciumAmount,
					lblIronAmount;
					
	// the percentages
	private Label 	lblCaloriesPercent,
					lblFatPercent,
					lblSaturatedPercent,
					lblCholesterolPercent,
					lblSodiumPercent,
					lblCarbohydratesPercent,
					lblFibrePercent,
					lblSugarsPercent,
					lblProteinPercent,
					lblVitaminAPercent,
					lblVitaminCPercent,
					lblCalciumPercent,
					lblIronPercent;

	// the filter percent score
	Label lblFilterPercent;
	
	// for the portion scaling
	private Scale scalePortion;
	private Text txtScale;

	// the other windows
	private Composite compositeNutrition;
	private FilterWindow filterWindow;
	private DailyAmountWindow dailyAmountWindow;
	private Label lblIngredientsList;
	private Label lblScaleToPortion;
	private ToolBar toolBar;
	private ToolItem tltmCreateAndEdit;
	private Text txtSearch;
	private Label lblOverallProductFilter;
	
	// labels for the ratings
	private Label lblStars[];
	private Label lblStar1;
	private Label lblNewLabel;
	
	// suggestions
	private List lstSuggestions;
	private Label lblSuggestions;
	
	//needed for ctunit
	private Display display;
	private Text getValue;//used in ctunits invokeMethod to get a labels text

	public FactsWindow()
	{	
		new LogicMain().init(this);
	}

	/**
	 * Open the window, needs to be a constructor for ctunit
	 */
	public FactsWindow(FoodHandler foodHandler, SuggestionHandler suggestionHandler, IngredientFilterHandler ingrHandler, NutriFilterHandler filterHandler)
	{	
		this.foodHandler = foodHandler;
		this.suggestionHandler = suggestionHandler;
		
		dailyPercent = new DailyPercentLogic();
		filterLogic = new FilterLogic();
		
		// initialize the other windows
		dailyAmountWindow = new DailyAmountWindow(dailyPercent, this);
		filterWindow = new FilterWindow(ingrHandler, filterHandler, this);
		
		// initialize the ingredients display to nothing
		i_labels = new Label[0][0];
		
		open();
	}
	
	public void open()
	{
		display = Display.getDefault();
		Register.newWindow(this);
		createContents();
		txtSearch.forceFocus();
		
		// center the window
	    Monitor primary = display.getPrimaryMonitor();
	    Rectangle bounds = primary.getBounds();
	    Rectangle rect = shell.getBounds();
	    
	    int x = bounds.x + (bounds.width - rect.width) / 2;
	    int y = bounds.y + (bounds.height - rect.height) / 2;
	    
	    shell.setLocation(x, y);		

		// add a listener, close all child windows when this closes
	    shell.addListener(SWT.Close, new Listener()
	    {
	        public void handleEvent(Event event) 
	        {
	        	filterWindow.close();
	        	dailyAmountWindow.close();
	        }
	      });
	    shell.addListener(SWT.Show, new Listener()
	    {
	    	// if the window gets focus, refresh the display
	    	public void handleEvent(Event event)
	    	{
	    		refreshDisplay();
	    	}
	    });
		shell.open();
		shell.layout();
		
		//for ctunit
		runWindow();
	}
	
	/**
	 * Used for CTUnit to run events or just runs the normal
	 * display loop
	 */
	public void runWindow()
    {
    	if (EventLoop.isEnabled())
    	{
			while (!shell.isDisposed())
			{
				if (!display.readAndDispatch())
				{
					display.sleep();
				}
			}
			display.dispose();
    	}
    }

	/**
	 * Create contents of the window.
	 * 
	 * @wbp.parser.entryPoint
	 */
	protected void createContents()
	{
		// initialize the highlight colour for failed filters
		highlight = SWTResourceManager.getColor(255, 0, 4);
		
		shell = new Shell(SWT.TITLE | SWT.MIN | SWT.CLOSE | SWT.BORDER);
		shell.setImage(SWTResourceManager.getImage(FactsWindow.class, "/fruit.png"));
		shell.setBackground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_BACKGROUND));
		shell.setSize(803, 683);
		shell.setText("NutriFacts");
		shell.setLayout(null);

		lstProducts = new List(shell, SWT.BORDER | SWT.V_SCROLL);
		lstProducts.setBounds(10, 85, 433, 245);
		lstProducts.addSelectionListener(new SelectionListener()
		{

			public void widgetSelected(SelectionEvent e)
			{
				if (lstProducts.getSelectionIndex() > -1)
				{
					refreshDisplay();
					updateSuggestions();
				}
			}

			public void widgetDefaultSelected(SelectionEvent e)
			{
				// even after reading the docs, still not sure what's the reason
				// for forcing me
				// to implement this...
			}
		});

		lblIngredientsList = new Label(shell, SWT.NONE);
		lblIngredientsList.setBounds(10, 336, 94, 20);
		lblIngredientsList.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.NORMAL));
		lblIngredientsList.setBackground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_BACKGROUND));
		lblIngredientsList.setText("Ingredients List:");

		lblScaleToPortion = new Label(shell, SWT.NONE);
		lblScaleToPortion.setBounds(460, 570, 327, 15);
		lblScaleToPortion.setBackground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_BACKGROUND));
		lblScaleToPortion.setText("Scale Portion Size:");

		scalePortion = new Scale(shell, SWT.NONE);
		scalePortion.setBounds(460, 591, 252, 42);
		scalePortion.setMaximum(20);
		scalePortion.setToolTipText("");
		scalePortion.setPageIncrement(2);
		scalePortion.setSelection(2);
		scalePortion.setBackground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_BACKGROUND));
		scalePortion.addSelectionListener(new SelectionListener()
		{
			public void widgetSelected(SelectionEvent e)
			{
				//txtScale.setText(String.valueOf(scalePortion.getSelection() / 2.0));
				Rational r = new Rational(scalePortion.getSelection() / 2.0);
				txtScale.setText(r.toString());

				updateScale();
			}

			public void widgetDefaultSelected(SelectionEvent e)
			{
				// even after reading the docs, still not sure what's the reason
				// for forcing me
				// to implement this...
			}
		});

		txtScale = new Text(shell, SWT.BORDER | SWT.READ_ONLY);
		txtScale.setBounds(718, 591, 69, 42);
		txtScale.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		txtScale.setFont(SWTResourceManager.getFont("Segoe UI", 15, SWT.NORMAL));
		txtScale.setText("1");

		toolBar = new ToolBar(shell, SWT.FLAT | SWT.RIGHT);
		toolBar.setBounds(10, 10, 321, 23);

		tltmCreateAndEdit = new ToolItem(toolBar, SWT.NONE);
		tltmCreateAndEdit.setImage(SWTResourceManager.getImage(FactsWindow.class, "/calculator--plus.png"));
		tltmCreateAndEdit.setText("Create and Edit Filters");
		tltmCreateAndEdit.addListener(SWT.Selection, new Listener()
		{
			public void handleEvent(Event event)
			{
				// launch the window
				try
				{
					filterWindow.open();
				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});

		final ToolItem toolItem = new ToolItem(toolBar, SWT.SEPARATOR);

		ToolItem tltmCustomizeDailyAmounts = new ToolItem(toolBar, SWT.NONE);
		tltmCustomizeDailyAmounts.setImage(SWTResourceManager.getImage(FactsWindow.class, "/clipboard-list.png"));
		tltmCustomizeDailyAmounts.setText("Customize Daily Amounts");
		tltmCustomizeDailyAmounts.addListener(SWT.Selection, new Listener()
		{
			public void handleEvent(Event event)
			{
				// launch the window
				try
				{
					dailyAmountWindow.open();
				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});

		// create the search box, filter percentage match
		lblOverallProductFilter = new Label(shell, SWT.NONE);
		lblOverallProductFilter.setBounds(525, 526, 202, 21);
		//fd_scrolledComposite.bottom = new FormAttachment(lblOverallProductFilter, -6);
		lblOverallProductFilter.setFont(SWTResourceManager.getFont("Segoe UI", 12, SWT.NORMAL));
		lblOverallProductFilter.setText("Overall Product Filter Score:");
		
		lblFilterPercent = new Label(shell, SWT.NONE);
		lblFilterPercent.setBounds(746, 525, 41, 23);
		lblFilterPercent.setFont(SWTResourceManager.getFont("Segoe UI", 13, SWT.NORMAL));
		lblFilterPercent.setText("100%");
		
		lblNewLabel = new Label(shell, SWT.NONE);
		lblNewLabel.setBounds(10, 47, 102, 20);
		lblNewLabel.setFont(SWTResourceManager.getFont("Segoe UI", 11, SWT.NORMAL));
		lblNewLabel.setText("Product Search:");
		
		txtSearch = new Text(shell, SWT.BORDER);
		txtSearch.setFont(SWTResourceManager.getFont("Segoe UI", 11, SWT.NORMAL));
		txtSearch.setBounds(118, 44, 325, 28);
		txtSearch.addModifyListener(new ModifyListener()
		{
			public void modifyText(ModifyEvent e)
			{
				refreshProductList();
			}
		});
		
		// create the ingridents display box
		createIngredientsDisplay();
		createRatingDisplay();
		
		// create the display for the nutritional information
		createNutriInfoDisplay();
		
		// create the suggestion box
		lstSuggestions = new List(shell, SWT.BORDER | SWT.V_SCROLL);
		lstSuggestions.setBounds(10, 512, 433, 133);
		lstSuggestions.addSelectionListener(new SelectionListener()
		{
			public void widgetSelected(SelectionEvent e)
			{
				if (lstSuggestions.getSelectionIndex() > -1)
					refreshDisplayWithSuggestion();
			}
			public void widgetDefaultSelected(SelectionEvent e)
			{
				
			}
		});
		
		lblSuggestions = new Label(shell, SWT.NONE);
		lblSuggestions.setFont(SWTResourceManager.getFont("Segoe UI", 10, SWT.NORMAL));
		lblSuggestions.setBounds(10, 488, 134, 20);
		lblSuggestions.setText("Suggested Products:");
	}

	
	/**
	 * create the box to store the ingredients
	 */
	private void createIngredientsDisplay()
	{
		scrolledComposite = new ScrolledComposite(shell, SWT.BORDER | SWT.V_SCROLL);
		scrolledComposite.setBounds(10, 362, 356, 120);
		scrolledComposite.setExpandHorizontal(true);
		scrolledComposite.setExpandVertical(true);
		scrolledComposite.setAlwaysShowScrollBars(true);
		
		cmpIngredients = new Composite(scrolledComposite, SWT.NONE);
		cmpIngredients.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		RowLayout rl_cmpIngredients = new RowLayout(SWT.HORIZONTAL);
		rl_cmpIngredients.spacing = 0;
		cmpIngredients.setLayout(rl_cmpIngredients);
		scrolledComposite.setContent(cmpIngredients);
		scrolledComposite.setMinSize(new Point(6, 6));
	}
	
	/**
	 * create the display for the ratings
	 */
	private void createRatingDisplay()
	{
		
		lblStars = new Label[5];
		
		lblStar1 = new Label(shell, SWT.NONE);
		lblStar1.setBounds(683, 499, 16, 16);
		lblStar1.setImage(SWTResourceManager.getImage(FactsWindow.class, "/star-empty.png"));
		lblStars[0] = lblStar1;
		
		Label lblStar2 = new Label(shell, SWT.NONE);
		lblStar2.setBounds(705, 499, 16, 16);
		lblStar2.setImage(SWTResourceManager.getImage(FactsWindow.class, "/star-empty.png"));
		lblStars[1] = lblStar2;
		
		Label lblStar3 = new Label(shell, SWT.NONE);
		lblStar3.setBounds(727, 499, 16, 16);
		lblStar3.setImage(SWTResourceManager.getImage(FactsWindow.class, "/star-empty.png"));
		lblStars[2] = lblStar3;
		
		Label lblStar4 = new Label(shell, SWT.NONE);
		lblStar4.setBounds(749, 499, 16, 16);
		lblStar4.setImage(SWTResourceManager.getImage(FactsWindow.class, "/star-empty.png"));
		lblStars[3] = lblStar4;
		
		Label lblStar5 = new Label(shell, SWT.NONE);
		lblStar5.setBounds(771, 499, 16, 16);
		lblStar5.setImage(SWTResourceManager.getImage(FactsWindow.class, "/star-empty.png"));
		lblStars[4] = lblStar5;
		
		Label lblProductRating = new Label(shell, SWT.NONE);
		lblProductRating.setBounds(576, 499, 101, 20);
		lblProductRating.setFont(SWTResourceManager.getFont("Segoe UI", 11, SWT.NORMAL));
		lblProductRating.setText("Product Rating:");
		
		// setup the click handlers
		lblProductRating.addListener(SWT.MouseUp, new Listener()
		{
			public void handleEvent(Event event) 
			{
				setRating(0, foodHandler);
			}
		});	
		lblStars[0].addListener(SWT.MouseUp, new Listener()
		{
			public void handleEvent(Event event) 
			{
				setRating(1, foodHandler);
			}
		});	
		lblStars[1].addListener(SWT.MouseUp, new Listener()
		{
			public void handleEvent(Event event) 
			{
				setRating(2, foodHandler);
			}
		});	
		lblStars[2].addListener(SWT.MouseUp, new Listener()
		{
			public void handleEvent(Event event) 
			{
				setRating(3, foodHandler);
			}
		});	
		lblStars[3].addListener(SWT.MouseUp, new Listener()
		{
			public void handleEvent(Event event) 
			{
				setRating(4, foodHandler);
			}
		});	
		lblStars[4].addListener(SWT.MouseUp, new Listener()
		{
			public void handleEvent(Event event) 
			{
				setRating(5, foodHandler);
			}
		});	
	}
	
	/**
	 * creates the layout for the display of the nutritional information
	 */
	private void createNutriInfoDisplay()
	{
		lblProductName = new Label(shell, SWT.WRAP);
		lblProductName.setBounds(460, 45, 327, 67);
		lblProductName.setFont(SWTResourceManager.getFont("Segoe UI", 12, SWT.NORMAL));
		lblProductName.setBackground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_BACKGROUND));
		
		compositeNutrition = new Composite(shell, SWT.BORDER);
		compositeNutrition.setBounds(460, 118, 327, 376);
		compositeNutrition.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));

		Label lblValeurNutritive = new Label(compositeNutrition, SWT.NONE);
		lblValeurNutritive.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblValeurNutritive.setFont(SWTResourceManager.getFont("Segoe UI", 12, SWT.BOLD));
		lblValeurNutritive.setBounds(2, 18, 124, 21);
		lblValeurNutritive.setText("Valeur Nutritive");

		Label lblNutritionFacts = new Label(compositeNutrition, SWT.NONE);
		lblNutritionFacts.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblNutritionFacts.setFont(SWTResourceManager.getFont("Segoe UI", 12, SWT.BOLD));
		lblNutritionFacts.setBounds(2, 0, 114, 21);
		lblNutritionFacts.setText("Nutrition Facts");

		lblPortionSize = new Label(compositeNutrition, SWT.NONE);
		lblPortionSize.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblPortionSize.setBounds(3, 39, 319, 15);
		lblPortionSize.setText("Per 0 portion (0 g) / par 0 portion (0 g)");

		Label label = new Label(compositeNutrition, SWT.SEPARATOR | SWT.HORIZONTAL);
		label.setBounds(3, 60, 319, 2);

		Label lblCaloriesCalories = new Label(compositeNutrition, SWT.NONE);
		lblCaloriesCalories.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblCaloriesCalories.setBounds(2, 88, 95, 15);
		lblCaloriesCalories.setText("Calories / Calories");

		Label label_1 = new Label(compositeNutrition, SWT.SEPARATOR | SWT.HORIZONTAL);
		label_1.setBounds(3, 85, 319, 2);

		Label lblTeneur = new Label(compositeNutrition, SWT.NONE);
		lblTeneur.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblTeneur.setFont(SWTResourceManager.getFont("Segoe UI", 7, SWT.NORMAL));
		lblTeneur.setBounds(2, 72, 57, 12);
		lblTeneur.setText("Teneur");

		Label lblAmount = new Label(compositeNutrition, SWT.NONE);
		lblAmount.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblAmount.setFont(SWTResourceManager.getFont("Segoe UI", 7, SWT.NORMAL));
		lblAmount.setBounds(3, 60, 55, 12);
		lblAmount.setText("Amount");

		Label lblValeurQuotidienne = new Label(compositeNutrition, SWT.RIGHT);
		lblValeurQuotidienne.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblValeurQuotidienne.setFont(SWTResourceManager.getFont("Segoe UI", 7, SWT.NORMAL));
		lblValeurQuotidienne.setBounds(232, 72, 88, 12);
		lblValeurQuotidienne.setText("% valeur quotidienne");

		Label lblDailyValue = new Label(compositeNutrition, SWT.RIGHT);
		lblDailyValue.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblDailyValue.setFont(SWTResourceManager.getFont("Segoe UI", 7, SWT.NORMAL));
		lblDailyValue.setBounds(206, 60, 114, 12);
		lblDailyValue.setText("% Daily Value");

		Label label_2 = new Label(compositeNutrition, SWT.SEPARATOR | SWT.HORIZONTAL);
		label_2.setBounds(3, 106, 319, 2);

		Label lblFatLipides = new Label(compositeNutrition, SWT.NONE);
		lblFatLipides.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblFatLipides.setBounds(3, 109, 64, 15);
		lblFatLipides.setText("Fat / Lipides");

		Label label_3 = new Label(compositeNutrition, SWT.SEPARATOR | SWT.HORIZONTAL);
		label_3.setBounds(3, 127, 319, 2);

		Label lblSaturatedSatures = new Label(compositeNutrition, SWT.NONE);
		lblSaturatedSatures.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblSaturatedSatures.setBounds(18, 130, 98, 15);
		lblSaturatedSatures.setText("Saturated / satures");

		Label lblTrans = new Label(compositeNutrition, SWT.NONE);
		lblTrans.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblTrans.setBounds(18, 146, 77, 15);
		lblTrans.setText("+ Trans / trans");

		Label label_4 = new Label(compositeNutrition, SWT.SEPARATOR | SWT.HORIZONTAL);
		label_4.setBounds(3, 164, 319, 2);

		Label lblCholesterolCholesterol = new Label(compositeNutrition, SWT.NONE);
		lblCholesterolCholesterol.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblCholesterolCholesterol.setBounds(3, 167, 131, 15);
		lblCholesterolCholesterol.setText("Cholesterol / Cholesterol");

		Label label_5 = new Label(compositeNutrition, SWT.SEPARATOR | SWT.HORIZONTAL);
		label_5.setBounds(3, 185, 319, 2);

		Label lblSodiumSodium = new Label(compositeNutrition, SWT.NONE);
		lblSodiumSodium.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblSodiumSodium.setBounds(3, 188, 95, 15);
		lblSodiumSodium.setText("Sodium / Sodium");

		Label label_6 = new Label(compositeNutrition, SWT.SEPARATOR | SWT.HORIZONTAL);
		label_6.setBounds(3, 206, 319, 2);

		Label lblCarbohydratesGlucides = new Label(compositeNutrition, SWT.NONE);
		lblCarbohydratesGlucides.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblCarbohydratesGlucides.setBounds(3, 209, 133, 15);
		lblCarbohydratesGlucides.setText("Carbohydrates / Glucides");

		Label label_7 = new Label(compositeNutrition, SWT.SEPARATOR | SWT.HORIZONTAL);
		label_7.setBounds(3, 227, 319, 2);

		lblCaloriesAmount = new Label(compositeNutrition, SWT.NONE);
		lblCaloriesAmount.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblCaloriesAmount.setBounds(103, 88, 55, 15);
		lblCaloriesAmount.setText("0");

		lblFatAmount = new Label(compositeNutrition, SWT.NONE);
		lblFatAmount.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblFatAmount.setBounds(73, 109, 53, 15);
		lblFatAmount.setText("0 g");

		lblFatPercent = new Label(compositeNutrition, SWT.NONE);
		lblFatPercent.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblFatPercent.setAlignment(SWT.RIGHT);
		lblFatPercent.setBounds(264, 109, 55, 15);
		lblFatPercent.setText("0 %");

		lblSaturatedAmount = new Label(compositeNutrition, SWT.NONE);
		lblSaturatedAmount.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblSaturatedAmount.setText("0 g");
		lblSaturatedAmount.setBounds(122, 130, 55, 15);

		lblTransAmount = new Label(compositeNutrition, SWT.NONE);
		lblTransAmount.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblTransAmount.setText("0 g");
		lblTransAmount.setBounds(101, 146, 55, 15);

		lblSaturatedPercent = new Label(compositeNutrition, SWT.NONE);
		lblSaturatedPercent.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblSaturatedPercent.setText("0 %");
		lblSaturatedPercent.setAlignment(SWT.RIGHT);
		lblSaturatedPercent.setBounds(264, 138, 55, 15);

		lblCholesterolPercent = new Label(compositeNutrition, SWT.NONE);
		lblCholesterolPercent.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblCholesterolPercent.setText("0 %");
		lblCholesterolPercent.setAlignment(SWT.RIGHT);
		lblCholesterolPercent.setBounds(264, 167, 55, 15);

		lblSodiumPercent = new Label(compositeNutrition, SWT.NONE);
		lblSodiumPercent.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblSodiumPercent.setText("0 %");
		lblSodiumPercent.setAlignment(SWT.RIGHT);
		lblSodiumPercent.setBounds(264, 188, 55, 15);

		lblCarbohydratesPercent = new Label(compositeNutrition, SWT.NONE);
		lblCarbohydratesPercent.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblCarbohydratesPercent.setText("0 %");
		lblCarbohydratesPercent.setAlignment(SWT.RIGHT);
		lblCarbohydratesPercent.setBounds(264, 209, 55, 15);

		lblCholesterolAmount = new Label(compositeNutrition, SWT.NONE);
		lblCholesterolAmount.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblCholesterolAmount.setText("0 mg");
		lblCholesterolAmount.setBounds(140, 167, 55, 15);

		lblSodiumAmount = new Label(compositeNutrition, SWT.NONE);
		lblSodiumAmount.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblSodiumAmount.setText("0 mg");
		lblSodiumAmount.setBounds(104, 188, 55, 15);

		lblCarbohydratesAmount = new Label(compositeNutrition, SWT.NONE);
		lblCarbohydratesAmount.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblCarbohydratesAmount.setText("0 g");
		lblCarbohydratesAmount.setBounds(142, 209, 55, 15);

		Label lblFibreFibres = new Label(compositeNutrition, SWT.NONE);
		lblFibreFibres.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblFibreFibres.setText("Fibre / Fibres");
		lblFibreFibres.setBounds(18, 230, 68, 15);

		Label label_8 = new Label(compositeNutrition, SWT.SEPARATOR | SWT.HORIZONTAL);
		label_8.setBounds(19, 248, 301, 2);

		Label lblSugarsSucres = new Label(compositeNutrition, SWT.NONE);
		lblSugarsSucres.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblSugarsSucres.setText("Sugars / Sucres");
		lblSugarsSucres.setBounds(18, 251, 80, 15);

		Label label_9 = new Label(compositeNutrition, SWT.SEPARATOR | SWT.HORIZONTAL);
		label_9.setBounds(2, 269, 319, 2);

		Label lblProteinProteines = new Label(compositeNutrition, SWT.NONE);
		lblProteinProteines.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblProteinProteines.setText("Protein / Proteines");
		lblProteinProteines.setBounds(3, 272, 98, 15);

		Label label_10 = new Label(compositeNutrition, SWT.SEPARATOR | SWT.HORIZONTAL);
		label_10.setBounds(2, 290, 319, 2);

		lblFibreAmount = new Label(compositeNutrition, SWT.NONE);
		lblFibreAmount.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblFibreAmount.setText("0 g");
		lblFibreAmount.setBounds(92, 230, 55, 15);

		lblSugarsAmount = new Label(compositeNutrition, SWT.NONE);
		lblSugarsAmount.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblSugarsAmount.setText("0 g");
		lblSugarsAmount.setBounds(103, 251, 55, 15);

		lblProteinAmount = new Label(compositeNutrition, SWT.NONE);
		lblProteinAmount.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblProteinAmount.setText("0 g");
		lblProteinAmount.setBounds(107, 272, 55, 15);

		lblFibrePercent = new Label(compositeNutrition, SWT.NONE);
		lblFibrePercent.setText("0 %");
		lblFibrePercent.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblFibrePercent.setAlignment(SWT.RIGHT);
		lblFibrePercent.setBounds(264, 230, 55, 15);

		Label lblVitaminA = new Label(compositeNutrition, SWT.NONE);
		lblVitaminA.setText("Vitamin A / Vitamine A");
		lblVitaminA.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblVitaminA.setBounds(3, 293, 123, 15);

		Label label_11 = new Label(compositeNutrition, SWT.SEPARATOR | SWT.HORIZONTAL);
		label_11.setBounds(2, 311, 319, 2);

		Label lblVitaminC = new Label(compositeNutrition, SWT.NONE);
		lblVitaminC.setText("Vitamin C / Vitamine C");
		lblVitaminC.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblVitaminC.setBounds(3, 314, 124, 15);

		Label label_12 = new Label(compositeNutrition, SWT.SEPARATOR | SWT.HORIZONTAL);
		label_12.setBounds(2, 332, 319, 2);

		Label lblCalciumCalcium = new Label(compositeNutrition, SWT.NONE);
		lblCalciumCalcium.setText("Calcium / Calcium");
		lblCalciumCalcium.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblCalciumCalcium.setBounds(3, 335, 99, 15);

		Label label_13 = new Label(compositeNutrition, SWT.SEPARATOR | SWT.HORIZONTAL);
		label_13.setBounds(3, 353, 319, 2);

		Label lblIronFer = new Label(compositeNutrition, SWT.NONE);
		lblIronFer.setText("Iron / Fer");
		lblIronFer.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblIronFer.setBounds(3, 356, 48, 15);

		lblVitaminAPercent = new Label(compositeNutrition, SWT.NONE);
		lblVitaminAPercent.setText("0 %");
		lblVitaminAPercent.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblVitaminAPercent.setAlignment(SWT.RIGHT);
		lblVitaminAPercent.setBounds(265, 293, 55, 15);

		lblVitaminCPercent = new Label(compositeNutrition, SWT.NONE);
		lblVitaminCPercent.setText("0 %");
		lblVitaminCPercent.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblVitaminCPercent.setAlignment(SWT.RIGHT);
		lblVitaminCPercent.setBounds(265, 314, 55, 15);

		lblCalciumPercent = new Label(compositeNutrition, SWT.NONE);
		lblCalciumPercent.setText("0 %");
		lblCalciumPercent.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblCalciumPercent.setAlignment(SWT.RIGHT);
		lblCalciumPercent.setBounds(264, 335, 55, 15);

		lblIronPercent = new Label(compositeNutrition, SWT.NONE);
		lblIronPercent.setText("0 %");
		lblIronPercent.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblIronPercent.setAlignment(SWT.RIGHT);
		lblIronPercent.setBounds(264, 356, 55, 15);

		lblCaloriesPercent = new Label(compositeNutrition, SWT.NONE);
		lblCaloriesPercent.setText("0 %");
		lblCaloriesPercent.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblCaloriesPercent.setAlignment(SWT.RIGHT);
		lblCaloriesPercent.setBounds(264, 88, 55, 15);

		lblSugarsPercent = new Label(compositeNutrition, SWT.NONE);
		lblSugarsPercent.setText("0 %");
		lblSugarsPercent.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblSugarsPercent.setAlignment(SWT.RIGHT);
		lblSugarsPercent.setBounds(264, 251, 55, 15);

		lblProteinPercent = new Label(compositeNutrition, SWT.NONE);
		lblProteinPercent.setText("0 %");
		lblProteinPercent.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblProteinPercent.setAlignment(SWT.RIGHT);
		lblProteinPercent.setBounds(264, 272, 55, 15);	
		
		lblVitaminAAmount = new Label(compositeNutrition, SWT.NONE);
		lblVitaminAAmount.setText("0");
		lblVitaminAAmount.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblVitaminAAmount.setBounds(140, 293, 55, 15);
		
		lblVitaminCAmount = new Label(compositeNutrition, SWT.NONE);
		lblVitaminCAmount.setText("0");
		lblVitaminCAmount.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblVitaminCAmount.setBounds(140, 314, 55, 15);
		
		lblCalciumAmount = new Label(compositeNutrition, SWT.NONE);
		lblCalciumAmount.setText("0");
		lblCalciumAmount.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblCalciumAmount.setBounds(140, 335, 55, 15);
		
		lblIronAmount = new Label(compositeNutrition, SWT.NONE);
		lblIronAmount.setText("0");
		lblIronAmount.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
		lblIronAmount.setBounds(140, 356, 55, 15);
		
		/* For ctunit*/
		getValue = new Text(shell, 0);
		getValue.setText("not set");
	}

	/**
	 * Initialize the products list, and select the first one if it exists
	 */
	private void refreshProductList()
	{
		// pull out the search term
		String search = txtSearch.getText().trim();
		FoodItemList foodList = null;
		
		lstProducts.removeAll();		// clear the list
		
		if (search.length() > 2)		// once at least 2 letters are typed in
			foodList = foodHandler.searchFoodItems(search);

		// iterate through the list, add the product names to the display list
		if (foodList != null)
			for (int i = 0; i < foodList.size(); i++)
			{
				lstProducts.add(foodList.get(i).getName());
			}
	}

	/**
	 * method to refresh the display with updated information from a selection
	 *  
	 * @param selection the selected string from the list
	 */
	public void refreshDisplay()
	{
		if (lstProducts.getItemCount() > 0)
		{			
			String selection = lstProducts.getItem(lstProducts.getSelectionIndex());
	
			// retrieve the food item, so we can pull out the nutritional
			// information
			product = foodHandler.getFoodItem(selection);
			
			// set the product label
			lblProductName.setText(selection);
	
			// set the portion size information
			lblPortionSize.setText(foodHandler.getPortionString(product));
			
			// retrieve the ingredients list from the logic layer
			//String ingredients = itemHandler.getIngredientsListString(selection);
			ArrayList<String> ingredients = product.getIngredientsList();
			
			createIngredientsList(ingredients); // set the ingredients textbox
			
			setRating(product.getRating(), foodHandler);		// set the current rating
	
			updateNutriFacts(foodHandler);
		}
	}
	
	public void refreshDisplayWithSuggestion()
	{
		if (lstSuggestions.getItemCount() > 0)
		{	
			String selection = lstSuggestions.getItem(lstSuggestions.getSelectionIndex());
			product = suggestionHandler.getFoodItem(selection);
			
			if (product !=  null)
			{
				// set the product label
				lblProductName.setText(selection);
		
				// set the portion size information
				lblPortionSize.setText(suggestionHandler.getPortionString(product));
				
				// retrieve the ingredients list from the logic layer
				//String ingredients = itemHandler.getIngredientsListString(selection);
				ArrayList<String> ingredients = product.getIngredientsList();
				
				createIngredientsList(ingredients); // set the ingredients textbox
				
				setRating(product.getRating(), suggestionHandler);		// set the current rating
		
				updateNutriFacts(suggestionHandler);
			}
		}
	}
	
	/**
	 * when the scale is changed, update the display of the nutritional information
	 */
	private void updateScale()
	{
		// update the scales in the logic handlers
		foodHandler.setScale(scalePortion.getSelection() / 2.0);
		filterLogic.setScale(scalePortion.getSelection() / 2.0f);
		
		if (product != null)	// if there is a product loaded, refresh the display
			updateNutriFacts(foodHandler);
	}
	
	/**
	 * updates the displayed nutritional facts from the database
	 */
	private void updateNutriFacts(FoodHandler handler)
	{
		// apply all of the filters
		FilterResults results = filterLogic.createResultSet(product);
		
		// set the portion size
		lblPortionSize.setText(handler.getPortionString(product));
		
		// update the amounts and display for the filters
		lblCaloriesAmount.setText(handler.getAmountString(product, NutriType.CALORIES, UnitType.NONE));
		setLabelAttributes(lblCaloriesAmount, results.getResult(NutriType.CALORIES));
		
		lblFatAmount.setText(handler.getAmountString(product, NutriType.FAT, UnitType.GRAMS));
		setLabelAttributes(lblFatAmount, results.getResult(NutriType.FAT));
		
		lblSaturatedAmount.setText(handler.getAmountString(product, NutriType.SATURATED_FAT, UnitType.GRAMS));
		setLabelAttributes(lblSaturatedAmount, results.getResult(NutriType.SATURATED_FAT));
		
		lblTransAmount.setText(handler.getAmountString(product, NutriType.TRANS_FAT, UnitType.GRAMS));
		setLabelAttributes(lblTransAmount, results.getResult(NutriType.TRANS_FAT));
		
		lblCholesterolAmount.setText(handler.getAmountString(product, NutriType.CHOLESTEROL, UnitType.MILLIGRAMS));
		setLabelAttributes(lblCholesterolAmount, results.getResult(NutriType.CHOLESTEROL));
		
		lblSodiumAmount.setText(handler.getAmountString(product, NutriType.SODIUM, UnitType.MILLIGRAMS));
		setLabelAttributes(lblSodiumAmount, results.getResult(NutriType.SODIUM));
		
		lblCarbohydratesAmount.setText(handler.getAmountString(product, NutriType.CARBS, UnitType.GRAMS));
		setLabelAttributes(lblCarbohydratesAmount, results.getResult(NutriType.CARBS));
		
		lblFibreAmount.setText(handler.getAmountString(product, NutriType.FIBRE, UnitType.GRAMS));
		setLabelAttributes(lblFibreAmount, results.getResult(NutriType.FIBRE));
		
		lblSugarsAmount.setText(handler.getAmountString(product, NutriType.SUGAR, UnitType.GRAMS));
		setLabelAttributes(lblSugarsAmount, results.getResult(NutriType.SUGAR));	
		
		lblProteinAmount.setText(handler.getAmountString(product, NutriType.PROTEIN, UnitType.GRAMS));
		setLabelAttributes(lblProteinAmount, results.getResult(NutriType.PROTEIN));
		
		lblVitaminAAmount.setText(handler.getAmountString(product, NutriType.VITAMIN_A, UnitType.NONE));
		setLabelAttributes(lblVitaminAAmount, results.getResult(NutriType.VITAMIN_A));
		
		lblVitaminCAmount.setText(handler.getAmountString(product, NutriType.VITAMIN_C, UnitType.MILLIGRAMS));
		setLabelAttributes(lblVitaminCAmount, results.getResult(NutriType.VITAMIN_C));
		
		lblCalciumAmount.setText(handler.getAmountString(product, NutriType.CALCIUM, UnitType.MILLIGRAMS));
		setLabelAttributes(lblCalciumAmount, results.getResult(NutriType.CALCIUM));
		
		lblIronAmount.setText(handler.getAmountString(product, NutriType.IRON, UnitType.MILLIGRAMS));
		setLabelAttributes(lblIronAmount, results.getResult(NutriType.IRON));

		// calculate the percentages using LOGIC (and the daily amounts)
		lblCaloriesPercent.setText(dailyPercent.getPercentString(product, NutriType.CALORIES, handler.getScale()));
		lblFatPercent.setText(dailyPercent.getPercentString(product, NutriType.FAT, handler.getScale()));
		lblSaturatedPercent.setText(dailyPercent.getPercentString(product, NutriType.SATURATED_FAT, handler.getScale()));
		lblCholesterolPercent.setText(dailyPercent.getPercentString(product, NutriType.CHOLESTEROL, handler.getScale()));
		lblSodiumPercent.setText(dailyPercent.getPercentString(product, NutriType.SODIUM, handler.getScale()));
		lblCarbohydratesPercent.setText(dailyPercent.getPercentString(product, NutriType.CARBS, handler.getScale()));
		lblFibrePercent.setText(dailyPercent.getPercentString(product, NutriType.FIBRE, handler.getScale()));
		lblSugarsPercent.setText(dailyPercent.getPercentString(product, NutriType.SUGAR, handler.getScale()));
		lblProteinPercent.setText(dailyPercent.getPercentString(product, NutriType.PROTEIN, handler.getScale()));
		lblVitaminAPercent.setText(dailyPercent.getPercentString(product, NutriType.VITAMIN_A, handler.getScale()));
		lblVitaminCPercent.setText(dailyPercent.getPercentString(product, NutriType.VITAMIN_C, handler.getScale()));
		lblCalciumPercent.setText(dailyPercent.getPercentString(product, NutriType.CALCIUM, handler.getScale()));
		lblIronPercent.setText(dailyPercent.getPercentString(product, NutriType.IRON, handler.getScale()));
		
		// update the filter score
		lblFilterPercent.setText(results.getFilterCalc() + "%");
	}
	
	/**
	 * Fill the suggestion box with alternative related products to the selected food
	 */
	private void updateSuggestions()
	{	
		// find the selected food
		String selected = lstProducts.getItem(lstProducts.getSelectionIndex());
		FoodItem food = foodHandler.getFoodItem(selected);
		
		FoodItemList suggestions = suggestionHandler.getSuggestions(food);
		
		// clear the suggestion list
		lstSuggestions.removeAll();
		
		// add suggested products to list
		if (suggestions != null)
		{
			for (int i = 0; i < suggestions.size(); i++)
			{
				lstSuggestions.add(suggestions.get(i).getName());
			}
		}
	}
	
	/**
	 * set the rating stars
	 * 
	 * @param x: the int value of the rating
	 */
	private void setRating(int x, FoodHandler handler)
	{
		// reset all the stars
		for (int i = 0; i < 5; i++)
			lblStars[i].setImage(SWTResourceManager.getImage(FactsWindow.class, "/star-empty.png"));
		
		switch (x)
		{
		case 5:
			lblStars[4].setImage(SWTResourceManager.getImage(FactsWindow.class, "/star.png"));
		case 4:
			lblStars[3].setImage(SWTResourceManager.getImage(FactsWindow.class, "/star.png"));
		case 3:
			lblStars[2].setImage(SWTResourceManager.getImage(FactsWindow.class, "/star.png"));
		case 2:
			lblStars[1].setImage(SWTResourceManager.getImage(FactsWindow.class, "/star.png"));
		case 1:
			lblStars[0].setImage(SWTResourceManager.getImage(FactsWindow.class, "/star.png"));
		case 0:
			break;
		}
		
		// the rating in the database
		handler.setFoodRating(product, x);
	}
	
	/**
	 * creates the ingredients list GUI box
	 */
	private void createIngredientsList(ArrayList<String> ingredients)
	{
		String words[];
		String word;
		IngredientFilterResults ingResults = filterLogic.createIngredientResultSet(product);
		org.eclipse.swt.graphics.Color colour;
		
		// clear the old list
		for (int i = 0; i < i_labels.length; i++)
			for (int j = 0; j < i_labels[i].length; j++)
			i_labels[i][j].dispose();
		
		if (ingredients.size() > 0)
		{
			// create the new array
			i_labels = new Label[(ingredients.size() * 2) - 1][0];
			
			for (int i = 0; i < i_labels.length; i = i + 2)		// + 2 for ", " between words
			{
				// determine the colour, based on the ingredient filters
				if (ingResults.containsIngredient(ingredients.get(i / 2)))
					colour = highlight;
				else
					colour = SWTResourceManager.getColor(SWT.COLOR_WHITE);		
				
				// split the label up into separate words, make a label for each one
				words = ingredients.get(i / 2).split(" ");
				
				i_labels[i] = new Label[words.length];
				
				for (int j = 0; j < words.length; j++)
				{
					i_labels[i][j] = new Label(cmpIngredients, SWT.NONE);
					i_labels[i][j].setBackground(colour);
					
					word = words[j];
					
					if (j + 1 < words.length)	// if not last word, add a space
						word += " ";
					
					i_labels[i][j].setText(word);
				}
				
				// draw the comma's, except for the last one
				if ((i + 1) < i_labels.length)
				{
					i_labels[i + 1] = new Label[1];
					i_labels[i + 1][0] = new Label(cmpIngredients, SWT.NONE);
					i_labels[i + 1][0].setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
					i_labels[i + 1][0].setText(", ");
	
				}
			}
		}
		// this is a pretty delicate balancing act, please don't change
		scrolledComposite.setMinSize(cmpIngredients.computeSize(336 - 20, SWT.DEFAULT, true));
		cmpIngredients.layout();
		
	}
	
	/**
	 * sets the labels attributes based on whether a filter failed or not
	 * @param label the label to modify
	 * @param result the result object
	 */
	private void setLabelAttributes(Label label, FilterResult result)
	{
		if (result.passed())
		{
			label.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_BACKGROUND));
			label.setToolTipText("");
		}
		else	// result failed
		{
			label.setBackground(highlight);
			label.setToolTipText(result.getFails());
		}
	}
	
	/******************************CTUNIT METHODS************************************/
	
	/**
	 * Gets a label name specified by the value in
	 * getLabel puts it in getLabels text. So getLabel
	 * stores the earlier specified labels value.
	 * @throws ClassNotFoundException 
	 * @throws NoSuchFieldException 
	 * @throws SecurityException 
	 * @throws IllegalAccessException 
	 * @throws IllegalArgumentException 
	 */
	public void setLabel() 
	throws ClassNotFoundException, SecurityException, NoSuchFieldException, IllegalArgumentException, IllegalAccessException
	{
		Field field;//holds value of field found
		String labelValue = "";
		
		labelValue = getValue.getText();
		field = FactsWindow.class.getDeclaredField(labelValue);
		getValue.setText(((Label)field.get(this)).getText());
	}
	
	/**
	 * See if <code>scrolledComposite</code> value for ingredient tests is
	 * red, ingredient to find is specified by getValue
	 */
	public void getIngedientIsRed()
	{
		String ingredient = getValue.getText();
		Label toFind = null;
		
		//find specified label
		for(Label[] labels : i_labels)
		{
			for(Label label : labels)
			{
				if(label.getText().equals(ingredient))
				{
					toFind = label;
					break;
				}
			}
		}
		if(toFind == null)
			System.out.println("Error: ingredient specified in getValue wasn't found");
		else if(toFind.getBackground().toString().equals(highlight + ""))
			getValue.setText("true");
		else
			getValue.setText("false");
		
		System.out.println();
	}
	
	/**
	 * Checks if a given label (in getValue) is highlighted in <code>highlight</code>
	 * @throws NoSuchFieldException 
	 * @throws SecurityException 
	 * @throws IllegalAccessException 
	 * @throws IllegalArgumentException 
	 */
	public void setIsRed() 
	throws SecurityException, NoSuchFieldException, IllegalArgumentException, IllegalAccessException
	{
		Field field;//holds value of field found
		String labelValue = "";
		
		labelValue = getValue.getText();
		field = FactsWindow.class.getDeclaredField(labelValue);
		labelValue = ((Label)field.get(this)).getBackground().toString();
		
		if (labelValue.equals(highlight + ""))
			getValue.setText("true");
		else
			getValue.setText("false");
	}
	
	/**
	 * Simulates a click on a rating based on <code>getValue</code>
	 */
	public void setRating()
	{
		int starValue = Integer.parseInt(getValue.getText());
		
		setRating(starValue, foodHandler);
	}
	
	/**
	 * Checks if the star specified in <code>getValue</code> is filled.
	 */
	public void checkLabelRating()
	{
		int starValue = Integer.parseInt(getValue.getText());
		Image testImage = SWTResourceManager.getImage(FactsWindow.class, "/star.png");
		
		if(lblStars[starValue].getImage().equals(testImage))
			getValue.setText("true");
		else
			getValue.setText("false");
	}
	
	/**
	 * Sets the scale value to what getValue was set to
	 */
	public void scaleValue()
	{
		int scale = Integer.parseInt(getValue.getText());
		
		scalePortion.setSelection(scale);
		
		//manually update scale
		Rational r = new Rational(scalePortion.getSelection() / 2.0);
		txtScale.setText(r.toString());
		updateScale();
	}
	
	/**
	 * Simulates a click on <code>tltmCreateAndEdit</code>
	 */
	public void openCreateEditFilters()
	{
		filterWindow.open();
	}
	
	/**
	 * Initiates all closing methods
	 */
	public void forceClose()
	{
		shell.close();
	}
}