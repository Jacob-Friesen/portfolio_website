package nutri.presentation;

import java.text.DecimalFormat;

import nutri.presentation.FactsWindow;
import nutri.logic.DailyPercentLogic;
import nutri.objects.NutriFacts;
import nutri.enums.NutriType;

import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Monitor;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Event;

import ctunit.Register;

/**
 * Updates a food item clicked on in the GUI
 */
public class DailyAmountWindow 
{
	private DecimalFormat decimal = new DecimalFormat("#.#");
	
	private FactsWindow factsWindow;	// pointer back to the main window
	
	protected Shell shlCustomizeDailyAmounts;
	private DailyPercentLogic percentLogic;
	private NutriFacts dailyFacts;
	
	private Text txtCalories;
	private Text txtTotalFat;
	private Text txtSaturatedFat;
	private Text txtCholesterol;
	private Text txtSodium;
	private Text txtTotalCarbs;
	private Text txtFibre;
	private Text txtSugar;
	private Text txtTransFat;
	private Text txtProtein;
	private Text txtVitaminA;
	private Text txtVitaminC;
	private Text txtCalcium;
	private Text txtIron;

	DailyAmountWindow (DailyPercentLogic percentLogic,  FactsWindow factsWindow)
	{
		Register.newWindow(this);
		
		this.percentLogic = percentLogic;
		this.factsWindow = factsWindow;
	}
	
	/**
	 * Launch the application.  used for testing the window.
	 * @param args none yet
	 */
	public static void main(String[] args)
	{
		try
		{
			DailyAmountWindow window = new DailyAmountWindow(new DailyPercentLogic(), null);
			window.open();
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open()
	{
		if (shlCustomizeDailyAmounts == null || shlCustomizeDailyAmounts.isDisposed())		// create a new window
		{
			Display display = Display.getDefault();
		    
			// get the daily intake amounts from the database
			dailyFacts = percentLogic.getIntakeAmounts();
			
			createContents();
	
			// center the window
		    Monitor primary = display.getPrimaryMonitor();
		    Rectangle bounds = primary.getBounds();
		    Rectangle rect = shlCustomizeDailyAmounts.getBounds();
		    
		    int x = bounds.x + (bounds.width - rect.width) / 2;
		    int y = bounds.y + (bounds.height - rect.height) / 2;
	
		    shlCustomizeDailyAmounts.setLocation(x, y);
			
			shlCustomizeDailyAmounts.open();
			shlCustomizeDailyAmounts.layout();
			while (!shlCustomizeDailyAmounts.isDisposed())
			{
				if (!display.readAndDispatch())
				{
					display.sleep();
				}
			}
		}
		else		// there is a window, display it
			shlCustomizeDailyAmounts.forceFocus();
	}
	
	/**
	 * close the window
	 */
	public void close()
	{
		if (shlCustomizeDailyAmounts != null && !shlCustomizeDailyAmounts.isDisposed())
			shlCustomizeDailyAmounts.close();
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents()
	{
		shlCustomizeDailyAmounts = new Shell(SWT.TITLE | SWT.MIN | SWT.CLOSE | SWT.BORDER);
		shlCustomizeDailyAmounts.setImage(SWTResourceManager.getImage(DailyAmountWindow.class, "/fruit.png"));
		shlCustomizeDailyAmounts.setSize(492, 503);
		shlCustomizeDailyAmounts.setText("Customize Daily Amounts");
		
		Label lblCalorieIntake = new Label(shlCustomizeDailyAmounts, SWT.NONE);
		lblCalorieIntake.setAlignment(SWT.RIGHT);
		lblCalorieIntake.setBounds(88, 32, 96, 15);
		lblCalorieIntake.setText("Calorie Intake:");
		
		txtCalories = new Text(shlCustomizeDailyAmounts, SWT.BORDER);
		txtCalories.setText("2000");
		txtCalories.setBounds(196, 29, 105, 21);
		
		Label lblTotalFat = new Label(shlCustomizeDailyAmounts, SWT.NONE);
		lblTotalFat.setAlignment(SWT.RIGHT);
		lblTotalFat.setBounds(111, 59, 73, 15);
		lblTotalFat.setText("Total Fat:");
		
		txtTotalFat = new Text(shlCustomizeDailyAmounts, SWT.BORDER);
		txtTotalFat.setText("65");
		txtTotalFat.setBounds(196, 56, 76, 21);
		
		Label lblG = new Label(shlCustomizeDailyAmounts, SWT.NONE);
		lblG.setBounds(278, 59, 55, 15);
		lblG.setText("grams");
		
		txtSaturatedFat = new Text(shlCustomizeDailyAmounts, SWT.BORDER);
		txtSaturatedFat.setText("20");
		txtSaturatedFat.setBounds(196, 83, 76, 21);
		
		Label lblSaturatedFat = new Label(shlCustomizeDailyAmounts, SWT.NONE);
		lblSaturatedFat.setAlignment(SWT.RIGHT);
		lblSaturatedFat.setBounds(79, 86, 105, 15);
		lblSaturatedFat.setText("Saturated Fat:");
		
		txtCholesterol = new Text(shlCustomizeDailyAmounts, SWT.BORDER);
		txtCholesterol.setText("300");
		txtCholesterol.setBounds(196, 137, 76, 21);
		
		Label label = new Label(shlCustomizeDailyAmounts, SWT.NONE);
		label.setText("grams");
		label.setBounds(278, 86, 55, 15);
		
		Label lblMilligrams = new Label(shlCustomizeDailyAmounts, SWT.NONE);
		lblMilligrams.setText("milligrams");
		lblMilligrams.setBounds(278, 140, 73, 15);
		
		Label lblCholesterol = new Label(shlCustomizeDailyAmounts, SWT.NONE);
		lblCholesterol.setAlignment(SWT.RIGHT);
		lblCholesterol.setBounds(111, 140, 74, 15);
		lblCholesterol.setText("Cholesterol:");
		
		txtSodium = new Text(shlCustomizeDailyAmounts, SWT.BORDER);
		txtSodium.setText("2400");
		txtSodium.setBounds(196, 164, 76, 21);
		
		Label label_1 = new Label(shlCustomizeDailyAmounts, SWT.NONE);
		label_1.setText("milligrams");
		label_1.setBounds(278, 167, 73, 15);
		
		Label lblSodium = new Label(shlCustomizeDailyAmounts, SWT.NONE);
		lblSodium.setAlignment(SWT.RIGHT);
		lblSodium.setBounds(129, 167, 55, 15);
		lblSodium.setText("Sodium:");
		
		txtTotalCarbs = new Text(shlCustomizeDailyAmounts, SWT.BORDER);
		txtTotalCarbs.setText("300");
		txtTotalCarbs.setBounds(196, 191, 76, 21);
		
		Label label_2 = new Label(shlCustomizeDailyAmounts, SWT.NONE);
		label_2.setText("grams");
		label_2.setBounds(278, 194, 55, 15);
		
		Label lblTotalCarbs = new Label(shlCustomizeDailyAmounts, SWT.NONE);
		lblTotalCarbs.setAlignment(SWT.RIGHT);
		lblTotalCarbs.setBounds(88, 194, 96, 15);
		lblTotalCarbs.setText("Total Carbs:");
		
		txtFibre = new Text(shlCustomizeDailyAmounts, SWT.BORDER);
		txtFibre.setText("25");
		txtFibre.setBounds(196, 218, 76, 21);
		
		Label label_3 = new Label(shlCustomizeDailyAmounts, SWT.NONE);
		label_3.setText("grams");
		label_3.setBounds(278, 221, 55, 15);
		
		Label lblFibre = new Label(shlCustomizeDailyAmounts, SWT.NONE);
		lblFibre.setAlignment(SWT.RIGHT);
		lblFibre.setBounds(129, 221, 55, 15);
		lblFibre.setText("Fibre:");
		
		txtSugar = new Text(shlCustomizeDailyAmounts, SWT.BORDER);
		txtSugar.setBounds(196, 245, 76, 21);
		
		Label lblGrams = new Label(shlCustomizeDailyAmounts, SWT.NONE);
		lblGrams.setBounds(278, 248, 55, 15);
		lblGrams.setText("grams");
		
		Label lblSugar = new Label(shlCustomizeDailyAmounts, SWT.NONE);
		lblSugar.setAlignment(SWT.RIGHT);
		lblSugar.setBounds(129, 248, 55, 15);
		lblSugar.setText("Sugar:");
		
		txtTransFat = new Text(shlCustomizeDailyAmounts, SWT.BORDER);
		txtTransFat.setBounds(196, 110, 76, 21);
		
		Label lblTransFat = new Label(shlCustomizeDailyAmounts, SWT.NONE);
		lblTransFat.setAlignment(SWT.RIGHT);
		lblTransFat.setBounds(129, 113, 55, 15);
		lblTransFat.setText("Trans Fat:");
		
		Label lblGrams_1 = new Label(shlCustomizeDailyAmounts, SWT.NONE);
		lblGrams_1.setBounds(278, 113, 55, 15);
		lblGrams_1.setText("grams");
		
		txtProtein = new Text(shlCustomizeDailyAmounts, SWT.BORDER);
		txtProtein.setBounds(196, 272, 76, 21);
		
		Label lblGrams_2 = new Label(shlCustomizeDailyAmounts, SWT.NONE);
		lblGrams_2.setBounds(278, 275, 55, 15);
		lblGrams_2.setText("grams");
		
		Label lblProtein = new Label(shlCustomizeDailyAmounts, SWT.NONE);
		lblProtein.setAlignment(SWT.RIGHT);
		lblProtein.setBounds(129, 275, 55, 15);
		lblProtein.setText("Protein:");
		
		txtVitaminA = new Text(shlCustomizeDailyAmounts, SWT.BORDER);
		txtVitaminA.setText("5000");
		txtVitaminA.setBounds(196, 299, 76, 21);
		
		txtVitaminC = new Text(shlCustomizeDailyAmounts, SWT.BORDER);
		txtVitaminC.setText("60");
		txtVitaminC.setBounds(196, 326, 76, 21);
		
		txtCalcium = new Text(shlCustomizeDailyAmounts, SWT.BORDER);
		txtCalcium.setText("1000");
		txtCalcium.setBounds(196, 353, 76, 21);
		
		txtIron = new Text(shlCustomizeDailyAmounts, SWT.BORDER);
		txtIron.setText("18");
		txtIron.setBounds(196, 380, 76, 21);
		
		Label lblVitaminA = new Label(shlCustomizeDailyAmounts, SWT.NONE);
		lblVitaminA.setAlignment(SWT.RIGHT);
		lblVitaminA.setBounds(111, 302, 73, 15);
		lblVitaminA.setText("Vitamin A:");
		
		Label lblVitaminC = new Label(shlCustomizeDailyAmounts, SWT.NONE);
		lblVitaminC.setAlignment(SWT.RIGHT);
		lblVitaminC.setBounds(111, 329, 73, 15);
		lblVitaminC.setText("Vitamin C:");
		
		Label lblNewLabel = new Label(shlCustomizeDailyAmounts, SWT.NONE);
		lblNewLabel.setBounds(278, 302, 55, 15);
		lblNewLabel.setText("IU");
		
		Label lblMilligrams_1 = new Label(shlCustomizeDailyAmounts, SWT.NONE);
		lblMilligrams_1.setBounds(278, 329, 55, 15);
		lblMilligrams_1.setText("milligrams");
		
		Label lblCalcium = new Label(shlCustomizeDailyAmounts, SWT.NONE);
		lblCalcium.setAlignment(SWT.RIGHT);
		lblCalcium.setBounds(129, 356, 55, 15);
		lblCalcium.setText("Calcium:");
		
		Label lblMilligrams_2 = new Label(shlCustomizeDailyAmounts, SWT.NONE);
		lblMilligrams_2.setBounds(278, 356, 55, 15);
		lblMilligrams_2.setText("milligrams");
		
		Label lblIron = new Label(shlCustomizeDailyAmounts, SWT.NONE);
		lblIron.setAlignment(SWT.RIGHT);
		lblIron.setBounds(129, 383, 55, 15);
		lblIron.setText("Iron:");
		
		Label lblMilligrams_3 = new Label(shlCustomizeDailyAmounts, SWT.NONE);
		lblMilligrams_3.setBounds(278, 383, 55, 15);
		lblMilligrams_3.setText("milligrams");
		
		Button btnCancel = new Button(shlCustomizeDailyAmounts, SWT.NONE);
		btnCancel.setBounds(391, 430, 75, 25);
		btnCancel.setText("Close");
		btnCancel.addListener(SWT.Selection, new Listener()
		{
			public void handleEvent(Event event) {
				// close the window
				shlCustomizeDailyAmounts.close();
			}
		});
		
		Button btnSaveChanges = new Button(shlCustomizeDailyAmounts, SWT.NONE);
		btnSaveChanges.setBounds(276, 430, 105, 25);
		btnSaveChanges.setText("Save Changes");
		btnSaveChanges.addListener(SWT.Selection, new Listener()
		{
			public void handleEvent(Event event) 
			{
				saveAmounts();
			}
		});
		
		Button btnResetToDefaults = new Button(shlCustomizeDailyAmounts, SWT.NONE);
		btnResetToDefaults.setBounds(10, 430, 115, 25);
		btnResetToDefaults.setText("Reset to Defaults");
		btnResetToDefaults.addListener(SWT.Selection, new Listener()
		{
			public void handleEvent(Event event) 
			{
				resetAmounts();
			}
		});
		
		refreshAmounts();
	}
	
	/**
	 * refresh the amounts displayed on the page
	 */
	private void refreshAmounts()
	{
		txtCalories.setText(String.valueOf(decimal.format(dailyFacts.getAmount(NutriType.CALORIES))));
		txtTotalFat.setText(String.valueOf(decimal.format(dailyFacts.getAmount(NutriType.FAT))));
		txtSaturatedFat.setText(String.valueOf(decimal.format(dailyFacts.getAmount(NutriType.SATURATED_FAT))));
		txtCholesterol.setText(String.valueOf(decimal.format(dailyFacts.getAmount(NutriType.CHOLESTEROL) * 1000)));
		txtSodium.setText(String.valueOf(decimal.format(dailyFacts.getAmount(NutriType.SODIUM) * 1000)));
		txtTotalCarbs.setText(String.valueOf(decimal.format(dailyFacts.getAmount(NutriType.CARBS))));
		txtFibre.setText(String.valueOf(decimal.format(dailyFacts.getAmount(NutriType.FIBRE))));
		txtSugar.setText(String.valueOf(decimal.format(dailyFacts.getAmount(NutriType.SUGAR))));
		txtTransFat.setText(String.valueOf(decimal.format(dailyFacts.getAmount(NutriType.TRANS_FAT))));
		txtProtein.setText(String.valueOf(decimal.format(dailyFacts.getAmount(NutriType.PROTEIN))));
		txtVitaminA.setText(String.valueOf(decimal.format(dailyFacts.getAmount(NutriType.VITAMIN_A))));
		txtVitaminC.setText(String.valueOf(decimal.format(dailyFacts.getAmount(NutriType.VITAMIN_C) * 1000)));
		txtCalcium.setText(String.valueOf(decimal.format(dailyFacts.getAmount(NutriType.CALCIUM) * 1000)));
		txtIron.setText(String.valueOf(decimal.format(dailyFacts.getAmount(NutriType.IRON) * 1000)));	
	}
	
	/**
	 * reset the amounts to the daily defaults
	 */
	private void resetAmounts()
	{
		dailyFacts = percentLogic.getDefaultIntakeAmounts();
		refreshAmounts();
	}
	
	/**
	 * save the daily amounts to the persistence layer
	 */
	private void saveAmounts()
	{
		dailyFacts.updateFact(NutriType.CALORIES, getDouble(txtCalories));
		dailyFacts.updateFact(NutriType.FAT, getDouble(txtTotalFat));
		dailyFacts.updateFact(NutriType.SATURATED_FAT, getDouble(txtSaturatedFat));
		dailyFacts.updateFact(NutriType.CHOLESTEROL, getDouble(txtCholesterol) / 1000);
		dailyFacts.updateFact(NutriType.SODIUM, getDouble(txtSodium) / 1000);
		dailyFacts.updateFact(NutriType.CARBS, getDouble(txtTotalCarbs));
		dailyFacts.updateFact(NutriType.FIBRE, getDouble(txtFibre));
		dailyFacts.updateFact(NutriType.SUGAR, getDouble(txtSugar));
		dailyFacts.updateFact(NutriType.TRANS_FAT, getDouble(txtTransFat));
		dailyFacts.updateFact(NutriType.PROTEIN, getDouble(txtProtein));
		dailyFacts.updateFact(NutriType.VITAMIN_A, getDouble(txtVitaminA));
		dailyFacts.updateFact(NutriType.VITAMIN_C, getDouble(txtVitaminC) / 1000);
		dailyFacts.updateFact(NutriType.CALCIUM, getDouble(txtCalcium) / 1000);
		dailyFacts.updateFact(NutriType.IRON, getDouble(txtIron) / 1000);
		
		percentLogic.updateIntakeAmounts(dailyFacts);
		factsWindow.refreshDisplay();
	}
	
	/**
	 * gets the double value of a textbox, or returns 0
	 * 
	 * @param t: the textbox
	 * @return: a double value
	 */
	private Double getDouble(Text t)
	{
		try {
		    return Double.parseDouble(t.getText());
		}
		catch (NumberFormatException e) {
		    return 0.0;
		}
	}
}
