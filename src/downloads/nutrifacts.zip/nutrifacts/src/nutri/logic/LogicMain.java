package nutri.logic;

import nutri.application.Services;
import nutri.persistence.IDataAccess;
import nutri.presentation.FactsWindow;

/**
 * Manages start up of the application and all logic classes.
 */
public class LogicMain
{
	private FoodHandler foodHandler;
	private SuggestionHandler suggestionHandler;
	private IngredientFilterHandler ingrHandler;
	private NutriFilterHandler nutriHandler;
	
	private IDataAccess dataAccess;

	public LogicMain()
	{
		dataAccess = Services.getDataAccess();
		foodHandler = new FoodHandler(dataAccess);
		suggestionHandler = new SuggestionHandler(dataAccess);
		ingrHandler = new IngredientFilterHandler(dataAccess);
		nutriHandler = new NutriFilterHandler(dataAccess);
	}

	/**
	 * initialize the <code>FoodItem</code> list and the GUI
	 */
	public void init(FactsWindow window)
	{	
		new FactsWindow(foodHandler, suggestionHandler, ingrHandler, nutriHandler);
	}
}
