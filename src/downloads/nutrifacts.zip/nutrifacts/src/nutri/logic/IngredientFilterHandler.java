package nutri.logic;

import java.util.ArrayList;

import nutri.objects.IngredientFilters;
import nutri.persistence.IDataAccess;

/**
 * Manages everything to do with user ingredients filters,
 * as well as retrieving a unique list of ingredients from the
 * database.<br/>
 * <br/>
 * Updates database when any ingredient is updated.
 * 
 */
public class IngredientFilterHandler 
{	
	private IDataAccess dataAccess;
	private IngredientFilters ingrFilters;
	
	public IngredientFilterHandler(IDataAccess dataAccess)
	{
		this.dataAccess = dataAccess;
		
		loadIngredients();
	}
	
	/**
	 * loads all ingredient filters from the database into this class,
	 * if unique.
	 */
	public void loadIngredients()
	{
		ingrFilters = new IngredientFilters();	// create a new list
		
		for (String ingredient : dataAccess.getAllIngredientFilters())
		{
			if(!ingrFilters.contains(ingredient))
				ingrFilters.addIngredient(ingredient);
		}
	}
	
	/**
	 * returns all the unique ingredients from the database
	 * for use in the the list of ingredients to filter with
	 * 
	 * @return the unique ingredient list in 
	 * <code>ArrayList</code> form
	 */
	public ArrayList<String> getAllIngredients()
	{
		return dataAccess.getAllIngredients();
	}
	
	/**
	 * loads all ingredient filters from the database, and
	 * returns them as an <code>IngredientFilters</code> object
	 * 
	 * @return the ingredient filters
	 */
	public IngredientFilters getAllIngredientFilters()
	{
		loadIngredients();
		return ingrFilters;
	}
	
	/**
	 * adds an ingredient filter to the database, and
	 * to the member variable if not null
	 * 
	 * @param ingredient a string ingredient filter
	 */
	public void addIngredient(String ingredient)
	{
		if(!ingrFilters.contains(ingredient) && ingredient != null)
		{
			ingrFilters.addIngredient(ingredient);
			dataAccess.addIngredientFilter(ingredient);
		}
	}
	
	/**
	 * delete an ingredient filter, both from the database
	 * and from the member variable
	 * 
	 * @param ingredient a string ingredient filter
	 */
	public void deleteIngredient(String ingredient)
	{
		ingrFilters.deleteIngredient(ingredient);
		dataAccess.deleteIngredientFilter(ingredient);
	}

}
