package nutri.logic;

import nutri.objects.FilterResults;
import nutri.objects.FoodItem;
import nutri.objects.FoodItemList;
import nutri.persistence.IDataAccess;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

/**
 * Handles the logic for the food suggestions
 *
 */
public class SuggestionHandler extends FoodHandler
{
	public static final int TOLERANCE = 2;//lower is higher tolerance
	private IDataAccess data;
	
	public SuggestionHandler(IDataAccess dataAccess) 
	{
		super(dataAccess);
		data = dataAccess;
	}

	/**
	 * Return a list of related, possibly better suited, food items
	 * 
	 * @param food the initial food to relate to
	 * @return the list of foods that are suggested for the given
	 * food item.
	 */
	public FoodItemList getSuggestions(FoodItem food)
	{	
		foodItems = data.getSimilarFoodsByCategory(food);
		
		// try to get at least ten
		if (foodItems.size() < 10)
			getSimilarByNutrifact(food);
		
		// apply filters
		ArrayList<FoodItem> suggestions = foodItems.getFoodList();
		
		Collections.sort(suggestions, new SuggestionComparator());
		
		if(suggestions.size() > 10)
			suggestions.subList(10, suggestions.size()).clear();

		return foodItems;
	}
	
	/**
	 * Uses the nutrifacts similarity (in persistence) method to 
	 * get foodItems related to the specified food item.
	 * 
	 * @param food the initial food to relate to
	 * @return the list of foods that are suggested for the given
	 * food item.
	 */
	private void getSimilarByNutrifact(FoodItem food)
	{
		FoodItemList foods2 = data.getSimilarFoodsByNutrifacts(food, TOLERANCE);
		
		if (foodItems.size() == 0)
			foodItems = foods2;
		else
		{	
			Map<String,FoodItem> removeDuplicates = new HashMap<String,FoodItem>();

			for (int i = 0; i < foodItems.size(); i++)
			{
				FoodItem curr = foodItems.get(i);
				removeDuplicates.put(curr.getName(), curr);
			}
			
			for (int i = 0; i < foods2.size(); i++)
			{
				FoodItem curr = foods2.get(i);
				removeDuplicates.put(curr.getName(), curr);
			}
			
			foodItems = new FoodItemList(removeDuplicates.values());
		}
	}
	
	/**
	 * Comparator for Suggestions - better suggestions have 
	 *
	 */
	public static class SuggestionComparator implements Comparator<FoodItem>
	{
		private FilterLogic filterLogic;
		public final static double FILTER_WEIGHT = 0.70;
		public final static double RATING_WEIGHT = 0.30;
		
		public SuggestionComparator()
		{
			filterLogic = new FilterLogic();
		}
		
		public int compare(FoodItem o1, FoodItem o2) 
		{		
			FilterResults filterValue1 = filterLogic.createResultSet(o1);
			FilterResults filterValue2 = filterLogic.createResultSet(o2);
			
			int filterScore1 = filterValue1.getFilterCalc();
			int filterScore2 = filterValue2.getFilterCalc();
			
			int rating1 = o1.getRating();
			int rating2 = o2.getRating();
			
			double score1 = ((filterScore1*FILTER_WEIGHT) + ((((double)rating1/5.0)*100)*RATING_WEIGHT));
			double score2 = ((filterScore2*FILTER_WEIGHT) + ((((double)rating2/5.0)*100)*RATING_WEIGHT));
			
			// a higher score is better
			if (score1 > score2)
			{
				return -1;
			}
			if (score1 < score2)
			{
				return 1;
			}
			if (score1 == score2)
			{
				return o1.compareTo(o2);
			}

			return 0;
		}
	}
}
