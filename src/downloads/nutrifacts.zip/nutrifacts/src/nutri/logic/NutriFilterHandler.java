package nutri.logic;

import nutri.objects.NutriFilter;
import nutri.objects.NutriFilterList;
import nutri.persistence.IDataAccess;

/**
 * Manages everything to do with filters, on any
 * filter update also updates the database.
 */
public class NutriFilterHandler 
{
	private IDataAccess dataAccess;
	private NutriFilterList filters;
	
	public NutriFilterHandler(IDataAccess dataAccess)
	{
		this.dataAccess = dataAccess;
		filters = new NutriFilterList();
		
		loadFilterData();
	}
	
	/**
	 * retrieves all the filter data from the database, and
	 * puts it into the <code>NutriFilterList</code> for
	 * this class
	 */
	private void loadFilterData()
	{
		NutriFilterList tempFilters = dataAccess.getAllFilters();
		
		//must do a deep copy, because of stub database
		filters = new NutriFilterList();
		for (int count = 0; count < tempFilters.size(); count++)
		{
			filters.addFilter(tempFilters.getFilter(count));
		}
	}
	
	/**
	 * get all the filters from the database, and return them
	 * 
	 * @return all filters from the database
	 */
	public NutriFilterList getAllFilters()
	{
		loadFilterData();
		return filters;
	}

	/**
	 * adds a unique filter to the collection, and writes to the database
	 * 
	 * @param filter a nutritional filter
	 */
	public void addFilter(NutriFilter filter)
	{
		if(filter != null && findNutriValue(filter) == false)
		{
			filters.addFilter(filter);
			dataAccess.addFilter(filter);
		}
	}
	
	/**
	 * finds a given value in a <code>nutriFilterList</code>
	 */
	public boolean findNutriValue(NutriFilter toFind)
	{
		boolean foundValue = false;
		
		for (NutriFilter filter : filters.getAllFilters())
		{
			if(filter.toString().equals(toFind.toString()))
			{
				foundValue = true;
				break;
			}
		}
		
		return foundValue;
	}

	/**
	 * updates a filter in the collection, and database
	 * 
	 * @param oldValue original filter data
	 * @param newValue new filter data
	 */
	public void updateFilter(NutriFilter oldValue, NutriFilter newValue)
	{
		if(oldValue != null && newValue != null && filters.indexOf(oldValue) > -1)
		{
			filters.updateFilter(filters.indexOf(oldValue), newValue);
			dataAccess.updateFilter(oldValue, newValue);
		}
	}

	/**
	 * removes a filter from the collection, and database
	 * 
	 * @param filter the filter to be removed
	 */
	public void deleteFilter(NutriFilter filter)
	{
		if(filter != null)
		{
			filters.deleteFilter(filter);
			dataAccess.deleteFilter(filter);
		}
	}
	
}
