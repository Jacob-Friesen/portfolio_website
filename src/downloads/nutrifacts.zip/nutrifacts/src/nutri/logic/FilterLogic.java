package nutri.logic;

import java.util.ArrayList;

import nutri.application.Services;
import nutri.enums.*;
import nutri.objects.*;

/**
 * This class represents the logic used to apply filters to <code>foodItem</code>
 * objects and return a collection of results. For use by the display to show the
 * nutritional information after the application of a filter, to the user.
 * 
 */

public class FilterLogic 
{

	// filter logic needs access to the filters and ingredient filters in the database
	private NutriFilterHandler filterAccess;
	private IngredientFilterHandler ingFilterAccess;
	
	float scale;		// scale that the user is viewing
	
	
	public FilterLogic ()
	{
		filterAccess = new NutriFilterHandler(Services.getDataAccess());
		ingFilterAccess = new IngredientFilterHandler(Services.getDataAccess());
		this.scale = 1f;
	}
	
	/**
	 * set the value that nutritional amounts will be scaled with
	 * 
	 * @param scale the scale to multiply amounts by
	 */
	public void setScale(final float scale)
	{
		this.scale = scale;
	}
	
	/**
	 * creates a result set of all of the filter results, parallel to a NutriFacts object
	 * 
	 * @param food a <code>foodItem</code> to test against
	 */
	public FilterResults createResultSet(final FoodItem food)
	{
		FilterResults results = new FilterResults();
		NutriFilterList filters = filterAccess.getAllFilters();
		
		applyFilters(food, filters, results);	// apply the nutriFilters to the result
		
		return results;
	}
	
	/**
	 * generate a result set of the ingredients in a food item that are filtered
	 * 
	 * @param food a <code>foodItem</code>
	 * @return a result set of filtered ingredients
	 */
	public IngredientFilterResults createIngredientResultSet(final FoodItem food)
	{
		IngredientFilterResults results = new IngredientFilterResults();
		IngredientFilters ingFilters = ingFilterAccess.getAllIngredientFilters();
		ArrayList<String> ings = food.getIngredients().getList();
		
		// iterate through and compare the strings
		for (int i = 0; i < ings.size(); i++)
			if (ingFilters.contains(ings.get(i)))
				results.filterIngredient(ings.get(i));
		
		return results;
	}
	
	/**
	 * apply all the <code>nutriFilter</code>'s from the database to the food item,
	 * and update the results
	 * 
	 * @param food the food item
	 * @param results the results of the filtering
	 */
	public void applyFilters(final FoodItem food, final NutriFilterList filters, FilterResults results)
	{
		FilterResult result;
		NutriType[] types = NutriType.values();
		
		// iterate through the nutriTypes, and try to apply all filters to it
		for (int i = 0; i < types.length; i++)
		{
			result = new FilterResult();		// create a new result
			
			for (int j = 0; j < filters.size(); j++)
			{
				if (filters.getFilter(j).isActive() &&						// if filter is active
						filters.getFilter(j).getNutriType() == types[i])	// if nutritypes match, try to filter
				{
					if (evaluateFilter(food.getFact(types[i]), filters.getFilter(j)))
						results.pass();
					else	// fail the result, too bad :(
					{
						results.fail();		// count the fail
						result.fail();		// fail the result
						result.addFilterString(filters.getFilter(j).toString());
					}
				}
			}
			
			// add the result to the results collection
			results.updateResult(types[i], result);
		}		
	}
	
	/**
	 * tests a <code>nutriFact</code> against a <code>nutriFilter</code>, and returns
	 * true or false
	 * 
	 * @param nutriFact the <code>nutriFact</code> object
	 * @param filter the user specified <code>nutriFilter</code>
	 * @return true or false, if the filter passes
	 */
	public boolean evaluateFilter(final NutriFact nutriFact, final NutriFilter filter)
	{
		boolean result = true;
		
		// may need to convert the values
		double nutriFactAmount = nutriFact.amount() * scale;		// in grams
		double filterAmount = filter.getValue();
		
		if (filter.getUnit() == UnitType.MILLIGRAMS)
			filterAmount /= 1000;
		
		// do the proper test
		switch (filter.getOperator())
		{
		case GREATER:
			if (nutriFactAmount <= filterAmount)
				result = false;
			break;
		case GREATER_OR_EQUAL:
			if (nutriFactAmount < filterAmount)
				result = false;
			break;
		case LESS:
			if (nutriFactAmount >= filterAmount)
				result = false;
			break;
		case LESS_OR_EQUAL:
			if (nutriFactAmount > filterAmount)
				result = false;
			break;
		}
		
		return result;
	}
}