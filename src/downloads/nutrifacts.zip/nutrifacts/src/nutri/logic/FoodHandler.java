package nutri.logic;

import java.util.ArrayList;

import nutri.enums.NutriType;
import nutri.enums.UnitType;
import nutri.objects.FoodItem;
import nutri.objects.FoodItemList;
import nutri.persistence.IDataAccess;

/**
 * Handles the logic for the <code>foodItemList</code>, calculating
 * daily percentages, getting scaled amounts, etc.
 *
 */
public class FoodHandler 
{

	protected FoodItemList foodItems;
	private IDataAccess dataAccess;

	private double scale;
	
	public FoodHandler(IDataAccess dataAccess)
	{
		this.dataAccess = dataAccess;
		foodItems = new FoodItemList();
		
		scale = 1;
	}
	
	/**
	 * load all of the food items from the database into a list
	 */
	public void loadData()
	{
		foodItems = dataAccess.getAllFood();
	}
	
	/**
	 * returns a <code>FoodList</code> for display by the UI
	 * 
	 * @return an <code>ArrayList<code> of <code>FoodItems<code>
	 */
	public ArrayList<FoodItem> getAllFoodItems()
	{
		return foodItems.getFoodList();
	}
	
	/**
	 * seach for a list of fooditems from the foodlist
	 * 
	 * @param s: the search term
	 * @return: the fooditemlist
	 */
	public FoodItemList searchFoodItems(String s)
	{
		foodItems = dataAccess.searchFoodItems(s);
		return foodItems;
	}

	/**
	 * update the rating of a food item in the database
	 * 
	 * @param food: foodname string, primary index
	 * @param i: the rating
	 */
	public void setFoodRating(FoodItem food, int i)
	{
		dataAccess.updateFoodRating(food.getName(), i);
		food.setRating(i);
	}
	
	/**
	 * retrive the foodrating for a food name
	 * 
	 * @param food: the food item
	 * @return: the foods rating
	 */
	public int getFoodRating(FoodItem food)
	{
		return dataAccess.getFoodRating(food.getName());
	}

	/**
	 * gets and returns a <code>FoodItem</code> based on it's name.
	 * 
	 * @param product the product name to retrieve from the 
	 * <code>FoodItem</code> List
	 * 
	 * @return the <code>FoodItem</code> with the sent in product name.
	 */
	public FoodItem getFoodItem(String product)
	{
		FoodItem result = foodItems.getFoodItem(product);
		
		// refresh the fooditem rating
		result.setRating(dataAccess.getFoodRating(product));
		
		return result;
	}
	
	/**
	 * returns the portion string display, to a scaled amount
	 * 
	 * @param product the product name to get the portion of.
	 * 
	 * @return a string representing the portion of the product
	 * sent in.
	 */
	public String getPortionString(FoodItem product)
	{
		return product.getPortionString(scale);
	}

	/**
	 * This method is for retrieving string representations of
	 * the values in a <code>FoodItem</code>. Pass last argument
	 * as <code>""</code> to get no unit appended to the amount.
	 * 
	 * @param product the <code>FoodItem</code> to get the amount of.
	 * @param name the type of amount to return
	 * @param unitNum the unit type to convert the amount to
	 * 
	 * @return the products amount of name in specified units
	 */
	public String getAmountString(FoodItem product, NutriType name, UnitType unitNum)
	{
		int multiplier = 1;
		String unit = " g";//notice the space in front
		
		if(unitNum == UnitType.MILLIGRAMS)
		{
			multiplier = 1000;
			unit = " mg"; 
		}
		else if(unitNum == UnitType.NONE)
			unit = "";
			
		return (int) (product.getAmount(name, scale) * multiplier) + unit;
	}
	
	/**
	 * sets the scale that amounts and percentages will be scaled to
	 * 
	 * @param scale to be set
	 */
	public void setScale(double scale)
	{
		this.scale = scale;
	}
	
	/**
	 * retrieves the scale value set in logic
	 * 
	 * @return a double representing scale
	 */
	public double getScale()
	{
		return scale;
	}
}
