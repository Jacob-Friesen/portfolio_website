package nutri.logic;

import nutri.application.Services;
import nutri.enums.NutriType;
import nutri.objects.DailyIntakeDefaults;
import nutri.objects.FoodItem;
import nutri.objects.NutriFacts;
import nutri.persistence.IDataAccess;

/**
 * Helps in creating a custom object for the presentation layer.
 */
public class DailyPercentLogic 
{
	NutriFacts dailyIntake;
	IDataAccess dataAccess;

	
	
	public DailyPercentLogic()
	{
		dataAccess = Services.getDataAccess();
		dailyIntake = getIntakeAmounts();
	}
	
	/**
	 * uses the daily intake amounts and a product to calculate the daily
	 * amounts of the product
	 * 
	 * @param product a fooditem
	 * @param name the name of the field requested
	 * @param scale the current scale of the slider
	 * @return a string representation of the percentage
	 */
	public String getPercentString(FoodItem product, NutriType name, double scale)
	{
		int percent = calcDailyPercentage(product, name, scale);
		String result = "";

		if (percent >= 0)
			result = percent + " %";

		return result;
	}
	
	/**
	 * calculates the daily percentage based on the defaults or custom values
	 * 
	 * @param product a fooditem
	 * @param name the name of the field requested
	 * @return the percentage as an int
	 */
	public int calcDailyPercentage(FoodItem product, NutriType name, double scale)
	{
		double percent = -1.0;
		double dailyAmount = dailyIntake.getAmount(name);

		if (dailyAmount > 0)
			percent = (product.getAmount(name, scale) / dailyAmount) * 100;

		// round up anything less than 1%
		if (percent > 0 && percent < 1)
			percent = Math.ceil(percent);

		if (percent >= 0)
			return (int) Math.round(percent);
		else
			return -1;
	}

	/**
	 * returns a NutriFacts object storing the daily intake amounts
	 * 
	 * @return a nutrifacts object
	 */
	public NutriFacts getIntakeAmounts()
	{
		NutriFacts dailyIntake = dataAccess.getDailyIntake();
		
		if (dailyIntake == null)
			return getDefaultIntakeAmounts();
		else
			return dailyIntake;
	}

	/**
	 * returns all of the default intake amounts, for initializing the custom
	 * object, or resetting defaults
	 * 
	 * @return nutrifacts of default daily intake
	 */
	public NutriFacts getDefaultIntakeAmounts()
	{
		NutriFacts result = new NutriFacts();

		result.updateFact(NutriType.CALORIES, DailyIntakeDefaults.CALORIES);
		result.updateFact(NutriType.FAT, DailyIntakeDefaults.FAT);
		result.updateFact(NutriType.SATURATED_FAT, DailyIntakeDefaults.SATURATED_FAT);
		result.updateFact(NutriType.TRANS_FAT, 0);
		result.updateFact(NutriType.CHOLESTEROL, DailyIntakeDefaults.CHOLESTEROL);
		result.updateFact(NutriType.SODIUM, DailyIntakeDefaults.SODIUM);
		result.updateFact(NutriType.CARBS, DailyIntakeDefaults.CARBS);
		result.updateFact(NutriType.FIBRE, DailyIntakeDefaults.FIBRE);
		result.updateFact(NutriType.SUGAR, 0);
		result.updateFact(NutriType.PROTEIN, DailyIntakeDefaults.PROTEIN);
		result.updateFact(NutriType.VITAMIN_A, DailyIntakeDefaults.VITAMIN_A);
		result.updateFact(NutriType.VITAMIN_C, DailyIntakeDefaults.VITAMIN_C);
		result.updateFact(NutriType.CALCIUM, DailyIntakeDefaults.CALCIUM);
		result.updateFact(NutriType.IRON, DailyIntakeDefaults.IRON);

		return result;
	}
	
	/**
	 * update the daily intake values in the database. If null is
	 * sent then just update to default values.
	 * 
	 * @param dailyIntake: the dailyintake values
	 */
	public void updateIntakeAmounts(NutriFacts dailyIntake)
	{
		if(dailyIntake == null)
			dailyIntake = getDefaultIntakeAmounts();
		this.dailyIntake = dailyIntake;
		dataAccess.insertDailyIntake(dailyIntake);
	}
}
