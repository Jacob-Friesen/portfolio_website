package nutri.application;

import nutri.presentation.FactsWindow;

public class Main
{
	public static final String dbName = "FOODDB";

	/**
	 * main; starts and shuts down application.
	 * 
	 * @param args none accepted at this time
	 */
	public static void main(String[] args)
	{
		System.out.println("start application");
		startUp();
		new FactsWindow();
		shutDown();
		System.out.println("end application");
	}

	/**
	 * startup the application
	 */
	public static void startUp()
	{
		Services.createDataAccess(dbName);
	}

	/**
	 * shutdown the application
	 */
	public static void shutDown()
	{
		Services.closeDataAccess();
	}
}
