package nutri.application;

import nutri.persistence.*;

/**
 * A class with static methods and a static variable containing the
 * dataAccess layer that all logic will be accessing
 *
 */

public class Services
{
	public static IDataAccess dataAccessService = null;

	/**
	 * creates the dataAccess layer.
	 * 
	 * @param dbName name of the database
	 * @return the dataAccess object
	 */
	public static IDataAccess createDataAccess(String dbName)
	{
		if (dataAccessService == null)
		{
			dataAccessService = new DataAccessObject();
			dataAccessService.open(dbName);
		}

		return dataAccessService;
	}
	
	/**
	 * changes which data access type or database this application is using
	 * 
	 * @param dataAccess the interface to change
	 */
	public static void changeDataAccess(IDataAccess dataAccess, String dbName)
	{
		if (dataAccess != null)
		{
			dataAccessService = dataAccess;
			dataAccess.open(dbName);
		}
	}

	/**
	 * returns the dataAccess object, been previous instantiated
	 * 
	 * @return the dataAccess object
	 */
	public static IDataAccess getDataAccess()
	{
		if (dataAccessService == null)
		{
			System.out.println("Connection to data access has not been established.");
			System.exit(1);
		}
		return dataAccessService;
	}

	/**
	 * close the dataAccess connection
	 */
	public static void closeDataAccess()
	{
		if (dataAccessService != null)
		{
			dataAccessService.close();
		}
		dataAccessService = null;
	}
}