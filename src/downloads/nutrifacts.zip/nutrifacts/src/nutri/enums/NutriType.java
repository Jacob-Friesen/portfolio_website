package nutri.enums;

/**
 * enum type used for passing nutritype between methods
 *
 */

public enum NutriType
{
	CALORIES,
	FAT,
	SATURATED_FAT,
	TRANS_FAT,
	CHOLESTEROL,
	SODIUM,
	CARBS,
	FIBRE,
	SUGAR,
	PROTEIN,
	VITAMIN_A,
	VITAMIN_C,
	CALCIUM,
	IRON
}