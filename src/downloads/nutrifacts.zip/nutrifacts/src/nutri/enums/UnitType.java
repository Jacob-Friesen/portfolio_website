package nutri.enums;

/**
 * enum used when passing the unittype between methods
 *
 */
public enum UnitType
{
	GRAMS,
	MILLIGRAMS,
	NONE
}