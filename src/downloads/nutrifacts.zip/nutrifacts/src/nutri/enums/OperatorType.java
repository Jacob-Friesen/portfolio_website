package nutri.enums;

/**
 * enum used for passing the filter operator type between methods
 *
 */
public enum OperatorType
{
	LESS,
	LESS_OR_EQUAL,
	GREATER,
	GREATER_OR_EQUAL
}