package nutri.persistence;

import java.util.ArrayList;

import nutri.objects.FoodItem;
import nutri.objects.FoodItemList;
import nutri.objects.NutriFilter;
import nutri.objects.NutriFilterList;
import nutri.objects.NutriFacts;

public interface IDataAccess
{
	// set up the database access
	/**
	 * open a connection to the persistence layer
	 */
	public void open(String dbName);

	/**
	 * close a connection to the persistence layer
	 */
	public void close();

	// FoodItems

	/**
	 * get all the food stored in the persistence layer
	 */
	public FoodItemList getAllFood();
	
	/**
	 * search the fooditem list for particular fooditems
	 * 
	 * @param s: a fooditem to search for
	 * @return: a fooditem list
	 */
	public FoodItemList searchFoodItems(String s);

	/**
	 * update a fooditems rating
	 * 
	 * @param food: the string key of the fooditem
	 * @param r: the rating
	 */
	public void updateFoodRating(String food, int r);
	
	/**
	 * return the rating of a food item
	 * 
	 * @param food: name of the food item
	 * @return: the integer rating
	 */
	public int getFoodRating(String food);
	
	// Ingredients

	/**
	 * get all the ingredients stored in the persistence layer
	 */
	public ArrayList<String> getAllIngredients();

	// Filters

	/**
	 * get all the filters stored in the persistence layer
	 */
	public NutriFilterList getAllFilters();

	/**
	 * add a filter to the persistence layer
	 * @param filter to add
	 */
	public void addFilter(NutriFilter filter);

	/**
	 * delete a filter from the persistence layer
	 * @param filter to delete
	 */
	public void deleteFilter(NutriFilter filter);
	
	/**
	 * overwrite and old filter with a new filters value
	 * @param oldValue to be overwritten
	 * @param newValue to overwrite the old value
	 */
	public void updateFilter(NutriFilter oldValue, NutriFilter newValue);
	
	/**
	 * get all ingredient filters in the persistence layer
	 */
	public ArrayList<String> getAllIngredientFilters();
	
	/**
	 * add an ingredient filter to the persistence layer
	 * @param ingredient to add
	 */
	public void addIngredientFilter(String ingredient);

	/**
	 * delete an ingredient filter from the persistence layer
	 * @param ingredient to delete
	 */
	public void deleteIngredientFilter(String ingredient);
	
	// daily intake values
	
	/**
	 * try to get the single daily intake value from the db
	 */
	public NutriFacts getDailyIntake();
	
	/**
	 * insert the daily intake value into the db
	 * @param intake
	 */
	public void insertDailyIntake(NutriFacts intake);
	
	//suggestions
	
	/**
	 * Get FoodItems with specified NutriFact values falling within
	 * a given tolerance +/-|%|
	 * 
	 * @param facts the NutriFacts to compare against 
	 * @param tolerance the tolerance to search within, lower is looser
	 * @return a list of FoodItems
	 */
	public FoodItemList getSimilarFoodsByNutrifacts(FoodItem basis, int tolerance);
	
	/**
	 * Get food items having the same category as a given 
	 * FoodItem
	 * 
	 * @param basis the basis for the suggestion,
	 * @return a list of FoodItems
	 */
	public FoodItemList getSimilarFoodsByCategory(FoodItem basis);

}
