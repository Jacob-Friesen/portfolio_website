package nutri.persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.DriverManager;
import java.util.ArrayList;

//import nutri.objects.*;
import nutri.enums.*;
import nutri.objects.NutriFact;
import nutri.objects.NutriFacts;
import nutri.objects.NutriFilter;
import nutri.objects.FoodItemList;
import nutri.objects.FoodItem;
import nutri.objects.NutriFilterList;

/**
 * Manages connection to a real database. Can retrieve and set objects from it.
 */
public class DataAccessObject implements IDataAccess
{
	private String dbName;
	private Connection connection;

	
	public DataAccessObject()
	{
		
	}

	/**
	 * opens a connection to the database name which was specified in the
	 * constructor
	 */
	public void open(String dbName)
	{
		this.dbName = dbName;
		
		String url;
		try
		{
			// Setup for HSQL
			Class.forName("org.hsqldb.jdbcDriver").newInstance();
			url = "jdbc:hsqldb:database\\" + dbName; // stored on disk mode
			connection = DriverManager.getConnection(url, "SA", "");
		}
		catch (Exception e)
		{
			processSQLError(e);
			System.exit(1);
		}
		System.out.println("Opened database " + dbName);
	}

	/**
	 * closes the connection to the database name which was specified in the
	 * constructor
	 */
	public void close()
	{
		try
		{	// commit all changes to the database
			Statement stmt = connection.createStatement();
			
			stmt.executeQuery("SHUTDOWN COMPACT");
			
			connection.close();
		}
		catch (Exception e)
		{
			processSQLError(e);
		}
		System.out.println("Closed database " + dbName);
	}
	
	/**
	 * creates a <code>FoodItemList</code> of all foods in
	 * the data base
	 * 
	 * @return list of all foods in the database
	 */	
	public FoodItemList getAllFood()
	{
		return searchFoodItems(null);		// return all fooditems
	}
	
	/**
	 * search the fooditems database for any food items
	 * containing the string s
	 * 
	 * @param s: the string to search for
	 * @return: food items containing the string
	 */
	public FoodItemList searchFoodItems(String s)
	{	
		FoodItemList allFood = null;
		String querystring = "select * from FOOD";

		// add the search term
		if (s != null)
			//querystring += " where upper(FOOD_NAME) like '%" + s.toUpperCase() + "%'";
			querystring += " where UPPER_NAME like '%" + s.toUpperCase() + "%'";
		
		try
		{
			Statement query1;
			ResultSet queryResult1;

			query1 = connection.createStatement();
			queryResult1 = query1.executeQuery(querystring);
			
			allFood = parseFoodItemQueryResult(queryResult1);			
		}
		catch(Exception e)
		{
			processSQLError(e);
		}
		
		return allFood;
	}

	/**
	 * update a fooditems rating
	 * 
	 * @param food: the string key of the fooditem
	 * @param r: the rating
	 */
	public void updateFoodRating(String food, int rating)
	{
		try
		{
			PreparedStatement pstmt = connection.prepareStatement("update FOOD set rating = ? where FOOD_NAME = ?");
			pstmt.setInt(1, rating);
			pstmt.setString(2, food);

			pstmt.execute();
		}
		catch (Exception e)
		{
			processSQLError(e);
		}
	}
	
	/**
	 * return the rating of a food item
	 * 
	 * @param food: name of the food item
	 * @return: the integer rating
	 */
	public int getFoodRating(String food)
	{
		int rating = 0;
		
		try
		{
			PreparedStatement pstmt = connection.prepareStatement("select RATING from FOOD where FOOD_NAME = ?");
			pstmt.setString(1, food);
			
			ResultSet results = pstmt.executeQuery();
			if (results.next())
				rating = results.getInt("RATING");
		}
		catch (Exception e)
		{
			processSQLError(e);
		}
		
		return rating;
	}
	
	/**
	 * adds a specified food to the database
	 * 
	 * @param item to add
	 */
	public void addFood(FoodItem food)
	{
		try
		{
			Statement stmt = connection.createStatement();			
			
			stmt.executeUpdate
			(
				"INSERT INTO FOOD " +
				"(FOOD_NAME," +
				"UPPER_NAME," +
				"CALORIES, " +
				"FAT, " +
				"SATURATED_FAT, " +
				"TRANS_FAT, " +
				"CHOLESTEROL, " +
				"SODIUM, " +
				"CARBS, " +
				"FIBRE, " +
				"SUGAR, " +
				"PROTEIN, " +
				"VITAMIN_A, " +
				"VITAMIN_C, " +
				"CALCIUM, " +
				"IRON, " +
				"SERVING_SIZE, " +
				"SERVING_UNIT, " +
				"PORTION_SIZE, " +
				"PORTION_EN, " +
				"PORTION_FR," +
				"RATING) " +
				"VALUES (" +
				"'" + food.getName() + "'" +
				",'" + food.getName().toUpperCase() + "'" +
				"," + food.getAmount(NutriType.CALORIES, 1.0) +
				"," + food.getAmount(NutriType.FAT, 1.0) +
				"," + food.getAmount(NutriType.SATURATED_FAT, 1.0) +
				"," + food.getAmount(NutriType.TRANS_FAT , 1.0) +
				"," + food.getAmount(NutriType.CHOLESTEROL, 1.0) +
				"," + food.getAmount(NutriType.SODIUM, 1.0) +
				"," + food.getAmount(NutriType.CARBS, 1.0) +
				"," + food.getAmount(NutriType.FIBRE, 1.0) +
				"," + food.getAmount(NutriType.SUGAR, 1.0) +
				"," + food.getAmount(NutriType.PROTEIN, 1.0) +
				"," + food.getAmount(NutriType.VITAMIN_A, 1.0) +
				"," + food.getAmount(NutriType.VITAMIN_C, 1.0) +
				"," + food.getAmount(NutriType.CALCIUM, 1.0) +
				"," + food.getAmount(NutriType.IRON, 1.0) +				
				"," + food.getServingSize() +
				",'" + food.getServingUnits() + "'" +
				"," + food.getPortionSize() + 
				",'" + food.getPortionTypeEn() + "'" +
				",'" + food.getPortionTypeFr() + "'" +
				","+ food.getRating() +")"
			);
			
			
			for(String ingredient : food.getIngredientsList())
			{
				stmt.executeUpdate
				(
					"INSERT INTO INGREDIENTS VALUES (" +
					"'" + food.getName() + "'" + ", " +
					"'" + ingredient + "')"
				);
			}
		}
		catch(Exception e)
		{
			processSQLError(e);
		}
	}
	
	/**
	 * deletes a specified food to the database
	 * 
	 * @param item to delete
	 */
	public void deleteFood(String foodName)
	{
		try
		{
			Statement stmt = connection.createStatement();
						
			stmt.executeUpdate
			(
				"DELETE FROM FOOD WHERE FOOD.FOOD_NAME = '" + foodName + "'"
			);
		
		}
		catch(Exception e)
		{
			processSQLError(e);
		}
	}
	
	/**
	 * Create a FoodItemList from a dataSet of the FOOD table.
	 * 	
	 * @param queryResult1 food dataset
	 * @return FoodItemList
	 */
	private FoodItemList parseFoodItemQueryResult(ResultSet queryResult1)
	{
		FoodItemList result = null;
		try
		{
			result = new FoodItemList();
			
			while(queryResult1.next())
			{
				Statement query2 = connection.createStatement();
				ResultSet queryResult2;
								
				String name = queryResult1.getString("FOOD_NAME");
				
				FoodItem foodItem = new FoodItem
				(
					name,
					queryResult1.getDouble("SERVING_SIZE"),
					queryResult1.getString("SERVING_UNIT")
				);		
				
				foodItem.addFact(NutriType.CALORIES, queryResult1.getDouble("CALORIES"));
				foodItem.addFact(NutriType.FAT, queryResult1.getDouble("FAT"));
				foodItem.addFact(NutriType.SATURATED_FAT, queryResult1.getDouble("SATURATED_FAT"));
				foodItem.addFact(NutriType.TRANS_FAT, queryResult1.getDouble("TRANS_FAT"));
				foodItem.addFact(NutriType.CHOLESTEROL, queryResult1.getDouble("CHOLESTEROL"));
				foodItem.addFact(NutriType.SODIUM, queryResult1.getDouble("SODIUM"));;
				foodItem.addFact(NutriType.CARBS, queryResult1.getDouble("CARBS"));
				foodItem.addFact(NutriType.FIBRE, queryResult1.getDouble("FIBRE"));
				foodItem.addFact(NutriType.SUGAR, queryResult1.getDouble("SUGAR"));
				foodItem.addFact(NutriType.PROTEIN, queryResult1.getDouble("PROTEIN"));
				foodItem.addFact(NutriType.VITAMIN_A, queryResult1.getDouble("VITAMIN_A"));
				foodItem.addFact(NutriType.VITAMIN_C, queryResult1.getDouble("VITAMIN_C"));
				foodItem.addFact(NutriType.CALCIUM, queryResult1.getDouble("CALCIUM"));
				foodItem.addFact(NutriType.IRON, queryResult1.getDouble("IRON"));
							
				
				foodItem.setPortion(queryResult1.getDouble("PORTION_SIZE"), queryResult1.getString("PORTION_EN"), queryResult1.getString("PORTION_FR"));
				
				foodItem.setRating(queryResult1.getInt("RATING"));
				//get ingredients corresponding to the food item from the ingredient table...
				queryResult2 = query2.executeQuery
				(
					"SELECT INGREDIENT_NAME FROM INGREDIENTS " +
					"WHERE INGREDIENTS.FOOD_NAME = '" + name +"'"
				);
				
				while(queryResult2.next())
				{
					foodItem.addIngredient(queryResult2.getString("INGREDIENT_NAME"));
				}
				
				
				result.addFood(foodItem);
				
				queryResult2.close();				
			}
			
			queryResult1.close();
		}
		catch(Exception e)
		{
			processSQLError(e);
		}
		
		return result;
	}
	
	/**
	 * Get FoodItems with specified NutriFact values falling within
	 * a given tolerance +/-|%| for Calories, Carbs, Fat and Protein. 
	 * 
	 * @param facts: the NutriFacts to compare against 
	 * @param tolerance: the tolerance to search within, lower is looser
	 * @return a list of FoodItems
	 */
	public FoodItemList getSimilarFoodsByNutrifacts(FoodItem basis, int tolerance)
	{	
		FoodItemList result = null;
		
		if(basis != null)
		{
			try
			{
				result = new FoodItemList();
				
				Statement query = connection.createStatement();
				ResultSet queryResult = null;
				
				String queryString = buildNutrifactQueryString(basis, tolerance);
				
				//if facts contains valid nutrifacts...
				if(queryString.compareTo("") != 0)
				{
					queryResult  = query.executeQuery
					(
						"SELECT * FROM FOOD WHERE " + queryString
					);
					
					result = parseFoodItemQueryResult(queryResult);
					if(result != null)
					{
						result.removeFood(basis);
					}
				}
			}
			catch(Exception e)
			{
				processSQLError(e);
			}
		}
		
		return result;
	}
	
	/**
	 * helper method for getSimilarFoodsByNutrifacts that builds
	 * the constraints for the SQL query string.
	 * @param facts facts to build constraints
	 * @param tolerance tolerance for the constraints, lower is looser
	 * @return the query string
	 */
	private String buildNutrifactQueryString(FoodItem basis, int tolerance)
	{
		String result = "";
		NutriFacts facts = basis.getFacts();
		
		tolerance = Math.abs(tolerance);
		
		ArrayList<NutriType> filterTypes = new ArrayList<NutriType>();
		
		filterTypes.add(NutriType.CALORIES);
		filterTypes.add(NutriType.CARBS);
		filterTypes.add(NutriType.PROTEIN);
		filterTypes.add(NutriType.FAT);
		
		for(NutriType nt : filterTypes)
		{
			NutriFact temp  = facts.getFact(nt);
			
			if(temp != null)
			{
				double amount = Math.abs(temp.amount());
				if(tolerance > 0)
				{
					double lowAmount = amount - ((double)1/tolerance)*amount;
					double highAmount = amount + ((double)1/tolerance)*amount;
					
					result += "FOOD." + nt.toString() + " <= " + highAmount + " AND " + "FOOD." + nt.toString() + " >= " + lowAmount;							  
				}
				else
				{
					result += temp.toString() + "=" + Math.abs(amount);
				}
				
				result += " AND ";
			}					
		}
		
		//remove last and...
		int index = result.lastIndexOf(" AND ");
		
		if(index != -1)
		{
			result += "FOOD_NAME <> '" + basis.getName() + "'";
			result = result.substring(0,index);
		}
		else if(result.length() > 0)
		{
			result += " AND FOOD_NAME <> '" + basis.getName() + "'";
		}
		
		return result;
	}
	
	/**
	 * Get food items having a similar category as a given 
	 * FoodItem
	 * 
	 * @param basis: the basis for the suggestion,
	 * @return: a list of FoodItems
	 */
	public FoodItemList getSimilarFoodsByCategory(FoodItem basis)
	{
		FoodItemList result = null;
		
		if(basis != null)
		{
			try
			{
				Statement query = connection.createStatement();
				
				ResultSet queryResult = query.executeQuery
				(
						"SELECT * FROM FOOD WHERE CATEGORY = (SELECT CATEGORY FROM FOOD WHERE FOOD_NAME = '" + basis.getName() +"') AND FOOD_NAME != '" + basis.getName()+"'" 
				);
				
				result = parseFoodItemQueryResult(queryResult);
			}
			catch(Exception e)
			{
				processSQLError(e);
			}
		}
		
		return result;
	}
		
	
	/**
	 * get all the ingredients from a database by adding them all to
	 * an <code>ArrayList</code> of strings
	 * 
	 * @return list of ingredients in the database
	 */
	public ArrayList<String> getAllIngredients()
	{
		ArrayList<String> allIngredients = null;
		
		try
		{
			allIngredients = new ArrayList<String>();
			Statement query = connection.createStatement();
			ResultSet queryResult = query.executeQuery("SELECT DISTINCT INGREDIENT_NAME FROM INGREDIENTS");
			
			while(queryResult.next())
			{
				allIngredients.add(queryResult.getString("INGREDIENT_NAME"));			
			}
			
			queryResult.close();
		}
		catch(Exception e)
		{
			processSQLError(e);
		}
		
		return allIngredients;
	}
	
	/**
	 * get all the ingredients from a database by adding them all to
	 * a <code>NutriFilterList</code>
	 * 
	 * @return NutriFilterList of filters in the database
	 */
	public NutriFilterList getAllFilters()
	{
		NutriFilterList allFilters = null;
		
		try
		{
			allFilters = new NutriFilterList();
			Statement query = connection.createStatement();
			ResultSet queryResult = query.executeQuery("SELECT * FROM FILTERS");
			
			while(queryResult.next())
			{
				allFilters.addFilter
				(
					new NutriFilter
					(
						queryResult.getInt("ID"),
						NutriType.valueOf(queryResult.getString("NUTRITYPE")),
						OperatorType.valueOf(queryResult.getString("OPERATOR")),
						queryResult.getDouble("VALUE"),
						UnitType.valueOf(queryResult.getString("UNIT"))
					)
				);
			}
			
			queryResult.close();
		}
		catch(Exception e)
		{
			processSQLError(e);
		}			
		
		return allFilters;
	}
	
	/**
	 * Add a specified filter to the database
	 * 
	 * @param filter to add
	 */
	public void addFilter(NutriFilter filter)
	{
		try
		{
			Statement stmt = connection.createStatement();
			Statement query = connection.createStatement();
			ResultSet queryResult;
			int id = -1;
			
			stmt.executeUpdate
			(
				"INSERT INTO FILTERS(NUTRITYPE, OPERATOR, VALUE, UNIT) VALUES('" +
				filter.getNutriType() + "', '" + 
				filter.getOperator() + "', " + 
				filter.getValue() + ", '" +
				filter.getUnit() +"')"				
			);
			
			
			//get the ID assigned to entry by DB
			queryResult = query.executeQuery
			(
				"SELECT ID FROM FILTERS ORDER BY ID DESC LIMIT 1"
			);
			
			if(queryResult.next())
			{
				id = queryResult.getInt("ID");
			}
			
			//assign the id to the filter so it can  be recognized by
			//future db operations. necessary since filters have no
			//logical primary key...
			filter.setDatabaseID(id);			
		
		}
		catch(Exception e)
		{
			processSQLError(e);
		}
	}

	/**
	 * deletes the specified filter in the database
	 * 
	 * @param filter to delete
	 */
	public void deleteFilter(NutriFilter filter)
	{
		try
		{
			Statement stmt = connection.createStatement();
			
			stmt.executeUpdate
			(
				"DELETE FROM FILTERS WHERE ID = " + filter.getDatabaseID()
			);
		
		}
		catch(Exception e)
		{
			processSQLError(e);
		}
	}

	/**
	 * updates a new filter with an old one in the database
	 * 
	 * @param oldValue to be overwritten
	 * @param newValue to overwrite the old value
	 */
	public void updateFilter(NutriFilter oldValue, NutriFilter newValue)
	{
		try
		{					
			Statement stmt = connection.createStatement();
			
			stmt.executeUpdate
			(
				"UPDATE FILTERS " +
				"SET ID="+ oldValue.getDatabaseID() +
				", NUTRITYPE='" + newValue.getNutriType() + 
				"', OPERATOR='" + newValue.getOperator() + 
				"', VALUE=" +  newValue.getValue() + 
				", UNIT='" + newValue.getUnit() + 
				"' WHERE ID=" + oldValue.getDatabaseID()
			);
		}
		catch (Exception e)
		{
			processSQLError(e);
		}
	}

	/**
	 * add an ingredient filter to the database
	 * 
	 * @param ingredientName name of ingredient to add
	 */
	public void addIngredientFilter(String ingredientName)
	{
		try
		{
			PreparedStatement pstmt = connection.prepareStatement("insert into INGREDIENT_FILTERS values (?)");
			pstmt.setString(1, ingredientName);
			pstmt.execute();
		}
		catch(Exception e)
		{
			processSQLError(e);
		}
	}
	
	/**
	 * delete an ingredient filter from the database
	 * 
	 * @param ingredientName name of ingredient to delete
	 */
	public void deleteIngredientFilter(String ingredientName)
	{
		try
		{	PreparedStatement pstmt = connection.prepareStatement("delete from INGREDIENT_FILTERS where INGREDIENT_NAME = ?");
		pstmt.setString(1, ingredientName);
		pstmt.execute();	
		}
		catch(Exception e)
		{
			processSQLError(e);
		}
	}
	
	/**
	 * get all ingredient filters from the database by placing them all in a list
	 * 
	 * @return list of all ingredients in the database
	 */
	public ArrayList<String> getAllIngredientFilters()
	{
		ArrayList<String> allIngredients = null;
		
		try
		{
			allIngredients = new ArrayList<String>();
			Statement query = connection.createStatement();
			ResultSet queryResult = query.executeQuery("SELECT * FROM INGREDIENT_FILTERS");
			
			while(queryResult.next())
			{
				allIngredients.add(queryResult.getString("INGREDIENT_NAME"));			
			}
			
			queryResult.close();
		}
		catch(Exception e)
		{
			processSQLError(e);
		}
		
		return allIngredients;
	}
	
	
	/**
	 * try to get the single daily intake value from the db
	 */
	public NutriFacts getDailyIntake()
	{
		NutriFacts facts = null;
		
		try
		{
			Statement query = connection.createStatement();
			ResultSet queryResult = query.executeQuery("SELECT * FROM DAILY_INTAKE");
			
			if (queryResult.next())		// if there was a result
			{
				// create a new facts object to return
				facts = new NutriFacts();
				facts.updateFact(NutriType.CALORIES, queryResult.getDouble("CALORIES"));
				facts.updateFact(NutriType.FAT, queryResult.getDouble("FAT"));
				facts.updateFact(NutriType.SATURATED_FAT, queryResult.getDouble("SATURATED_FAT"));
				facts.updateFact(NutriType.TRANS_FAT, queryResult.getDouble("TRANS_FAT"));
				facts.updateFact(NutriType.CHOLESTEROL, queryResult.getDouble("CHOLESTEROL"));
				facts.updateFact(NutriType.SODIUM, queryResult.getDouble("SODIUM"));
				facts.updateFact(NutriType.CARBS, queryResult.getDouble("CARBS"));
				facts.updateFact(NutriType.FIBRE, queryResult.getDouble("FIBRE"));
				facts.updateFact(NutriType.SUGAR, queryResult.getDouble("SUGAR"));
				facts.updateFact(NutriType.PROTEIN, queryResult.getDouble("PROTEIN"));
				facts.updateFact(NutriType.VITAMIN_A, queryResult.getDouble("VITAMIN_A"));
				facts.updateFact(NutriType.VITAMIN_C, queryResult.getDouble("VITAMIN_C"));
				facts.updateFact(NutriType.CALCIUM, queryResult.getDouble("CALCIUM"));
				facts.updateFact(NutriType.IRON, queryResult.getDouble("IRON"));
			}
			
			queryResult.close();
		}
		catch(Exception e)
		{
			processSQLError(e);
		}					
		
		return facts;
	}
	
	/**
	 * insert the daily intake value into the db
	 * @param intake: a nutrifacts object of daily intake values
	 */
	public void insertDailyIntake(NutriFacts intake)
	{
		try
		{
			Statement stmt = connection.createStatement();			
			
			// delete any existing value
			stmt.executeUpdate("DELETE FROM DAILY_INTAKE");
			
			// add the new values
			stmt.executeUpdate
			(
				"INSERT INTO DAILY_INTAKE VALUES (" +
				intake.getAmount(NutriType.CALORIES) +
				"," + intake.getAmount(NutriType.FAT) +
				"," + intake.getAmount(NutriType.SATURATED_FAT) +
				"," + intake.getAmount(NutriType.TRANS_FAT) +
				"," + intake.getAmount(NutriType.CHOLESTEROL) +
				"," + intake.getAmount(NutriType.SODIUM) +
				"," + intake.getAmount(NutriType.CARBS) +
				"," + intake.getAmount(NutriType.FIBRE) +
				"," + intake.getAmount(NutriType.SUGAR) +
				"," + intake.getAmount(NutriType.PROTEIN) +
				"," + intake.getAmount(NutriType.VITAMIN_A) +
				"," + intake.getAmount(NutriType.VITAMIN_C) +
				"," + intake.getAmount(NutriType.CALCIUM) +
				"," + intake.getAmount(NutriType.IRON) + ")");			
		}
		catch(Exception e)
		{
			processSQLError(e);
		}		
		
	}
	
	
	/**
	 * print the SQL error message and stack trace and return the
	 * error message
	 * 
	 * @param e an exception object describing an error
	 * @return string of the error message
	 */
	public String processSQLError(Exception e)
	{
		String result;
		result = "*** SQL Error: " + e.getMessage();
		e.printStackTrace();
		return result;
	}
	
}
