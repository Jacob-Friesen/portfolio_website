package nutri.persistence;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;

import nutri.enums.*;
import nutri.objects.NutriFacts;
import nutri.objects.NutriFilter;
import nutri.objects.FoodItem;
import nutri.objects.FoodItemList;
import nutri.objects.NutriFilterList;

/**
 * Simulates a real database
 */
public class DataAccessStub implements IDataAccess
{
	private String dbName;
	private String databaseType = "stub";

	private FoodItemList foodItems;
	private HashSet<String> allIngredients;
	private HashSet<String> ingredientFilters;
	private NutriFilterList filters;

	private NutriFacts dailyValues;

	public DataAccessStub()
	{
		ingredientFilters = new HashSet<String>();
	}

	/**
	 * Adds all items in the stub database to a list of filter
	 * ingredients and fooditems
	 */
	public void open(String dbName)
	{
		this.dbName = dbName;
		
		createStubFood();
		createStubFilters();
		createStubIngredientFilters();
		createStubDailyValues();
		
		System.out.println("Opened " + databaseType + " database " + dbName);
	}

	/**
	 * Simulates a closing connection of a database
	 */
	public void close()
	{
		System.out.println("Closed " + databaseType + " database " + dbName);
	}
	
	/**
	 * adds some initial food data to database
	 */
	private void createStubFood()
	{
		FoodItem food;
		ArrayList<String> ingredients;

		foodItems = new FoodItemList();
		allIngredients = new HashSet<String>();
		filters = new NutriFilterList();

		// Set up 'Apple Jacks'
		food = new FoodItem("Apple Jacks Cereal", 33, "g");

		ingredients = new ArrayList<String>(Arrays.asList("Sugar", "Whole grain corn flour", "Wheat flour"));
		food.addIngredients(ingredients);
		allIngredients.addAll(ingredients);

		food.addFact(NutriType.CALORIES, 129);
		food.addFact(NutriType.FAT, 0);
		food.addFact(NutriType.SATURATED_FAT, 0);
		food.addFact(NutriType.TRANS_FAT, 0);
		food.addFact(NutriType.CHOLESTEROL, 0);
		food.addFact(NutriType.SODIUM, 0.146);
		food.addFact(NutriType.CARBS, 30);
		food.addFact(NutriType.FIBRE, 1);
		food.addFact(NutriType.SUGAR, 14);
		food.addFact(NutriType.PROTEIN, 1);
		food.addFact(NutriType.VITAMIN_A, 900);
		food.addFact(NutriType.VITAMIN_C, 0.02);
		food.addFact(NutriType.CALCIUM, 0);
		food.addFact(NutriType.IRON, 0.00594);
		food.setPortion(1, "cup", "tasse");

		foodItems.addFood(food);

		// Set up 'Milk'
		food = new FoodItem("Milk, 1 percent", 250, "mL");

		ingredients = new ArrayList<String>(Arrays.asList("Partly skimmed milk", "vitamin A palmitate", "vitamin d3"));
		food.addIngredients(ingredients);
		allIngredients.addAll(ingredients);

		food.addFact(NutriType.CALORIES, 110);
		food.addFact(NutriType.FAT, 2.5);
		food.addFact(NutriType.SATURATED_FAT, 1.5);
		food.addFact(NutriType.TRANS_FAT, 0);
		food.addFact(NutriType.CHOLESTEROL, 0.005);
		food.addFact(NutriType.SODIUM, 0.140);
		food.addFact(NutriType.CARBS, 12);
		food.addFact(NutriType.FIBRE, 0);
		food.addFact(NutriType.SUGAR, 11);
		food.addFact(NutriType.PROTEIN, 9);
		food.addFact(NutriType.VITAMIN_A, 500);
		food.addFact(NutriType.VITAMIN_C, 0.036);
		food.addFact(NutriType.CALCIUM, 0.003);
		food.addFact(NutriType.IRON, 0);
		food.setPortion(1, "cup", "tasse");

		foodItems.addFood(food);

		// add orange juice
		food = new FoodItem("Dole Orange Juice", 250, "mL");

		ingredients = new ArrayList<String>(Arrays.asList("Orange juice from concentrate"));
		food.addIngredients(ingredients);
		allIngredients.addAll(ingredients);

		food.addFact(NutriType.CALORIES, 115);
		food.addFact(NutriType.FAT, 0);
		food.addFact(NutriType.SATURATED_FAT, 0);
		food.addFact(NutriType.TRANS_FAT, 0);
		food.addFact(NutriType.CHOLESTEROL, 0);
		food.addFact(NutriType.SODIUM, 0.026);
		food.addFact(NutriType.CARBS, 28);
		food.addFact(NutriType.FIBRE, 0);
		food.addFact(NutriType.SUGAR, 23);
		food.addFact(NutriType.PROTEIN, 2);
		food.addFact(NutriType.VITAMIN_A, 0);
		food.addFact(NutriType.VITAMIN_C, 0.06);
		food.addFact(NutriType.CALCIUM, 0.02);
		food.addFact(NutriType.IRON, 0.00036);
		food.setPortion(1, "cup", "tasse");

		foodItems.addFood(food);

		// add chef boyardee
		food = new FoodItem("Chef Boyardee Beef Ravioli", 226, "g");

		ingredients = new ArrayList<String>(Arrays.asList("Water", "Tomato Puree", "Enriched Wheat Flour", "Beef and Seasoned Beef", "Toasted Wheat Crumbs", "Sugar/Glucose-Fructose", "Salt",
				"Textured Vegetable Protein", "Modified Corn Starch", "Carrots", "Natural Flavour", "Dehydrated Onion", "Caramel", "Potassium Chloride", "Citric Acid", "Maltodextrin",
				"Spice Extracts", "Processed Cheese Spread", "Disodium Inosinate & Disodium Guanylate", "Soybean Oil"));
		food.addIngredients(ingredients);
		allIngredients.addAll(ingredients);

		food.addFact(NutriType.CALORIES, 210);
		food.addFact(NutriType.FAT, 7);
		food.addFact(NutriType.SATURATED_FAT, 3);
		food.addFact(NutriType.TRANS_FAT, 0.3);
		food.addFact(NutriType.CHOLESTEROL, 0.001);
		food.addFact(NutriType.SODIUM, 0.670);
		food.addFact(NutriType.CARBS, 29);
		food.addFact(NutriType.FIBRE, 3);
		food.addFact(NutriType.SUGAR, 4);
		food.addFact(NutriType.PROTEIN, 7);
		food.addFact(NutriType.VITAMIN_A, 100);
		food.addFact(NutriType.VITAMIN_C, 0);
		food.addFact(NutriType.CALCIUM, 0.02);
		food.addFact(NutriType.IRON, 0.0027);
		food.setPortion(0.2, "can", "canne");

		foodItems.addFood(food);
		
		// add whoppers
		food = new FoodItem("Whoppers", 41, "g");

		ingredients = new ArrayList<String>(Arrays.asList("Sugar", "Modified Milk Ingredients",
				"Modified Hydrogenated Palm Kernel Oil", "Corn Syrup Solids", "Corn Syrup", "Malted Milk", "Cocoa Powder",
				"Soy Lecithin", "Resinous Glaze", "Natural and Artificial Flavours", "Calcium Carbonate", "Salt",
				"Tapioca Dextrin", "Sulfites", "Sorbitan Tristearate"));
		food.addIngredients(ingredients);
		allIngredients.addAll(ingredients);

		food.addFact(NutriType.CALORIES, 190);
		food.addFact(NutriType.FAT, 7);
		food.addFact(NutriType.SATURATED_FAT, 7);
		food.addFact(NutriType.TRANS_FAT, 0.1);
		food.addFact(NutriType.CHOLESTEROL, 0);
		food.addFact(NutriType.SODIUM, 0.115);
		food.addFact(NutriType.CARBS, 31);
		food.addFact(NutriType.FIBRE, 0);
		food.addFact(NutriType.SUGAR, 26);
		food.addFact(NutriType.PROTEIN, 1);
		food.addFact(NutriType.VITAMIN_A, 0);
		food.addFact(NutriType.VITAMIN_C, 0.0036);
		food.addFact(NutriType.CALCIUM, 0);
		food.addFact(NutriType.IRON, 0.00036);
		food.setPortion(18, "pieces", "morceaux");

		foodItems.addFood(food);
	}
	
	/**
	 * adds some initial filters to simulate data in the database
	 */
	private void createStubFilters()
	{
		filters.addFilter(new NutriFilter(NutriType.FAT, OperatorType.LESS, 20, UnitType.GRAMS));
		filters.addFilter(new NutriFilter(NutriType.CARBS, OperatorType.LESS_OR_EQUAL, 30, UnitType.GRAMS));
		filters.addFilter(new NutriFilter(NutriType.PROTEIN, OperatorType.GREATER, 10, UnitType.GRAMS));
		filters.addFilter(new NutriFilter(NutriType.SUGAR, OperatorType.LESS, 20, UnitType.GRAMS));
		filters.addFilter(new NutriFilter(NutriType.SODIUM, OperatorType.LESS_OR_EQUAL, 20, UnitType.MILLIGRAMS));
	}

	/**
	 * adds some initial ingredient filters to database
	 */
	private void createStubIngredientFilters()
	{
		ingredientFilters.add("vitamin d3");
		ingredientFilters.add("Wheat flour");
	}

	/**
	 * adds the initial daily values to the database
	 */
	private void createStubDailyValues()
	{
		dailyValues = new NutriFacts();
		dailyValues.updateFact(NutriType.CALORIES, 2000);
		dailyValues.updateFact(NutriType.FAT, 65);
		dailyValues.updateFact(NutriType.SATURATED_FAT, 20);
		dailyValues.updateFact(NutriType.TRANS_FAT, 0);
		dailyValues.updateFact(NutriType.CHOLESTEROL, 0.3);
		dailyValues.updateFact(NutriType.SODIUM, 2.3);
		dailyValues.updateFact(NutriType.CARBS, 300);
		dailyValues.updateFact(NutriType.FIBRE, 25);
		dailyValues.updateFact(NutriType.SUGAR, 0);
		dailyValues.updateFact(NutriType.PROTEIN, 50);
		dailyValues.updateFact(NutriType.VITAMIN_A, 5000);
		dailyValues.updateFact(NutriType.VITAMIN_C, 0.06);
		dailyValues.updateFact(NutriType.CALCIUM, 1);
		dailyValues.updateFact(NutriType.IRON, 0.018);
	}
	
	/**
	 * @return a list of all food items in the stub database
	 */
	public FoodItemList getAllFood()
	{
		return foodItems;
	}
	
	/**
	 * search the fooditems database for any food items
	 * containing the string s
	 * 
	 * @param s: the string to search for
	 * @return: food items containing the string
	 */
	public FoodItemList searchFoodItems(String s)
	{
		FoodItemList toReturn = new FoodItemList();
		
		if(s != null && !s.isEmpty())
		{
			for(int count = 0; count < foodItems.size(); count++)
			{
				if(foodItems.get(count).getName().contains(s))
					toReturn.addFood(foodItems.get(count));
			}
			
			return toReturn;
		}
		else
			return getAllFood();
	}

	/**
	 * update a fooditems rating
	 * 
	 * @param food: the string key of the fooditem
	 * @param r: the rating
	 */
	public void updateFoodRating(String food, int rating)
	{
		//find the value and set it
		for (int count = 0; count < foodItems.size(); count ++)
		{
			if(foodItems.get(count).getName().equals(food))
			{
				foodItems.get(count).setRating(rating);
				break;
			}
		}
	}
	
	/**
	 * return the rating of a food item
	 * 
	 * @param food: name of the food item
	 * @return: the integer rating
	 */
	public int getFoodRating(String food)
	{
		int result = 0;
		
		result = foodItems.getFoodItem(food).getRating();
		
		return result;
	}
	
	/**
	 * @return the list of all ingredients in the stub database
	 */
	public ArrayList<String> getAllIngredients()
	{
		ArrayList<String> ret_value = new ArrayList<String>(allIngredients);

		Collections.sort(ret_value);

		return ret_value;
	}

	/**
	 * @return the <code>NutriFilterList</code> of all filters in the stub database
	 */
	public NutriFilterList getAllFilters()
	{
		return filters;
	}

	/**
	 * @param add a filter to the stub database
	 */
	public void addFilter(NutriFilter filter)
	{
		filters.addFilter(filter);
	}

	/**
	 * @param delete a filter from the stub database
	 */
	public void deleteFilter(NutriFilter filter)
	{
		filters.deleteFilter(filter);
	}
	
	/**
	 * update old filter by a new filter
	 * 
	 * @param oldValue to be overwritten
	 * @param newValue to overwrite the old value
	 */
	public void updateFilter(NutriFilter oldValue, NutriFilter newValue)
	{
		int index = filters.indexOf(oldValue);
		filters.updateFilter(index, newValue);
	}
	
	/**
	 * add an ingredient filter to the database
	 * 
	 * @param ingredientName name of ingredient to add
	 */
	public void addIngredientFilter(String ingredientName)
	{	
		ingredientFilters.add(ingredientName);
	}
	
	/**
	 * delete an ingredient filter from the database
	 * 
	 * @param ingredientName name of ingredient to delete
	 */
	public void deleteIngredientFilter(String ingredientName)
	{
		ingredientFilters.remove(ingredientName);
	}
	
	/**
	 * get all ingredient filters from the database by placing them all in a list
	 * 
	 * @return list of all ingredients in the database
	 */
	public ArrayList<String> getAllIngredientFilters()
	{
		ArrayList<String> ingredients = new ArrayList<String>(ingredientFilters);
		return ingredients;
	}
	
	/**
	 * try to get the single daily intake value from the db
	 */
	public NutriFacts getDailyIntake()
	{
		return dailyValues;
	}
	
	/**
	 * insert the daily intake value into the db
	 * @param intake
	 */
	public void insertDailyIntake(NutriFacts intake)
	{
		dailyValues = intake;
	}

	/**
	 * Returns a food item list with similar nutritional facts
	 * compared to the current.
	 * 
	 * @param basis the food item to find categories for
	 * @param tolerance ignored in the stub
	 * @return the list of food items with the same category as the
	 * one sent in
	 */
	public FoodItemList getSimilarFoodsByNutrifacts(FoodItem basis, int tolerance) 
	{
		FoodItemList toReturn = new FoodItemList();
		boolean foundFood = false;
		
		if(basis != null)
		{
			tolerance = Math.abs(tolerance);
			
			for(FoodItem food : foodItems.getFoodList())
			{
				if(!food.equals(basis) && compareMatchLevel(food, basis) >= tolerance)
					toReturn.addFood(food);
				
				if(food.getName().equals(basis.getName()))
					foundFood = true;
			}
			
			if(foundFood == false)
				toReturn = new FoodItemList();
		}
		else
			toReturn = null;
		
		return toReturn;
	}
	
	/**
	 * Compares the 2 food items returning an int representing how
	 * similar they are.
	 * 
	 * @param food1 one food to compare
	 * @param food2 one food to compare
	 * @return the level at which they are similar
	 */
	public int compareMatchLevel(FoodItem food1, FoodItem food2)
	{
		int matchLevel = 0;
		
		for(NutriType type : NutriType.values())
		{
			if( Math.abs(food1.getFact(type).amount() - food2.getFact(type).amount()) <  20)
				matchLevel++;
		}
		
		return matchLevel;
	}

	/**
	 * Since there are no categories in the stub database return all
	 * food items except the one sent in if the item exists in the 
	 * list.
	 * 
	 * @param basis the food item to find categories for
	 * @return the list of food items with the same category as the
	 * one sent in
	 */
	public FoodItemList getSimilarFoodsByCategory(FoodItem basis)
	{
		FoodItemList toReturn = new FoodItemList();
		boolean foundFood = false;
		
		if(basis != null)
		{
			for(FoodItem food : foodItems.getFoodList())
			{
				if(food.getName().equals(basis.getName()))
					foundFood = true;
				else
					toReturn.addFood(food);
			}
			
			if(foundFood == false)
				toReturn = new FoodItemList();
		}
		else
			toReturn = null;
		
		return toReturn;
	}
}