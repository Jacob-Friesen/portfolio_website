﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;//for any type of collection
using System.Drawing;//for any type of color info
using Microsoft.VisualBasic.PowerPacks;//need for oval shapes

/*sets and manages what happens to each menuStrip item*/

namespace fidelity2
{
    class CircleBorderManager
    {
        Form current;

        public CircleBorderManager(Form sent)
        {
            current = sent;
        }

        public void init(OvalShape objectSent)
        {
            //MessageBox.Show("oval shape modifications");

            //every oval needs to be opaque
            objectSent.BackStyle = BackStyle.Opaque;

            //this will control the outer border of the circle window
            if (objectSent.Name.Equals("outerBorderC"))
            {
                //fill the shape
                objectSent.BackColor = Color.DarkSlateGray;
            }
            //this control inner circle clicks
            else if (objectSent.Name.Equals("createInnerC"))
            {
                //add a event to transition to the create form
                objectSent.Click += new EventHandler(createClicked);
            }
            //this control inner circle clicks
            else if (objectSent.Name.Equals("searchInnerC"))
            {
                //add a event to transition to the create form
                objectSent.Click += new EventHandler(searchClicked);
            }
        }

        /*---Events---*/

        public void createClicked(object sender,EventArgs e)
        {
            MessageBox.Show("Heading to the create menu");
        }

        public void searchClicked(object sender, EventArgs e)
        {
            MessageBox.Show("Heading to the search menu");
        }
    }
}
