﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;//for any type of collection
using System.ComponentModel;
using System.Data;
using System.Drawing;
using Microsoft.VisualBasic.PowerPacks;//need for oval shapes

/** This class handles all post design changes to code**/

namespace fidelity2
{
    class DataManager
    {
        MenuManager menuManager;
        CircleBorderManager circleBorderManager;

        Form current;

        public DataManager(Form sent)
        {
            current = sent;

            //initialize all possible subclasses
            menuManager = new MenuManager(current);
            circleBorderManager = new CircleBorderManager(current);
        }

        public void initialize(object objectSent)
        {
            //find the object type
            if (objectSent is MenuStrip)
            {
                //MessageBox.Show("Data Manager");

                menuManager.init((MenuStrip)objectSent);
            }
            //find the object type
            if (objectSent is OvalShape)
            {
                //MessageBox.Show("Data Manager");

                circleBorderManager.init((OvalShape)objectSent);
            }
        }
    }
}
