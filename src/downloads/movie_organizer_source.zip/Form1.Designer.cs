﻿namespace fidelity2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.wideViewPicture = new System.Windows.Forms.Panel();
            this.homeScreenText = new System.Windows.Forms.TextBox();
            this.wideViewTop = new System.Windows.Forms.Panel();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.titleText = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.createText = new System.Windows.Forms.TextBox();
            this.searchText = new System.Windows.Forms.TextBox();
            this.wideViewPicture.SuspendLayout();
            this.wideViewTop.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // wideViewPicture
            // 
            this.wideViewPicture.BackColor = System.Drawing.Color.DarkOrange;
            this.wideViewPicture.Controls.Add(this.homeScreenText);
            this.wideViewPicture.Location = new System.Drawing.Point(0, 563);
            this.wideViewPicture.Name = "wideViewPicture";
            this.wideViewPicture.Size = new System.Drawing.Size(203, 68);
            this.wideViewPicture.TabIndex = 1;
            // 
            // homeScreenText
            // 
            this.homeScreenText.BackColor = System.Drawing.Color.LimeGreen;
            this.homeScreenText.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.homeScreenText.Location = new System.Drawing.Point(23, 28);
            this.homeScreenText.Name = "homeScreenText";
            this.homeScreenText.ReadOnly = true;
            this.homeScreenText.Size = new System.Drawing.Size(31, 13);
            this.homeScreenText.TabIndex = 6;
            this.homeScreenText.Text = "Home";
            // 
            // wideViewTop
            // 
            this.wideViewTop.BackColor = System.Drawing.Color.DarkSlateGray;
            this.wideViewTop.Controls.Add(this.textBox2);
            this.wideViewTop.Location = new System.Drawing.Point(0, 545);
            this.wideViewTop.Name = "wideViewTop";
            this.wideViewTop.Size = new System.Drawing.Size(203, 22);
            this.wideViewTop.TabIndex = 2;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.DarkSlateGray;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.ForeColor = System.Drawing.SystemColors.Info;
            this.textBox2.Location = new System.Drawing.Point(38, 2);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(122, 13);
            this.textBox2.TabIndex = 3;
            this.textBox2.Text = "Wide View";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // titleText
            // 
            this.titleText.BackColor = System.Drawing.Color.DarkOrange;
            this.titleText.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.titleText.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleText.Location = new System.Drawing.Point(478, 54);
            this.titleText.Name = "titleText";
            this.titleText.ReadOnly = true;
            this.titleText.Size = new System.Drawing.Size(141, 55);
            this.titleText.TabIndex = 6;
            this.titleText.Text = "Home";
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.DarkSlateGray;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1018, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // menuToolStripMenuItem
            // 
            this.menuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.resetToolStripMenuItem,
            this.addToolStripMenuItem,
            this.helpToolStripMenuItem,
            this.quitToolStripMenuItem});
            this.menuToolStripMenuItem.Name = "menuToolStripMenuItem";
            this.menuToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.menuToolStripMenuItem.Text = "Menu";
            // 
            // resetToolStripMenuItem
            // 
            this.resetToolStripMenuItem.BackColor = System.Drawing.Color.Orange;
            this.resetToolStripMenuItem.Name = "resetToolStripMenuItem";
            this.resetToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.resetToolStripMenuItem.Text = "Reset";
            // 
            // addToolStripMenuItem
            // 
            this.addToolStripMenuItem.BackColor = System.Drawing.Color.Moccasin;
            this.addToolStripMenuItem.Name = "addToolStripMenuItem";
            this.addToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.addToolStripMenuItem.Text = "Add";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.BackColor = System.Drawing.Color.Orange;
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // quitToolStripMenuItem
            // 
            this.quitToolStripMenuItem.BackColor = System.Drawing.Color.Moccasin;
            this.quitToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quitToolStripMenuItem.Name = "quitToolStripMenuItem";
            this.quitToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Q)));
            this.quitToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.quitToolStripMenuItem.Text = "Quit";
            // 
            // createText
            // 
            this.createText.BackColor = System.Drawing.Color.DarkOrange;
            this.createText.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.createText.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.createText.Location = new System.Drawing.Point(343, 327);
            this.createText.Name = "createText";
            this.createText.ReadOnly = true;
            this.createText.Size = new System.Drawing.Size(114, 42);
            this.createText.TabIndex = 5;
            this.createText.Text = "Create";
            this.createText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // searchText
            // 
            this.searchText.BackColor = System.Drawing.Color.DarkOrange;
            this.searchText.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.searchText.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchText.Location = new System.Drawing.Point(612, 327);
            this.searchText.Name = "searchText";
            this.searchText.ReadOnly = true;
            this.searchText.Size = new System.Drawing.Size(123, 42);
            this.searchText.TabIndex = 4;
            this.searchText.Text = "Search";
            this.searchText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightBlue;
            this.ClientSize = new System.Drawing.Size(1018, 631);
            this.Controls.Add(this.titleText);
            this.Controls.Add(this.createText);
            this.Controls.Add(this.searchText);
            this.Controls.Add(this.wideViewTop);
            this.Controls.Add(this.wideViewPicture);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.wideViewPicture.ResumeLayout(false);
            this.wideViewPicture.PerformLayout();
            this.wideViewTop.ResumeLayout(false);
            this.wideViewTop.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        protected System.Windows.Forms.Panel wideViewPicture;
        protected System.Windows.Forms.Panel wideViewTop;
        protected System.Windows.Forms.TextBox textBox2;//the first border oval//the second border oval
        protected System.Windows.Forms.TextBox homeScreenText;
        protected System.Windows.Forms.TextBox titleText;
        protected System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem menuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resetToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quitToolStripMenuItem;
        protected System.Windows.Forms.TextBox createText;
        protected System.Windows.Forms.TextBox searchText;//the inner content oval
    }
}

