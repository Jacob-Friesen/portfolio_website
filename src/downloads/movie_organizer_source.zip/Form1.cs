﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace fidelity2
{
    public partial class Form1 : Form
    {
        private String path = Application.StartupPath;

        private DataManager dataManager;

        public Form1()
        {
            InitializeComponent();

            dataManager = new DataManager(this);

            initScreenObjects();
        }

        //getters and setters
        public Panel getWideViewTop()
        {
            return wideViewTop;
        }

        public void initScreenObjects()
        {
            //not going to be managing background so I'l, just do it here
            //this.BackgroundImage = Image.FromFile(path + "\\images\\background.bmp");
            this.MaximumSize = this.Size;//window size is unchangable for now
            this.MinimumSize = this.Size;//window size is unchangable for now

            //load menus
            //dataManager.initialize(menuStrip1);

            //load circles (don't need to but good for testing)
            //dataManager.initialize(outerBorderC);//outer border
            //dataManager.initialize(createInnerC);//outer border
            //dataManager.initialize(searchInnerC);//outer border

            //load other stuff
        }
    }
}
