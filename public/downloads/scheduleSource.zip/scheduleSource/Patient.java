import java.awt.Graphics;
import java.awt.Point;
import java.util.ArrayList;

/**
* Patient
*
* STUDENT: Jacob Friesen, 7623030
*
* PURPOSE: keeps track of all patient data, which is the patients
* name, condition, resources required to treat the condition, doctors
* treated by and start and stop times, and bitmap. Also can fill (given input)
* and print patient info and specifies how the patients should be sorted.
* And also can check the current patients bmp.
* 
*/

public class Patient implements Comparable<Patient>//Comparable is for a sorts in Patientlist
{
	
	private String name;
	private Condition condition;
	private ArrayList<Resource> resources = new ArrayList<Resource>();//name and type of doctor string stored
	private String start;
	private String stop;
	private String bmpLocation;//just store the loaction in here for now
	private Bitmap patientBmp;
	
	public Patient(String name,Condition condition)
	{
		this.name = name;
		this.condition = condition;
		bmpLocation = "resources/patient.bmp";
		patientBmp = new Bitmap(bmpLocation);
	}
	
	public String getName()
	{
		return name;
	}
	
	public int getPriority()
	{
		return condition.getPriority();
	}
	
	public Condition getCondition()
	{
		return condition;
	}
	
	public ArrayList<Requirements> getRequirements()
	{
		return condition.getRequirements();
	}
	
	public String getStart()
	{
		return start;
	}
	
	public String getStop()
	{
		return stop;
	}
	
	public ArrayList<Resource> getResources()
	{
		return resources;
	}
	
	public void paintBmp(Graphics g,Point location)
	{
		/** given a location paint a bitmap**/
		
		patientBmp.paintBmp(g,location);
	}
	
	public boolean checkBmp(Point point)
	{
		/**check if the current bitmap of this resource is in
		 * this position**/
		
		if(patientBmp != null)
		{
			return patientBmp.isIn(point);
		}
		
		return false;
	}
	
	public void setTimes( String start, String end)
	{
		/**
		 * fillTimes
		 * 
		 * PURPOSE: fills in the start and end times
		 * 
		 * PARAMETERS: the strings start, end  which are the treatments
		 * start and end times.
		 * 
		 */
		
		this.start = start;
		this.stop = end;
	}
	
	public void fillResInfo( ArrayList<Resource> resources)
	{
		/**
		 * fillInfo
		 * 
		 * PURPOSE: fills in the resources the patient is being
		 * treated by.
		 * 
		 * PARAMETERS: resources which is a reference to the list of
		 * doctors this patient is being treated by.
		 * 
		 */
		
		this.resources = resources;
	}
	
	public void addResource(Resource resource)
	{
		/**
		 * addDoctorName
		 * 
		 * PURPOSE: fills in a resource
		 * 
		 * PARAMETERS: resource is the resource to add
		 * 
		 */
		
		resources.add(resource);
	}
	
	public int compareTo(Patient patient)
	{
		/**
		 * compareTo
		 * 
		 * PURPOSE: This will define how sorts will work on Patient objects.
		 * 
		 * PARAMETERS: patient the Patient compared to the Patient of this method,
		 * which would be this.
		 * 
		 * RETURNS: 0 if equal, -1 if less and 1 if greater, for the patient
		 * sent in compared to the current
		 * 
		 */
		
		int result = 0;//0 is equal, -1 is less and 1 is greater
		
		//sort for priority with initial list(anyones start works)
		if (this.getPriority() < patient.getPriority())
		{
			result = -1;
		}
		else if (this.getPriority() > patient.getPriority())
		{
			result = 1;
		}
		else//equal
		{
			result = 0;
		}

		return result;
	}
	
	public String getFullInfo()
	{
		/**
		 * printFullInfo
		 * 
		 * PURPOSE: puts all patient info into a string, which is the name
		 * condition, priority, resources to treat the condition, start and
		 * stop times for the patient and the doctors treated by.
		 * 
		 * RETURNS: string of all patient info.
		 * 
		 */
		
		String info;
		
		info = name + "\n" + condition  + "\n"+ "priority: " + getPriority() + "\n";
		info = info + condition.getRequirements();
		info = info + "\n" + "start: " + start + "\n" + "end  : " + stop + "\n" + resources;
		
		return info;
	}
	
	public String getDocInfo()
	{
		return name + "\nCondition: " + condition.getName() + "\nResource requirements:\n"
		+ condition.getRequirements() + "\nStart: "	+ start + "\nStop: " + stop;
	}
	
	public String getPatientInfo()
	{
		return name + "\nCondition: " + condition.getName()+ "\npriority " + getPriority() + "\nStart: "	+ start + "\nStop: " + stop + resources;
	}
	
	public void printTreatInfo()
	{
		System.out.println(condition.getRequirements());
	}
	
	public String toString()
	{
		return name;
	}
}


