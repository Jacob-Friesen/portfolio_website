import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.util.ArrayList;

/**
* Room
*
* STUDENT: Jacob Friesen, 7623030
*
* PURPOSE: Room contains a rectangle that is to be displayed. It needs the RoomID from
* one of it's subclasses, to translate the rectangle properly. Room also contains code
* to paint the current patients name and condition as well as their bitmap and the
* doctors treating them bitmaps.
* 
*/

public class Room extends Resource{
	
	//room rectangle stuff
	
	private Rectangle rect;//(this is not directly read but its attributes are.)
	private int borderSize = 2;
	//x and y coordinates for this room's
	private int x;
	private int y;
	//the size of the rectangle
	private final int sizeX;
	private final int sizeY; 
	
	//margins in rectangle
	
	//the margins(all in pixels)
	private final int leftWordMargin = 8;//all text is this far from the left
	private final int lineHeight = 20;//how high each line of text is
	//the image placing variables
	private final int patientLeft;//for the patients bitmap left spacing
	private final int patientTop;//for the patients bitmap top spacing
	private final int resourceTop;//for each resources top
	private final int resourceRight = 50;//the margin on the right for resources
	
	public Room(String name,int RoomID)
	{
		super(name);
		this.name = name;
		schedule = new Schedule();
		
		//rectangle initialization
		sizeX = 225;
		sizeY = 175;
		//ID 1 to 4 so translating rect by multiplying the x coordinate by this number works.
		x = 10 + ((RoomID - 1) * (sizeX-1));//-1 gets rid of thick border between rectangles
		y = 100;
		
		//each rectangle is the same size, but
		//at different locations.
		rect = new Rectangle(x,y,sizeX,sizeY);
		
		//image placing variables
		patientLeft = x + leftWordMargin + 160;
		patientTop = y + lineHeight -5;
		resourceTop = y + 70;
	}
	
	public Patient paint(Graphics g,Time currentTime)
	{
		/**
		 * paint
		 * 
		 * PURPOSE: paints the border of the current rectangle (distance is already specified).
		 * creates a black original rectangle filled by a slightly smaller rectangle
		 * Then calls the room type and name to display in the rectangle. Then gets 
		 * the patient to display their name and condition as well as their bitmap
		 * and bitmap of the doctors they are being treated by.
		 * 
		 * PARAMETERS: g is the graphics to paint to and current time is the
		 * current time in the applet.
		 * 
		 * RETURNS: the patient found in the room given the current time.
		 * 
		 * **/
		
		Patient currPatient;
		Point currentPos = new Point(patientLeft,patientTop);//gives the current point for which to display a current bitmap
		ArrayList<Resource> resourceTemp;
		
		//border
		g.setColor(Color.BLACK);
		g.drawRect(x,y,sizeX,sizeY);
		
		//smaller fill in rectangle
		g.setColor(Color.WHITE);
		g.fillRect(x+1,y+1,sizeX-borderSize,sizeY-borderSize);
		
		//draw the room type string
		g.setColor(Color.BLACK);
		g.drawString(getType() + " " + getName(),x + leftWordMargin,y+lineHeight);
		
		//getting the current patient given a time
		currPatient = schedule.getPatient(currentTime);
		
		//drawing the bitmaps
		if(currPatient != null)
		{
			//patient name condition and bitmap drawing
			g.drawString(currPatient.getName() + "",x + leftWordMargin,y+lineHeight*2);
			g.drawString(currPatient.getCondition().getName() + "",x + leftWordMargin,y+lineHeight*3);
			currPatient.paintBmp(g, currentPos);
			
			/**doctor/nurse drawings**/
			resourceTemp = currPatient.getResources();//resources treating the patient
			//requirements = currPatient.getCondition().getRequirements();//treat times for each resource need to be found
			currentPos.setLocation(x + leftWordMargin,resourceTop);
			
			//goes through each resource and if not a room prints out their bitmap
			for(Resource resource : resourceTemp)
			{	
				//room bitmaps are not drawn
				if(!(resource.getType().equals("GENERALROOM") || resource.getType().equals("SURGERYROOM")))
				{
					//check here if the image can be displayed (check resources schedule and see if it has currentPatient now)
					if(resource.canFindPatient(currentTime,currPatient) == true)
					{
						resource.paintBmp(g, currentPos);
						
						//determines if a new line should be wrote to
						if(currentPos.getX() + resource.getSizeX() >= (x + sizeX) - resourceRight)
						{
							currentPos.setLocation(x + leftWordMargin,resourceTop + resource.getSizeX() -1);
						}
						else
						{
							currentPos.setLocation(((int)currentPos.getX()) + resource.getSizeX() -1, currentPos.getY());
						}
						
						resource.setOffScreen(false);
					}
					else
					{
						//set the resource to a point offscreen (to prevent invisible boxes from remaining)
					}
				}
			}
		}
		
		return currPatient;
	}
}
