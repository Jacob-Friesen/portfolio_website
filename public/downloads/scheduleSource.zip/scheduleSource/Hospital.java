import java.awt.Graphics;
import java.awt.Point;

/**
* Hospital
*
* STUDENT: Jacob Friesen, 7623030
*
* PURPOSE: Coordinates all data when it is being made and then defines
* painting and bitmap searching for the applet. This keeps track of
* the time the user seent.
* 
*/

public class Hospital {
	
	private String patientFile;
	private String conditionFile;
	
	//3 parts of information that need to be created/read.
	private Resourcelist first8Res;
	private Conditionlist origCond;
	private Patientlist origPats;
	
	//the patients currently being displayed in the rooms
	private Patient[] currentPatients;
	
	//Timer for the current display (not used iin repainting)
	private Time mainTime;//used in hospital and lower
	
	//used to stop the timer when a key is pressed (in Main GUI)
	boolean stop;
	
	public Hospital(String patientFile,String conditionFile)
	{
		this.patientFile = patientFile;
		this.conditionFile = conditionFile;
		first8Res = new Resourcelist();
		origCond = new Conditionlist();
		origPats = new Patientlist();
		mainTime = new Time();
		currentPatients = new Patient[4];//4 rooms in total 1 patient per room
		stop = false;
	}
	
	public void init()
	{	
		/**
		 * init
		 * 
		 * PURPOSE: reads in all required information for the scheduler, and
		 * prints it into the console.
		 * 
		 */
		
		first8Res.createResources();
		first8Res.printIDs();//names and types print

		origCond.readConditions(conditionFile);
		origCond.printConditions();

		origPats.readPatients(patientFile,origCond);//OrigCond is needed so patient priorities can be set
		origPats.printName();

		//schedule patients into the resources
		origPats.schedulePatients(first8Res);

		//print patient and doctor info
		//origPats.printFullInfo();
		System.out.println(origPats.getFullInfo());
		System.out.println(first8Res);
	}
	
	public void switchStop()
	{
		/**
		 * switchStop
		 * 
		 * PURPOSE: switches whether the applet should be
		 * stopped or not. (It still repaints)
		 * 
		 */
		
		if(stop == true)
		{
			stop = false;
		}
		else
		{
			stop = true;
		}
	}
	
	public void invalidateBmps()
	{
		first8Res.invalidateBmps();
	}
	
	public void paint(Graphics g)
	{
		/**
		 * paint
		 * 
		 * Increments time if stop is not false (s or space was pressed) and draws the time
		 * then causes each resource to define what's on screen. Also gets the list of patients
		 * currently being displayed on screen from the paint of the resources.
		 * 
		 * **/
		
		if(stop == false)
		{
			incrementTime();
		}
		
		//call rooms paint and find which patients were painted
		currentPatients = first8Res.paint(g,mainTime);
		
		g.drawString("Time: " + mainTime.getDay()+ "day"  + ":" + mainTime.getMinute() + "m", 0, 15);
		g.drawString("Press space or s to pause simulation", 400,364);
	}
	
	public void incrementTime()
	{
		//For now assuming a increment of 5
		int incrementBy = 5;
		
		mainTime.increment(incrementBy);
	}
	
	public String checkPoint(Point point)
	{
		/**
		 * checkPoint
		 * 
		 * PURPOSE: Checks the specified point to see if there is a bitmap,
		 * if so draws the specified information of it in the text field. The
		 * patients that currently have bitmaps in the room are known by this
		 * class and are the only ones printed.
		 * 
		 * PARAMETERS: point which is the point to search the bitmaps for.
		 * 
		 * RETURNS: The text information the current bitmap if any has.
		 */
		
		Resource foundRes = null;
		String stringFound = null;
		
		//loop through all the resources
		foundRes = first8Res.checkDoctorBmps(point);
		
		//only can find 1 bitmap at a time so a if else works
		if(foundRes != null)
		{
			stringFound = foundRes.getSchedule();
		}
		else
		{
			//original patients will no longer work must use each resources pateintlist.
			for(int count = 0;count < currentPatients.length;count++)
			{
				if(currentPatients[count] != null && currentPatients[count].checkBmp(point) == true)
				{
					stringFound = currentPatients[count].getPatientInfo();
					break;
				}
			}
		}

		return stringFound;
	}
}
