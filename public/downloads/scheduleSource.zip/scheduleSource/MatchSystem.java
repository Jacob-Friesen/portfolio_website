import java.util.ArrayList;

/**
* ScheduleSystem
*
* STUDENT: Jacob Friesen, 7623030
*
* PURPOSE: Schedules a given patient into a given doctorList, contains
* a instance of Doctorlist's doctors.
* 
*/

public class MatchSystem {
	
	ArrayList<Resource> resources;
	
	public MatchSystem(ArrayList<Resource> resources)
	{
		this.resources = resources;
	}

	public void schedulePatient(Patient patient)
	{
		/**
		 * schedulePatient
		 * 
		 * PURPOSE: schedules a patient into a set of doctors that fit the
		 * condition requirements for a patient. It tries to find the
		 * earliest time possible. All doctors must start at the same time.
		 * 
		 * ALGORITHM:
		 * 1)Find the types of doctors (and the corresponding times) that are to -|
		 * treat the patient.												      |
		 * 2)Find the earliest doctors that are available.						  |
		 * 3)Find the highest time of the doctors selected.                       |
		 * 4)Then if all doctors can schedule at that time go to step 5)          | All in the main while loop
		 * otherwise take the last earliest time found and look after             |
		 * that point from step 1)												 -|
		 * 5)Schedule patient into required doctors and update the patients info.
		 * 
		 * PARAMETERS: patient is the patient to be placed.
		 * 
		 */
		
		int count = 0;
		int[] highestTime = new int[2];//keeps the earliest day and minute of that day found for the current doctor
		int[] scheduleAt = {0,0};//the day and the minute check for a valid time after.
		ArrayList<Requirements> treatInfo = new ArrayList<Requirements>();
		ArrayList<Resource> treaters = new ArrayList<Resource>();//list of doctors that will treat the patient
		ArrayList<Resource> docsTemp = new ArrayList<Resource>();//exact copy of list of doctors used so some can be subtracted on the fly in the first for loop
		Resource tempDoctor;
		boolean foundSet = false;
		
		//1)Find the types of doctors (and the corresponding times) that are to treat the patient.	
		treatInfo = patient.getRequirements();

		while(foundSet == false)
		{
			//2)Find the earliest doctors that are available.
			treaters.clear();//prepare for a new set
			docsTemp.addAll(resources);//need to do a deep copy
			for(count = 0;count < treatInfo.size();count++)
			{		
				//finds a doctor with a timeslot for this
				tempDoctor = findValidDoctors(treatInfo.get(count),docsTemp,scheduleAt);
				treaters.add(tempDoctor);
				docsTemp.remove(tempDoctor);
			}
			
			//3)Find the highest time and doctor of the doctors selected.
			highestTime = highestDocTime(treaters,treatInfo,scheduleAt);
			
			//4)revise the list according to that latest time
			treaters = reviseList(treatInfo,highestTime);
			
			if(treaters.size() == treatInfo.size())
			{
				foundSet = true;
			}
			else
			{
				scheduleAt = highestTime;//take the latest earliest time found
			}
		}
		
		//5)Schedule patient into required doctors and update the patients info. (update of info in doctor class and later in fillPatientInfo)
		for(count = 0;count < treatInfo.size();count++)
		{		
			if(highestTime[1] > -1)
			{
				//place into the treaters array
				treaters.get(count).placePatient(treatInfo.get(count).getTime(), patient, highestTime[0], highestTime[1]);
			}
			else
			{
				//message should never appear
				System.out.println("Failed to schedule " + patient + " with Doctor " + treaters.get(count));
			}
		}
		
		//find largest time of the doctors required and use that to put in patient time taken info
		fillPatientInfo(findLargestTime(treatInfo),highestTime,patient);//this will be off for now
	}
	
	private Resource findValidDoctors(Requirements onePart, ArrayList<Resource> docsTemp,int[] scheduleAt)
	{
		/**
		 * findValidDoctors
		 * 
		 * PURPOSE: method finds a doctor for the given treatment part, has to match type and
		 * be the earliest of that type.
		 * 
		 * PARAMETERS: docsTemp is the list of doctors to use, schedule at is the [0]day
		 * and [1] minute to try to find after and onePart is the type and time required.
		 * 
		 * RETURNS: The found doctor that meets all of the requirments
		 * 
		 */
		
		/**method finds a valid doctor for the given treatment part*/
		
		Resource foundDoc = null;
		Resource earliest = null;
		int[] lowestTime = new int[2];//0 for day and 1 for minute
		int[] currentTime = new int[2];
		
		//check thru the list to find the type of doctor
		for(Resource resource : docsTemp)
		{
			//find if doctor is the correct type
			if(( resource.getType() ).equals( onePart.getType() ))
			{
				foundDoc = resource;
				break;
			}
		}
		
		//find if this doctor is the earliest doctor
		earliest = foundDoc;
		for(Resource resource : docsTemp)
		{
			if(( resource.getType() ).equals( earliest.getType() ))
			{
				//see if found doctor is actually sooner than others of the same type
				lowestTime = earliest.getEarliestTime(onePart.getTime(),scheduleAt);//getting latest time
				currentTime = resource.getEarliestTime( onePart.getTime(),scheduleAt);
				if(lowestTime[0] > currentTime[0])//days
				{
					earliest = resource;
				}
				else if(lowestTime[0] == currentTime[0])//days
				{
					if(lowestTime[1] > currentTime[1])//minutes
					{
						earliest = resource;
					}
				}
			}
		}
		
		//if a new one is found, foundDoc will change here
		foundDoc = earliest;
		
		return foundDoc;
	}
	
	private int[] highestDocTime(ArrayList<Resource> treaters,ArrayList<Requirements> treatInfo,int[] scheduleAt)
	{
		/**
		 * highestDocTime
		 * 
		 * PURPOSE: method finds the latest time a doctor has to schedule.
		 * 
		 * PARAMETERS: treaters is the list of doctors to use, schedule at is the [0]day
		 * and [1] minute to try to find after and treatInfo is the array of requirements 
		 * that must be met for the condition.
		 * 
		 * RETURNS: [0] day and [1] minute of the time latest time a doctor has to schedule.
		 * 
		 */

		Resource highestDoctor;
		int[] highestTime = new int[2];//0 for day and 1 for minute
		int[] currentTime = new int[2];
		int count = 0;
		int tempCount = 0;//must keep the count of the actual found highest doctor for later
		
		//remember there is a one to one correspondence of treaters to their treatment times.
		highestDoctor = treaters.get(0);
		
		assert(treaters.size() == treatInfo.size());
		for(count = 0;count < treaters.size();count++)	
		{
			highestTime = highestDoctor.getEarliestTime(treatInfo.get(tempCount).getTime(),scheduleAt);//getting latest time
			currentTime = treaters.get(count).getEarliestTime( treatInfo.get(count).getTime(),scheduleAt);
			
			if(highestTime[0] < currentTime[0])//days
			{
				highestDoctor = treaters.get(count);
				tempCount = count;
			}
			else if(highestTime[0] == currentTime[0])//days
			{
				if(highestTime[1] < currentTime[1])//minutes
				{
					highestDoctor = treaters.get(count);
					tempCount = count;
				}
			}
		}
		
		highestTime = highestDoctor.getEarliestTime(treatInfo.get(tempCount).getTime(),scheduleAt);
		
		return highestTime;
	}
	
	private ArrayList<Resource> reviseList(ArrayList<Requirements> treatInfo,int[] scheduleAt)
	{
		/**
		 * reviseList
		 * 
		 * PURPOSE: changes the treaters list by adding only which ones can be scheduled at the time specified.
		 * 
		 * PARAMETERS: schedule at is the [0]day and [1] minute to try to find after, treatInfo
		 * is the array of requirements that must be met for the condition.
		 * 
		 * RETURNS: the [0] day and [1] minute of the time latest time a doctor has to schedule.
		 * 
		 */
		ArrayList<Resource> treaters = new ArrayList<Resource>();//eventual array of treaters to use
		ArrayList<Resource> tempCopy = new ArrayList<Resource>();//array to check for of types
		int[] timeFound = new int[2];
		
		tempCopy.addAll(resources);//need to do a deep copy
		
		for(Requirements requirement : treatInfo)//find a valid doctor
		{
			for(Resource resource : tempCopy)
			{
				if(resource.getType().equals(requirement.getType()))
				{
					//now check for validity
					timeFound = resource.getEarliestTime( requirement.getTime(),scheduleAt);
					if(timeFound[1] == -1)
					{
						resource.addDay();
					}
					else if(timeFound[0] != scheduleAt[0] || timeFound[1] != scheduleAt[1])
					{
						//do nothing
					}
					else
					{
						treaters.add(resource);
						tempCopy.remove(resource);
						break;
					}
				}
			}
		}
		
		return treaters;
	}
	
	private int findLargestTime(ArrayList<Requirements> treatInfo)
	{
		/**
		 * highestDocTime
		 * 
		 * PURPOSE: method finds the largest amount of time required for the condition
		 * of the current patient being scheduled.
		 * 
		 * PARAMETERS: treatInfo is the array of requirements that must be met for the condition.
		 * 
		 * RETURNS: the largest amount of time in minutes.
		 * 
		 */
		
		int largestTime = 0;
		
		largestTime = treatInfo.get(0).getTime();
		for(Requirements requirement : treatInfo)
		{
			if(requirement.getTime() > largestTime)
			{
				largestTime = requirement.getTime();
			}
		}
		
		return largestTime;
	}
	
	private void fillPatientInfo(int largestTime,int[] start,Patient patient)
	{
		/**
		 * fillPatientInfo
		 * 
		 * PURPOSE: fills all required info about a given patient
		 * 
		 * PARAMETERS: patient is the patient to be placed. largestTime is the longest
		 * operating doctor in other words the total treatment time of the patient, and
		 * start is the [0]day and [1]minute the patient is scheduled for.
		 * 
		 */
		
		//fills patient time
		patient.setTimes(start[1] + " minutes " + start[0] + " days",(start[1] + largestTime) + " minutes " + start[0] + " days");
	}

}
