import java.awt.*;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.Timer;

/**
* MainGUI
*
* STUDENT: Jacob Friesen, 7623030
*
* PURPOSE: Runs the data (displaying it in the console window), and then
* creates and runs the GUI;
* 
*/

public class MainGUI extends Panel implements KeyListener{

	private static final long serialVersionUID = 1L;//gave a warning for not having this
	
	Hospital origHospital;
	String conditionFile = "resources/conditions.txt";
	String patientFile = "resources/patients.txt";
	
	//GUI variables
	private Image dbImage;
	private Graphics dbg;
	
	//Dimensions
	int height = 600;
	int width = 1000;
	
	//text field variables (I also call the text field text box)
	private JScrollPane mouseDisplayScrollpane;
	private JTextPane mouseDisplayTextpane;
	private static int textBoxHeight = 150;
	private static int textBoxWidth = 600;
	
	//mouse variable
	private Point mouseLocation;
	
	public MainGUI()
	{
		mouseLocation = new Point(0,0);
		origHospital = new Hospital(patientFile,conditionFile);
	}
	
	public void init() 
	{
		/**
		 * init
		 * 
		 * PURPOSE: runs the data, and then sets up all needed parts for
		 * running the applet; the mouse and keyboard listeners, the text
		 * window at the bottom of the applet, and the main timer.
		 * 
		 */
		
		//all the work will be done here
		origHospital.init();
		
		/**NOW THE GUI STUFF**/
		
		// define dimensions and layout
		this.setSize(width, height);
		setLayout(null);
		
		//this is the whenever the mouse is moved part of the program
		addMouseMotionListener(new MouseAdapter() 
		{     
			
            public void mouseMoved(MouseEvent evt) 
            {
            	String foundText = null;
            	
        		mouseLocation = evt.getPoint();
        		
        		//check if the mouse is over a bitmap
        		foundText = origHospital.checkPoint(mouseLocation);
        		if(foundText != null)
        		{
        			mouseDisplayTextpane.setText(foundText);
        			
        			//repainting the text box
        			mouseDisplayScrollpane.repaint();
        		}    		
            }    
        });
		
		//text field intialization
		setLayout(null);
		mouseDisplayTextpane = new JTextPane();
		mouseDisplayTextpane.setBounds(10,10,textBoxWidth-20,textBoxHeight-20);
		mouseDisplayTextpane.setVisible(true);
		mouseDisplayScrollpane = new JScrollPane(mouseDisplayTextpane);
		mouseDisplayScrollpane.setVerticalScrollBarPolicy(
		JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		mouseDisplayScrollpane.setBounds(175,getSize().height-textBoxHeight,textBoxWidth,textBoxHeight);
		//getContentPane().add(mouseDisplayScrollpane);
		add(mouseDisplayScrollpane,BorderLayout.CENTER);
		
		// create the timer to force a repaint
		int delay = 250; // time in milliseconds for the timer period,slow so the time moves reasonably slow
		ActionListener taskPerformer = new ActionListener() 
		{
		      public void actionPerformed(ActionEvent evt) 
		      {
		          repaint();
		      }
		};
		
		//adding the key listener to this entire applet
		this.addKeyListener(this);
		
		//create a timer
		new Timer(delay, taskPerformer).start();
	}
	
	public void paint(Graphics g)
	{
		/**
		 * paint
		 * 
		 * PURPOSE: Defines how the applet should be painted. This
		 * includes everything displayed on screen. This uses double
		 * buffering the main graphics are sent in and a secondary
		 * graphics is written to with all the stuff to be painted.
		 * Then graphics sent in are drawn. The information obtained
		 * this time will be drawn in the next paint.
		 * 
		 */
		
		//starting
		if(dbImage == null)
		{
			dbImage = createImage (width, height-textBoxHeight);
			// dbg is now what we use to draw
			dbg = dbImage.getGraphics();
		}
		
		//invalidate all resourceBmps, all locations are erased and will only be set
		//if a resource is painted
		origHospital.invalidateBmps();
			
		//the part of the window surrounding the text box will always have focus this way
		requestFocus();
		
		// clear screen in the background for the paint after the current paint
		dbg.setColor (getBackground()); 
		dbg.fillRect (0, 0,width,height-textBoxHeight); 
		
		// define what is to be painted after the current paint
		origHospital.paint(dbg);
		
		// draw previously defined image on the screen 
		g.drawImage (dbImage,0,0, this);
		
		//repainting the text box
		mouseDisplayScrollpane.repaint();
		
	}
	
	/** The following 3 methods define what happens when keys
	 * are pressed, all are needed because keyListener is
	 * implemented.
	 */
	
	public void keyPressed(KeyEvent e) 
	{
		//whole console keys
		if(e.getKeyCode()== KeyEvent.VK_SPACE){
			origHospital.switchStop();
		}
		if(e.getKeyCode()== KeyEvent.VK_S){
			origHospital.switchStop();
		}
	}
	public void keyReleased(KeyEvent e)
	{
	}

	public void keyTyped(KeyEvent arg0)
	{	
	}
}
	