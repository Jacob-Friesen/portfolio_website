/**
* Surgeon
*
* STUDENT: Jacob Friesen, 7623030
*
* PURPOSE: records doctor type, and bitmap file location.
* 
*/

public class Surgeon extends Doctor{

	private String bmpLocation;;
	
	public Surgeon(String name,String fileName)
	{
		super(name);
		bmpLocation = fileName;
		type = "SURGEON";
		
		resourceBmp = new Bitmap(bmpLocation);
	}
}
