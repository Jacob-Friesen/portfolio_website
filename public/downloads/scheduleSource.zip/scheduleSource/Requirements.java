/**
* Requirements
*
* STUDENT: Jacob Friesen, 7623030
*
* PURPOSE: Stores one part of the requirements
* needed to treat a condition, which is the type
* of doctor and time the doctor is needed for.
* 
*/

public class Requirements {
	
	private String type;
	private int time;
	
	public Requirements(String doctorTime)
	{
		//reads in a line of info "doctortype timetotreat" is the format
		
		String[] temp;//will always be 2 because a doctor is always just with a time.
		
		temp = doctorTime.split("\\s+");//splitting by spaces, allows for 2 in a row
		type = temp[0];
		time = Integer.valueOf(temp[1]);
	}

	public int getTime() {
		return time;
	}

	public String getType() {
		return type;
	}
	
	public String toString()
	{
		return type + " " + time;
	}

}
