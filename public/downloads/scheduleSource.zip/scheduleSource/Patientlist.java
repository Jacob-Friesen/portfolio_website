/**
* Patientlist
*
* STUDENT: Jacob Friesen, 7623030
*
* PURPOSE: keeps track of the array of patients. Can schedule, print patients
* (in 3 ways),add patients to a patientList, read in patients, and sort patients
* by priority.
* 
*/

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;


public class Patientlist {
	private ArrayList <Patient>patients;
	
	public Patientlist()
	{
		patients = new ArrayList<Patient>();
	}
	
	public int getSize()
	{
		return patients.size();
	}
	
	public Patient getPatient(int index)
	{
		return patients.get(index);
	}
	
	public void add(Patient patient)
	{
		/**
		 * add
		 * 
		 * PURPOSE: adds patients to a custom assembled Patientlist (each Day class also has a patient list),
		 * assuming there already was a patient list created. (copies all info too)
		 * 
		 * PARAMETERS: patient which is the patient to be added, and conditions which are the condition set to use
		 * for the patient
		 * 
		 */
		
		patients.add(new Patient(patient.getName(),patient.getCondition()));//must do a deep copy
		//this isn't necessary but it makes the deep copy complete
		patients.get(patients.size()-1).fillResInfo(patient.getResources());//not necessary for now
		patients.get(patients.size()-1).setTimes(patient.getStart(),patient.getStop());
	}
	
	public Patient get(int index)
	{
		/**
		 * Gets patient at specified index
		 */
		
		return patients.get(index);
	}
	public Patient getPatientTime(int minute)
	{
		String[] start;
		String[] end;
		Patient foundPatient = null;
		
		//go through patients and see the closest one that is
		//still above the given minute
		for (Patient patient : patients)
		{
			//getting start and end minutes
			start = patient.getStart().split("\\s+");
			end = patient.getStop().split("\\s+");
			if(Integer.parseInt(start[0]) <= minute && Integer.parseInt(end[0]) >= minute)
			{
					foundPatient = patient;
					break;
			}
		}
		return foundPatient;
	}
	
	public void sort()
	{
		/**sorts the patients according to priority*/
		
		Collections.sort(patients);//sort keeps order between elements intact 
	}
	
	public void readPatients(String patientFile, Conditionlist conditions)
	{
		/**
		 * readPatients
		 * 
		 * PURPOSE: reads patients from a prespecified txt file and puts each one
		 * into a array slot for a Patient array. First line is the patient name second
		 * is the condition and third is a blank line. The blank line is not used.
		 * 
		 * PARAMETERS: patientFile which is a string of the location of the file to be
		 * read in, and conditions is the set of conditions to use.
		 * 
		 */

		String line;//stores input line temporarily
		String name = null;
		String condition = null;
		int count = 1;//keeps track of total number of lines

		try//error checking
		{
			//setting up file reading
			BufferedReader console;
			console = new BufferedReader(new FileReader(patientFile));

			line = console.readLine();
			while(line != null)
			{
				if(count == 1)//first in set is the name
				{
					name = line;
				}
				else if(count == 2)//second in set is the condition
				{
					assert(name != null);
					condition = line;

					//loading patient into patient array,finds actaul condition here
					patients.add(new Patient(name,conditions.getCondition(condition)));
				}
				else//third is the blank line which is not read in
				{
					assert(name != null);
					assert(condition != null);
					assert(count == 3);

					//nulling name and condition makes error checking possible earlier in this else
					condition = null;
					name = null;

					count = 0;//prepare for the next set(count is incremented at the end of the while.)
				}

				line = console.readLine();
				count++;
			}
			console.close();
		}
		catch(IOException e)
		{
			System.out.println("File was not found");
			e.printStackTrace();
		}
	}
	
	public void schedulePatients(Resourcelist resources)
	{
		/**
		 * schedulePatients
		 * 
		 * PURPOSE: puts each patient into a doctors schedule after they have been
		 * sorted for priority.
		 * 
		 * PARAMETERS: doctors are the doctors that are available to treat the
		 * patient.
		 * 
		 */
		
		/*first sort according to priority:
		 sort keeps order between elements intact (if a and b are equal and a appeared before b,
		 a will always appear before b no matter the length of the sorts or number of sorts)
		 */
		sort();
		
		for(Patient patient : patients)
		{
			resources.schedulePatient(patient);
		}
	}
	
	public void printName()
	{
		/**
		 * printNameCond
		 * 
		 * PURPOSE: prints all patients names in the original array.
		 * 
		 */

		System.out.println("\nPatient List:");
		for(Patient patient : patients)
		{
			System.out.println(patient);
		}
	}
	
	public String getFullInfo()
	{
		/**
		 * getFullInfo
		 * 
		 * PURPOSE: puts all the patients info (name,condition,start,stop and doctor treated by)
		 * into a string.
		 * 
		 */
		
		String foundString = "";
		
		foundString = "\n\nPatient info:";
		for(Patient patient : patients)
		{
			foundString += "\n----------------------------------\n";
			foundString += patient.getFullInfo();
		}
		
		return foundString;
	}
	
	public String getDocInfo()
	{
		String patientsString = "";
		
		for(Patient patient : patients)
		{
			patientsString += patient.getDocInfo() + "\n\n";
		}
		
		return patientsString;
	}
}