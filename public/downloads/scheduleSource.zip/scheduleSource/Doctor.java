import java.awt.Graphics;

/**
* Doctor
*
* STUDENT: Jacob Friesen, 7623030
*
* PURPOSE: records doctor name.
* 
*/

public class Doctor extends Resource{
	public Doctor(String name)
	{
		super(name);
		this.name = name;
		schedule = new Schedule();
	}

	public Patient paint(Graphics g, Time currentTime) {
		return null;
	}
}
