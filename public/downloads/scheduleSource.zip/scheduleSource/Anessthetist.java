/**
* Anessthetist
*
* STUDENT: Jacob Friesen, 7623030
*
* PURPOSE: records doctor type, and bitmap file location.
* 
*/

public class Anessthetist extends Doctor{

	private String bmpLocation;
	
	public Anessthetist(String name,String fileName)
	{
		super(name);
		bmpLocation = fileName;
		type = "ANESSTHETIST";
		
		resourceBmp = new Bitmap(bmpLocation);
	}
}