/**
* Conditionlist
*
* STUDENT: Jacob Friesen, 7623030
*
* PURPOSE: Keeps track of the array of conditions. Can build them from a txt file, print them, find
* an array of Requirements for a specific condition, get a conditions priority and get a condition
* given a condition string.
* 
*/

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Conditionlist {
	ArrayList <Condition>conditions;
	
	public Conditionlist()
	{
		conditions = new ArrayList<Condition>();
	}
	
	public int getSize()
	{
		return conditions.size();
	}
	
	public Condition getPlace(int index)
	{
		return conditions.get(index);
	}
	
	public Condition getCondition(String condString)
	{
		/**
		* getCondition
		* 
		* PURPOSE: searches through the Conditionlist to find
		* a condition with a equivalent string to the one sent.
		* 
		* PARAMETERS: a string which is the condition to find
		* and send back. 
		* 
		* RETURNS: a condition class instance of the condition
		* the string sent in represents.
		*/
		
		for(Condition condition : conditions)
		{
			if(condition.getName().equals(condString))
			{
				return condition;
			}
		}
		
		return null;//should never go here
	}
	
	public void readConditions(String conditionFile)
	{
		/**
		* readConditions
		* 
		* PURPOSE: reads conditions from a prespecified txt file and puts each one
		* into a array slot for a Condition array. First line is the condition name second
		* is the priority and third is the resources(I use for reading in). The following lines
		* number defined by resources, are all in caps and are the doctors needed and how much
		* of their time is needed individually.
		* 
		* PARAMETERS: conditionFile which is a string of the location of the file to be
		* read in.
		* 
		*/

		String line;//stores input line temporarily
		String name = null;
		String priority = null;
		ArrayList<String> doctorTimes = new ArrayList<String>();
		int count = 1;//starts at 1 due to increment at end of while loop
		String[] temp;

		try//error checking
		{
			//setting up file reading
			BufferedReader console;
			console = new BufferedReader(new FileReader(conditionFile));

			line = console.readLine();
			//reads line into name if even and if odd reads into time. (0 is even)
			while(line != null)
			{
				if(count == 1)//if count is even (integer division finds this)
				{
					name = line;
				}
				else if(count == 2)
				{
					assert(name != null);
					temp = line.split(" ");//splitting by spaces
					priority = temp[1];
				}
				else if(count == 3)
				{
					assert(name != null);
					assert(priority != null);
					
					//A mini while loop to read in the resource requirements
					temp = line.split(" ");//splitting by spaces
					count = Integer.valueOf(temp[1]);//the word resources is irrelevant
					while(count > 0)
					{
						line = console.readLine();
						
						//compile arrayList
						doctorTimes.add(line); 
						
						count--;
					}

					//loading condition into condition array
					conditions.add(new Condition(name,Integer.valueOf(priority),doctorTimes));
					doctorTimes.clear();

					//nulling name makes error checking possible earlier in this else
					name = null;
					priority = null;
					
					count = 0;
					line = console.readLine();//skips the blank line at the end of each doctor 
				}

				line = console.readLine();
				
				count++;
			}
			console.close();
		}
		catch(IOException e)
		{
			System.out.println("File was not found");
			e.printStackTrace();
		}	
	}
	
	public ArrayList<Requirements> conditionTimes(Condition condition)
	{
		/**
		* conditionTimes
		* 
		* PURPOSE: finds the resources a condition will take to get treated from
		* a string given.
		* 
		* PARAMETERS: a specific condition
		* 
		* RETURNS: A organized form of data (Requirements) that contains all the necessary
		* time and type of doctor info.
		* 
		*/
		
		int count = 0;
		ArrayList<Requirements> timeInfo = new ArrayList<Requirements>();
		
		for(count = 0;count < this.getSize(); count++)
		{
			if((this.getPlace(count)) == condition)//condition sent equals condition found
			{
				timeInfo = (this.getPlace(count)).getRequirements();//gets the conditions time and type requirements
			}
		}
		return timeInfo;
	}
	
	public int conditionPriority(Condition condition)
	{
		/**
		* conditionPriority
		* 
		* PURPOSE: finds the priority of the condition sent in
		* 
		* PARAMETERS: condition is the string for the condition name
		* 
		* RETURNS: the priority the condition has that was given as a int.
		* 
		*/
		
		return condition.getPriority();
	}
	
	public void printConditions()
	{
		/**
		* printConditions
		* 
		* PURPOSE: prints all conditions in the original array, which is the name and time
		* it takes to treat the condition.
		* 
		*/

		System.out.println("\nCondition List:");
		for(Condition cond : conditions)
		{
			System.out.println(cond);
		}
	}
}
