import java.awt.Graphics;
import java.awt.Point;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;

import javax.imageio.ImageIO;

/**
* Bitmap
*
* STUDENT: Jacob Friesen, 7623030
*
* PURPOSE: Manages a buffered image in the form of a bitmap. Keeps the
* location of the bitmap in the applet too.
* 
*/

public class Bitmap 
{
	private BufferedImage img = null;
	private Point location;//stores the location (bottom right) of bitmap
	private boolean offScreen;
	
	public Bitmap(String filename) 
	{
		location = new Point(-99,-99);
		try 
		{
			img = ImageIO.read(new File(filename));
		} 
		catch (IOException e) 
		{
			System.out.println(e);
		}
		
		offScreen = true;
	}
	
	// the point is defined by the room which the person is located in
	public void paintBmp(Graphics g, Point location2) 
	{
		//record location
		location.setLocation(location2);   
		
		g.drawImage(img,(int)location.getX(),(int)location.getY(),null);
	}
	
	public int getSizeX()
	{
		return img.getWidth(); 
	}
	
	public void setOffScreen(boolean variable)
	{
		offScreen = variable;
	}
	
	public boolean getOffScreen()
	{
		return offScreen;
	}
	
	public boolean isIn(Point point)
	{
		/**
		 * isIn
		 * 
		 * PURPOSE: Checks if the current point is in
		 * the buffered image of this class.
		 * 
		 * PARAMETERS: point is the point to check for.
		 * 
		 * RETURNS: true or false, false if the point isn't in the 
		 * current buffered image.
		 * 
		 */
		
		boolean isIn = false;
		
		//must first check if there is a image and a valid location it was placed at
		if(img != null && location != null)
		{
			//in the width
			if(point.getX() <= (location.getX() + img.getWidth()) && point.getX() >= location.getX())
			{
				//and in the height
				if(point.getY() <= (location.getY() + img.getHeight()) && point.getY() >= location.getY())
				{
					isIn = true;
				}
			}
		}
		
		return isIn;
	}

}
