import java.awt.Graphics;

/**
* Nurse
*
* STUDENT: Jacob Friesen, 7623030
*
* PURPOSE: keeps track of the nurse name and records type. Also
* is records the location of a specific nurse bitmap.
* 
*/

public class Nurse extends Resource{
	
	private String bmpLocation;
	
	public Nurse(String name,String fileName)
	{
		super(name);
		bmpLocation = fileName;
		this.type = "NURSE";
		schedule = new Schedule();
		
		resourceBmp = new Bitmap(bmpLocation);
	}
	
	public Patient paint(Graphics g, Time currentTime) 
	{
		return null;
	}
}