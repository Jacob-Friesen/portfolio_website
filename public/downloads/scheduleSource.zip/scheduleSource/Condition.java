import java.util.ArrayList;

/**
* Condition
*
* STUDENT: Jacob Friesen, 7623030
*
* PURPOSE: Keeps track of a conditions name and priority and resources
* required to treat the condition. Highest priority is 1 and lowest is 4.
* 
*/

public class Condition
{
	private String name;
	private int priority;
	//this is the info of the requirements to treat the condition
	private ArrayList<Requirements> treaters = new ArrayList<Requirements>();
	
	public Condition(String name,int priority, ArrayList<String> doctorTimes)
	{	
		this.name = name;
		this.priority = priority;
		
		//converting doctorTimes to a array of treatments.
		for(int count = 0;count < doctorTimes.size();count++)
		{
			treaters.add(new Requirements(doctorTimes.get(count)));
		}
	}
	
	public String getName()
	{
		return name;
	}

	public int getPriority()
	{
		return priority;
	}
	
	public ArrayList<Requirements> getRequirements()
	{
		return treaters;
	}
	
	public String toString()
	{
		return name;
	}
}
