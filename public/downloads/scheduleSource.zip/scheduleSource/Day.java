/**
* Day
*
* STUDENT: Jacob Friesen, 7623030
*
* PURPOSE: class which keeps track of the patients scheduled for a doctors given day. Also
* keeps track of what day number itself is (dayId). Can place a patient into this day's
* PatientList, and print the day's PatientList.
* 
*/

public class Day {
	private final int TOTAL_TIME;
	private int[] timeBlocks;//tracks used time blocks for the current day, 1 is used 0 is not
	private int workStart;
	private int breaks;
	private Patientlist dayPatients;//list of patients for the day
	
	public Day()
	{
		/*for now all the numbers will be initialized by hard coding but that can be easily
		fixed by modifying the parameters.*/
		
		TOTAL_TIME = 480;
		timeBlocks = new int[TOTAL_TIME];
		workStart = 5;
		fillTime(0,workStart);//fill the 5 minutes at work start
		breaks = 5;
		dayPatients = new Patientlist();
	}
	
	public void place(int treatTime, Patient patient, int day,int minute)
	{
		/**
		 * place
		 * 
		 * PURPOSE: places the given doctors patient in the patient ArrayList at this day at
		 * the current minute specified for the time specified.
		 * 
		 * PARAMETERS: treatTime is how much time the patient needs to be treated for. Patient
		 * is the one being treated, and minute is the time to schedule at.
		 * 
		 */
		
		int start = minute;
		int end = 0;
			
		fillTime(start,treatTime);//fill in the treat times
		
		end  = start + treatTime;
		
		if(start + treatTime + breaks < TOTAL_TIME)//if there is room at the end add break time
		{
			fillTime(end,breaks);
		}
		
		dayPatients.add(patient);
		//times haven't been set for any patients yet so this new copy will need to be set
		( dayPatients.get(dayPatients.getSize()-1) ).setTimes(start + " minutes " + day + " days",end + " minutes " + day + " days");
	}
	
	public int findEarliestBlock(int treatTime, int minuteAfter)
	{
		/**
		 * findEarliestBlock
		 * 
		 * PURPOSE: loops through array until a block of time is equal or greater
		 * than the time sent is found after the minute specified, with the break
		 * added.
		 * 
		 * PARAMETERS: treatTime is how much time the patient needs to be treated for.
		 * minuteAfter is the time in this day to schedule after.
		 * 
		 * RETURNS: a int specifying the earliest time the patient can be scheduled in
		 * the day, -1 if its impossible to schedule.
		 * 
		 */
		
		int count = 0;
		int earliestTime = -1;//-1 means a failure to find a block in the day
		int block = 0;//counts how large a current block is
		
		//loops until end of array(returns -1) or until a big enough time block was found
		for(count = minuteAfter;count < timeBlocks.length - 1 && earliestTime == -1; count++)
		{
			//found a non used minute
			if(timeBlocks[count] == 0)
			{
				//loop to find how big the time block is
				while(timeBlocks[count] == 0 && count < timeBlocks.length - 1)
				{
					block++;
					count++;//remember still moving through the array
				}
				
				//check if block is large enough
				if(block >= treatTime + breaks)//must check for if there is enough time for a break after
				{
					/*Count the rest and add to block so the beginning of the time able to schedule
					 is found correctly.*/
					block = block + (TOTAL_TIME - count) - 1;
					
					earliestTime = TOTAL_TIME - block - 1;
				}
				//in the case that the break + minuteAfter + treatTime exceeds total time no break needs
				//to be given.
				else if(treatTime + breaks + minuteAfter >= 480 && block >= treatTime)
				{
					block = block + (TOTAL_TIME - count) - 1;
					
					earliestTime = TOTAL_TIME - block - 1;
				}
				else//have to remember to reset block on failure to be large enough
				{
					block = 0;
				}
			}
		}
		
		return earliestTime;
	}
	
	public void fillTime(int start, int time)
	{
		/**
		 * fillTime
		 * 
		 * PURPOSE: loops through array starting at the minute specified and until
		 * the time specified. Fills in by setting the array slot(minute) to 1, if
		 * the minute is already one this prints ERROR.(should never happen).
		 * 
		 * PARAMETERS: start is the time to start placing, and time is for how many
		 * array slots to place for.
		 * 
		 */
		
		int count = 0;
		
		for(count = 0;count < time;count++)
		{
			if(timeBlocks[start + count] == 1)
			{
				System.out.println("ERROR HERE");//this is good for error checking
			}
			else
			{
				timeBlocks[start + count] = 1;//1 is filled
			}
		}
		
	}
	
	public Patient getPatient(int minute)
	{
		/**
		 * getPatient
		 * 
		 * PURPOSE: gets the patient at the given minute
		 * 
		 */
		
		Patient patient;
		
		//go through the list of patients
		patient = dayPatients.getPatientTime(minute);
		
		return patient;
	}
	
	public String toString()
	{
		/**
		 * getPatient
		 * 
		 * PURPOSE: gets the patient at the given minute
		 * 
		 */
		
		//go through the list of patients
		return dayPatients.getDocInfo();
	}
}
