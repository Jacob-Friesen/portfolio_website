/**
* SurgeryRoom
*
* STUDENT: Jacob Friesen, 7623030
*
* PURPOSE: records the room type
* 
*/

public class SurgeryRoom extends Room{
	
	private int roomID;
	
	public SurgeryRoom(String name, int roomID)
	{
		super(name,roomID);
		this.roomID = roomID;
		type = "SURGERYROOM";
	}
}
