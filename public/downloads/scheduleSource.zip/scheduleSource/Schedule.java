/**
* Schedule
*
* STUDENT: Jacob Friesen, 7623030
*
* PURPOSE: keeps track of a doctor's current day and the ArrayList of
* days of the doctors schedule. Each day will contain a Patientlist
* of patients to be treated that day by the doctor. Can add days,
* place patients into days and print each days schedule. As well as
* sort the patients of each day by start time, and get the earliest
* time to treat a patient.
* 
*/

import java.util.ArrayList;

public class Schedule {
	private ArrayList<Day> days;//keeps track of the days that that each contian the doctors schedule.
	
	public Schedule()
	{
		days = new ArrayList<Day>();
		days.add(new Day());//start with one blank day slot(needs identifier of which day it is)
	}
	
	public void addDay()
	{
		/**
		 * addDay
		 * 
		 * PURPOSE: adds schedules day by 1
		 * 
		 */
		
		//day++;
		days.add(new Day());//add a new blank day
	}
	
	public int[] getEarliestTime(int treatTime ,int[] after)
	{
		/**
		 * getEarliestTime
		 * 
		 * PURPOSE: gets the earliest time in the current schedule of days.
		 * 
		 * PARAMETERS: treatTime is how long a scheduled treatment will take
		 * and after is the time to look after for a valid time. 1 is minute
		 * and 0 is day to look after.
		 * 
		 * RETURNS: the int[] value of the earliest time of the schedule.0
		 * is day and 1 is minute.
		 * 
		 */
		
		int count = 0;
		int[] earliestTime = new int[2];//0 is day 1 is the minute
		earliestTime[1] = -1;
		
		//look through the days until a time that works is found or no time is found
		for(count = after[0];count < days.size() && earliestTime[1] == -1;count++)
		{
			//just look after the minute specified for the first day
			if(count == after[0])
			{
				earliestTime[1] = days.get(count).findEarliestBlock(treatTime,after[1]);
			}
			else
			{
				earliestTime[1] = days.get(count).findEarliestBlock(treatTime,0);//start finding at the beggining now
			}
			
			//this set what day the valid time was found at
			if(earliestTime[1] > -1)
			{
				earliestTime[0] = count;
			}
		}
		
		return earliestTime;
	}
	
	public void placePatient(int treatTime, Patient patient,int minDay,int minute)
	{
		/**
		 * placePatient
		 * 
		 * PURPOSE: places a patient into the current day at the minute and day given
		 * for the given time.
		 * 
		 * PARAMETERS: treatTime is the time the patient takes the patient
		 * get treated. patient is that patient. minDay is the day to schedule on and
		 * minute is the minute to schedule on, and conditions is the set of conditions to use.
		 * 
		 */
	
		days.get(minDay).place(treatTime,patient,minDay,minute);//sending day in so patient info can be filled
	}
	
	public Patient getPatient(Time time)
	{
		if(time.getDay() < days.size())
		{
			return days.get(time.getDay()).getPatient(time.getMinute());
		}
		else
		{
			return null;
		}
	}
	
	public String getDays()
	{
		String daysString = "";
		int count = 0;
		
		for(Day day : days)
		{
			daysString += "====day " + count + "====\n";
			daysString += day.toString();
			count++;
		}
			
		return daysString;
	}
}