/**
* GeneralRoom
*
* STUDENT: Jacob Friesen, 7623030
*
* PURPOSE: records the room type
* 
*/


public class GeneralRoom extends Room{
	
	private int RoomID;
	
	public GeneralRoom(String name,int RoomID)
	{
		super(name,RoomID);
		this.RoomID = RoomID;
		type = "GENERALROOM";
	}
}
