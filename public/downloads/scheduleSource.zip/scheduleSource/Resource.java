import java.awt.Graphics;
import java.awt.Point;

/**
* Resource
*
* STUDENT: Jacob Friesen, 7623030
*
* PURPOSE: keeps track of the name and type of a resource and their schedule.
* Able to place patients into the schedule and print the schedule or the 
* resource name and type, also able to add a day to the resource's schedule,
* and sort the resources patients by start time. Also can paint and check resource
* Bmps. Some of these methods are overridden, see subclasses.
* 
*/

abstract class Resource {
	
	protected String name;
	protected String type;
	protected Schedule schedule;
	protected Bitmap resourceBmp;
	protected String bmpLocation = "";
	
	public Resource(String name)
	{
		this.name = name;
		schedule = new Schedule();
	}
	
	public String getType()
	{
		return type;
	}
	
	public String getName()
	{
		return name;
	}
	
	/**BitmapStuff**/
	
	public abstract Patient paint(Graphics g,Time currentTime);
	
	public void paintBmp(Graphics g,Point location)
	{
		/** given a location paint a bitmap **/
		
		resourceBmp.paintBmp(g,location);
	}
	
	public boolean checkOwnBmp(Point point)
	{
		/**
		 * checkOwnBmp
		 * 
		 * PURPOSE: checks if the point sent in is in the resources bitmap.
		 * 
		 */
		
		boolean isIn = false;
		
		//does not check rooms since all rooms bmps will be null
		if(resourceBmp != null)
		{
			isIn = resourceBmp.isIn(point);
		}
		
		return isIn;
	}
	
	public int getSizeX()
	{
		return resourceBmp.getSizeX();
	}
	
	public boolean canFindPatient(Time currentTime,Patient patient)
	{
		/**
		 * canFindPatient
		 * 
		 * PURPOSE: tries to find the patient sent in at the current
		 * time in the current resource.
		 * 
		 * PARAMETERS: the current time in the applet and patient is
		 * the patient to search for.
		 * 
		 * RETURNS: true or false, false if no patient was found.
		 * 
		 */
		
		boolean foundCorrect = false;
		Patient foundPatient = null;
		
		//check if correct patient was found
		foundPatient = schedule.getPatient(currentTime);
		if(foundPatient != null && foundPatient.getName().equals(patient.getName()))
		{
			foundCorrect =  true;
		}
		
		return foundCorrect;
	}
	
	public void setOffScreen(boolean variable)
	{
		resourceBmp.setOffScreen(variable);
	}
	
	public boolean getOffScreen()
	{
		return resourceBmp.getOffScreen();
	}
	
	/**schedule stuff**/
	
	public int[] getEarliestTime(int treatTime, int[] after)
	{
		//Just calls schedules get earliest time.
		
		return schedule.getEarliestTime(treatTime, after);
	}
	
	public void addDay()
	{
		/**
		 * addDay
		 * 
		 * PURPOSE: adds schedules day count by 1.
		 * 
		 */
		
		schedule.addDay();
	}
	
	public void placePatient(int treatTime,Patient patient,int minDay, int minute)
	{
		/**
		 * placePatient
		 * 
		 * PURPOSE:  The method places the patient into the doctor's schedule
		 * 
		 * PARAMETERS: treatTime is the time the patient takes the patient
		 * get treated. patient is that patient. minDay is the day to schedule on and
		 * minute is the minute to schedule on. and conditions is the set of conditions to use.
		 * 
		 */
		
		patient.addResource(this);
		
		schedule.placePatient(treatTime,patient,minDay,minute);
		
	}
	public void deleteSchedule()
	{
		schedule = null;
	}
	
	public String getSchedule()
	{
		/**
		 * getSchedule
		 * 
		 * PURPOSE: gets all the schedule information in one string.
		 * 
		 */
		
		return toString() + "\n" + schedule.getDays();
	}
	
	public String toString()
	{
		return type + ": " + name;
	}
}
