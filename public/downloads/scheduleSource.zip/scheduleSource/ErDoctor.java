/**
* ErDoctor
*
* STUDENT: Jacob Friesen, 7623030
*
* PURPOSE: records doctor type, and bitmap file location.
* 
*/

public class ErDoctor extends Doctor{

	private String bmpLocation;
	
	public ErDoctor(String name,String fileName)
	{
		super(name);
		bmpLocation = fileName;
		type = "ERDOCTOR";
		
		resourceBmp = new Bitmap(bmpLocation);
	}
}
