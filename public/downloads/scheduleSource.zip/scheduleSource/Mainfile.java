import java.awt.Dimension;
import java.net.MalformedURLException;

import javax.swing.JFrame;

/**
* Mainfile (of doctor program)
*
* COMP 2150 SECTION A01
* INSTRUCTOR: Jay Kraut
* ASSIGNMENT: Assignment 4
* STUDENT: Jacob Friesen, 7623030
* DUE DATE: August 3rd
*
* PURPOSE: 
* Implements a GUI to do the below.(Same description of assignment 3's)
* 
* From a list of doctors and patients and conditions; schedules
* each patient into a doctors schedule based on priority then if equal on a first come
* first serve basis. The conditions read in are so each patient can be scheduled correctly.
* Each patient has a condition with each unique condition having a list of doctor types and
* their times needed for. More details in classes (and class methods).
*
*/

public class Mainfile {
	public static void main(String[] args) throws MalformedURLException{
		
		Dimension size = new Dimension(1000,650);
		JFrame frame = new JFrame();
		
		System.out.println("Welcome to the Supreme Scheduling Sensation v1.0\n");
		
		//make sure the "applet" exits correctly
		frame.addWindowListener(new java.awt.event.WindowAdapter() 
		{
			 public void windowClosing(java.awt.event.WindowEvent e) 
			 {
				 System.exit(0);
			 };
		});
		
		//generate the main gui to display with frame displayed as big as the original applet
		MainGUI mainScreen = new MainGUI();
		frame.add(mainScreen);
		frame.pack();
		mainScreen.init();
		frame.setSize(size);
		
		//make the frame size unchangeable
		frame.setResizable(false);
		
		//set the frame to be seeable
		frame.setVisible(true);

		System.out.println("\nProgram completed normally\n");
	}
}