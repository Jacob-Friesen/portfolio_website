import java.awt.Graphics;
import java.awt.Point;
import java.util.ArrayList;

/**
* Resourcelist
*
* STUDENT: Jacob Friesen, 7623030
*
* PURPOSE: keeps track of the ArrayList of resources. Includes scheduling(via external class) of patients,
* printing of resource(name and type) and resources schedules, and sorting all the resources in the lists
* patients. Also manages checking and painting all the resources.
* 
*/

public class Resourcelist{

	ArrayList<Resource> resources;//using a ArrayList because its easier to modify later.
	MatchSystem matcher;//used to find where to schedule a patient into a doctors schedule
	
	public Resourcelist()
	{	
		resources = new ArrayList<Resource>();
		matcher = new MatchSystem(resources);
	}
	
	public void createResources()
	{
		/**
		 * createDoctors
		 * 
		 * PURPOSE: creates 5 doctors, 2 nurses and 2 rooms with hard coded names,
		 * types, and file locations.
		 * 
		 */

		//alphabetical order names for easier tracking
		resources.add(new ErDoctor("Alfred","resources/alfred.bmp"));//"scheduling.jar/alfred.bmp"));
		resources.add(new ErDoctor("Ben","resources/ben.bmp"));
		resources.add(new Surgeon("Charmander","resources/charmander.bmp"));
		resources.add(new Surgeon("Death","resources/death.bmp"));
		resources.add(new Anessthetist("Electricut","resources/electricut.bmp"));
		
		//nurse
		resources.add(new Nurse("Fran the Grimy,","resources/fran.bmp"));
		resources.add(new Nurse("Grega the Bloody","resources/grega.bmp"));
		resources.add(new Nurse("Hormaocka the experimental","resources/hormaocka.bmp"));
		resources.add(new Nurse("Ingrid the Dangerous","resources/ingrid.bmp"));
		
		//rooms (name and their room ID's)
		resources.add(new GeneralRoom("1",1));
		resources.add(new GeneralRoom("2",2));
		resources.add(new SurgeryRoom("1",3));
		resources.add(new SurgeryRoom("2",4));
		
	}
	
	public void printIDs()
	{
		/**
		 * printDoctors
		 * 
		 * PURPOSE: prints all the doctors names and types.
		 * 
		 */

		System.out.println("Doctor Names:");
		for(Resource resource : resources)
		{
			System.out.println(resource);
		}
	}
	
	public void schedulePatient(Patient patient)
	{
		/**
		 * schedulePatient
		 * 
		 * PURPOSE: uses the matcher class to place the patient into this Doctorlist
		 * 
		 * PARAMETERS: patient is the patient to be placed. conditions is
		 * the set of conditions to look up for the patient.
		 * 
		 */
		
		matcher.schedulePatient(patient);//schedules the patient into this doctors list
	}
	
	public void invalidateBmps()
	{
		for(Resource resource : resources)
		{
			if(!(resource.getType().equals("GENERALROOM") || resource.getType().equals("SURGERYROOM")))
			{
				resource.setOffScreen(true);
			}
		}
	}
	
	public Patient[] paint(Graphics g, Time currentTime)
	{
		/**
		 * paint
		 * 
		 * PURPOSE: paints all the rooms which is all the required information.
		 * 
		 * PARAMETERS: g is what is painted to, and time is the time being displayed and
		 * what time the displaying is linked to.
		 * 
		 * RETURNS: The list of patients that currently have a bitmap in a room.
		 * 
		 */
		
		Patient[] currentPatients = new Patient[4];//4 rooms one patient per room
		int count = 0;
		
		for(Resource resource : resources)
		{
			//only need to paint the rooms doctors will be painted automatically
			if(resource.getType().equals("GENERALROOM") || resource.getType().equals("SURGERYROOM") && count < currentPatients.length)
			{
				currentPatients[count] = resource.paint(g,currentTime);
				count++;
			}
		}
		
		return currentPatients;
	}
	
	public Resource checkDoctorBmps(Point point)
	{
		/**
		 * checkDoctorBmps
		 * 
		 * PURPOSE: sees if the current point sent in is in any of the doctors (not rooms).
		 * 
		 * PARAMETERS: point which is the point to search for
		 * 
		 * RETURNS: The list of patients that currently have a bitmap in a room.
		 * 
		 */
		
		Resource found = null;
		
		for (Resource resource : resources)
		{
			if(!(resource.getType().equals("GENERALROOM") || resource.getType().equals("SURGERYROOM")))
			{
				if(resource.checkOwnBmp(point) == true && resource.getOffScreen() == false)
				{
					found = resource;
				}
			}
		}
		
		return found;
	}
	
	public String toString()
	{
		String returnString = "";
		
		returnString = "\n--------------Doctor Schedules:---------------";
		for(Resource resource : resources)
		{
			returnString+= resource.getSchedule();
		}
		
		return returnString;
	}
}
