/**
* Time
*
* STUDENT: Jacob Friesen, 7623030
*
* PURPOSE: stores a time and methods to manipulate it
* 
*/
public class Time {
	
	private int day;
	private int minute;
	private int TIME_IN_DAY = 480;
	
	public Time()
	{
		day = 0;
		minute = 0;
	}
	
	public Time(int day, int minute)
	{
		this.day = day;
		this.minute = minute;
	}
	
	public int getDay()
	{
		return day;
	}
	
	public int getMinute()
	{
		return minute;
	}
	
	public void increment(int by)
	{
		/** increments time by the variable sent in
		 * and if the minute is past the day minute
		 * limit it is reset and the day number is increased.
		 */
		
		if(minute < TIME_IN_DAY)
		{
			minute = minute + 5;
		}
		else
		{
			minute = 0;
			day++;
		}
	}

}
