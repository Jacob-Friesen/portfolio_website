﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ContactList
{
    public partial class newForm : ContactList.Entry
    {
        //for the inheritance
        public newForm()
        {
            InitializeComponent();
        }

        public newForm(ListView listCopy,ListView fullCopy)
        {
            InitializeComponent();

            this.listCopy = listCopy;
            this.fullCopy = fullCopy;

            initButtons();
        }

        public void updateFull(ListView sentList)
        {
            fullCopy = sentList;
        }

        /* Menu events*/
        public override void clickedSaved(object sender, EventArgs e)
        {
            //create a line to be added to the listView
            ListViewItem mainListItems = new ListViewItem();

            //add the items to the line

            //need to enter all entries
            if (!firstNameT.Text.Equals("") && !lastNameT.Text.Equals("") && !ageT.Text.Equals("") && !universityYearT.Text.Equals("") && !phoneNumT.Text.Equals("") && radioClicked != null)
            {
                mainListItems = new ListViewItem(firstNameT.Text);
                mainListItems.SubItems.Add(lastNameT.Text);
                mainListItems.SubItems.Add(ageT.Text);
                mainListItems.SubItems.Add(radioClicked);//value derived from events
                //radio buttons cannot be reset
                mainListItems.SubItems.Add(universityYearT.Text);
                mainListItems.SubItems.Add(phoneNumT.Text);

                //add the line to the display list and the full list
                listCopy.Items.Add((ListViewItem)mainListItems.Clone());
                fullCopy.Items.Add((ListViewItem)mainListItems.Clone());//(MAY BE A SOFT COPY)

                resetVariables();

                this.Hide();
            }
            else
            {
                MessageBox.Show("Error: no text entered");
            }
        }
    }
}
