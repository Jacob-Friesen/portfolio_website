﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.IO;
using System.Windows.Forms;

namespace ContactList
{
    /* This class reads and manipulates an xml file
     * */

    class xmlReader
    {
        private XmlDocument contacts;
        private ListView listContacts;

        public xmlReader(ListView listContacts, XmlDocument contacts)
        {
            this.contacts = contacts;
            this.listContacts = listContacts;//remember this is a soft copy
        }

        public void loadXml(String fileName)
        {
            /* PURPOSE:
             * loads the sent xml file and adds all the data from
             * it to the sent in listView.
             */

            FileStream file = new FileStream(fileName, FileMode.Open, FileAccess.ReadWrite);

            contacts.Load(file);

            /*if (listContacts != null)
            {
                listContacts = new ListView();
            }*/

            //get each individual element
            foreach (XmlElement item in contacts.SelectNodes(@"contactlist/contact"))
            {
                //A debug line
                Console.WriteLine("item: |" + item["lastname"].InnerText + "| ");

                //create a line to be added to the listView
                ListViewItem mainListItems = new ListViewItem();

                //add the items to the line
                mainListItems = new ListViewItem(item["firstname"].InnerText + "");
                mainListItems.SubItems.Add(item["lastname"].InnerText + "");
                mainListItems.SubItems.Add(item["age"].InnerText + "");
                mainListItems.SubItems.Add(item["gender"].InnerText + "");
                mainListItems.SubItems.Add(item["universityyear"].InnerText + "");
                mainListItems.SubItems.Add(item["phone"].InnerText + "");

                //add the line to the listView
                listContacts.Items.Add((ListViewItem)mainListItems.Clone());
            }

            //have to do this to allow multiple file openings
            file.Close();
        }

    }
}
