﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;//for the ArrayList
using System.Xml;



namespace ContactList
{
    public partial class mainForm : Form
    {
        private String path = Application.StartupPath;

        private Boolean loaded = false;

        //might as well use a little bit of object orientation
        private xmlReader xmlReader;
        private XmlDocument contactsPage;//now easy to modify if there is changes

        //forms
        private newForm newFormWindow;
        private editForm editFormWindow;

        //listView variables
        private List<ListViewItem> lastSelectedRow;
        private int minAge;
        private int lastAge;//the last age that was selected

        public mainForm()
        {
            InitializeComponent();

            contactsPage = new XmlDocument();
            xmlReader = new xmlReader(listContacts, contactsPage);

            newFormWindow = new newForm(listContacts,dataList);
            editFormWindow = new editForm(listContacts, dataList, lastSelectedRow);

            minAge = 0;
            lastAge = minAge;

            //column num should already be loaded
            lastSelectedRow = new List<ListViewItem>();

            //these will just add the event handlers
            initMenus();
            initButtons();
            initListView();
            initTrackBar();
        }

        public void initMenus()
        {
            exitToolStripMenuItem.Click += new EventHandler(clickedExit);
            loadToolStripMenuItem.Click += new EventHandler(clickedLoad);
        }

        public void initButtons()
        {
            newButton.Click += new EventHandler(clickedNew);
            editButton.Click += new EventHandler(clickedEdit);
            deleteButton.Click += new EventHandler(clickedDelete);
        }

        public void initListView()
        {
            //do when a item selected is changed (can be from null)
            listContacts.SelectedIndexChanged += new EventHandler(selectedIndexChanged);

            cloneFromTo(listContacts, dataList);
        }

        public void initTrackBar()
        {
            ageTrackBar.Scroll +=new EventHandler(scrolledBar);
        }

        /* Menu events*/
        public void clickedNew(object sender, EventArgs e)
        {
            if (loaded == true)
            {
                //launch the form that happens when new is clicked
                newFormWindow.Show();
            }
            else
            {
                MessageBox.Show("Error: File not loaded");
            }
        }

        public void clickedEdit(object sender, EventArgs e)
        {
            if (loaded == true)
            {
                editFormWindow.Visible = false;
                if (lastSelectedRow.Count > 0)
                {
                    //get the visbility to work
                    editFormWindow.loadValues(lastSelectedRow);
                    editFormWindow.Show();
                }
                else
                {
                    MessageBox.Show("Error: no row selected");
                }
            }
            else
            {
                MessageBox.Show("Error: File not loaded");
            }
        }

        public void clickedDelete(object sender, EventArgs e)
        {
            //need this because least Selected row is deleted from modifying the count
            int rowCount = lastSelectedRow.Count;

            if (loaded == true)
            {
                //this shows how to select all the items (and subitems)
                string fullString = "";
                foreach (ListViewItem item in lastSelectedRow)
                {
                    foreach (ListViewItem.ListViewSubItem subItem in item.SubItems)
                    {
                        fullString += subItem.Text;
                    }
                    fullString += "\n";
                }
               // MessageBox.Show("Rows are:\n" + fullString);

                //delete selected rows, modifying collection so I cannot delete with foreach
                for (int count = 0; count < rowCount; count++)
                {
                    //remove  the identical object from the full list
                    (dataList.FindItemWithText(lastSelectedRow[0].Text)).Remove();
                    newFormWindow.updateFull(dataList);
                    editFormWindow.updateFull(dataList);

                    //keep in mind the collection keeps on shrinking on each delete
                    lastSelectedRow[0].Remove();
                }

                //modify XML here
            }
            else
            {
                MessageBox.Show("Error: File not loaded");
            }

        }

        public void clickedExit(object sender, EventArgs e)
        {
            //close application the safe way
            Dispose();
        }

        public void clickedLoad(object sender, EventArgs e)
        {
            //MessageBox.Show("clicked Load");

            //must clear previous list before loading a new one
            openFileDialog1 = new OpenFileDialog();

            //start where the application exe file is located
            openFileDialog1.InitialDirectory = path;
            //what files can be used
            openFileDialog1.Filter = "xml files (*.xml)|*.xml";
            //openFileDialog1.FilterIndex = 2;
            openFileDialog1.RestoreDirectory = true;

            //show the dialog box on screen
            openFileDialog1.ShowDialog();

            //get the opened files name and then loads its xml (WARNING:doing this now may cause errors)
            xmlReader.loadXml(openFileDialog1.FileName);

            //make sure the fullist is consistent with the displayed one here
            dataList = new ListView();
            cloneFromTo(listContacts, dataList);
            newFormWindow.updateFull(dataList);
            editFormWindow.updateFull(dataList);

            loaded = true;

            updateList();//update the visible list view
        }

        /*trackbar events*/
        public void scrolledBar(object sender, EventArgs e)
        {
            //MessageBox.Show("You scrolled it babey!\n" + ageTrackBar.Value);
            lastAge = minAge;
            minAge = ageTrackBar.Value * 10;

            //going leftwards
            if(lastAge > minAge)
            {
                //remove all of the display lists rows but keep the columns
                listContacts.Items.Clear();
                cloneFromTo(dataList, listContacts);
            }

            updateList();
        }

        public void updateList()
        {
            /* PURPOSE:
             * changes the view list according to where the slider is
             */

            //find items less than minAge and delete them
            foreach (ListViewItem item in listContacts.Items)
            {
                Console.WriteLine(item.SubItems[2].Text + " | " + minAge);
                //check if item is less than minage if so remove (remember it's still stored )
                if (Convert.ToInt32(item.SubItems[2].Text) < minAge)//2 is the age
                {
                    item.Remove();
                }
            }

            listContacts.Visible = true;
        }

        /*List view events*/
        public void selectedIndexChanged(object sender, EventArgs e)
        {

            //clear previous selected entries
            lastSelectedRow.Clear();

            //gets each line selected
            foreach (ListViewItem item in listContacts.SelectedItems)
            {
                lastSelectedRow.Add(item);

                //find the item in fullList
                //MessageBox.Show(fullList.FindItemWithText(item.Text) + "");
            }
        }

        /*no clone method for listView so I made one*/
        public void cloneFromTo(ListView from,ListView to)
        {
            /* PURPOSE:
             *  Hard copies the first list view data into the secound
             * */

            ListViewItem mainListItems = new ListViewItem();
            int count = 0;

            //create the templist
            foreach (ListViewItem item in from.Items)
            {
                //get each individual element
                foreach (ListViewItem.ListViewSubItem subItem in item.SubItems)
                {
                    //add the items to the line
                    if (count == 0)
                    {
                        mainListItems = new ListViewItem(subItem.Text);
                    }
                    else
                    {
                        mainListItems.SubItems.Add(subItem.Text);
                    }

                    count++;
                }
                //add the line to the listView
                to.Items.Add((ListViewItem)mainListItems.Clone());
                to.Visible = true;

                count = 0;
            }
        }

    }
}
