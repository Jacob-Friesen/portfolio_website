﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ContactList
{
    public partial class editForm : ContactList.newForm
    {
        private List<ListViewItem> currentRow;
        int fullCopyPos;

        public editForm(ListView listCopy,ListView fullCopy, List<ListViewItem> lastSelectedRow)
        {
            InitializeComponent();

            this.listCopy = listCopy;//soft copy
            this.fullCopy = fullCopy;//soft copy
            currentRow = lastSelectedRow;//soft copy
            fullCopyPos = -1;

            initButtons();
        }

        public override void clickedSaved(object sender, EventArgs e)
        {

            //create a line to be added to the listView
            ListViewItem mainListItems = new ListViewItem();

            //add the items to the line

            //need to enter all entries
            if (!firstNameT.Text.Equals("") && !lastNameT.Text.Equals("") && !ageT.Text.Equals("") && !universityYearT.Text.Equals("") && !phoneNumT.Text.Equals("") && radioClicked != null)
            {
                mainListItems = new ListViewItem(firstNameT.Text);
                mainListItems.SubItems.Add(lastNameT.Text);
                mainListItems.SubItems.Add(ageT.Text);
                mainListItems.SubItems.Add(radioClicked);//value derived from events
                //radio buttons cannot be reset
                mainListItems.SubItems.Add(universityYearT.Text);
                mainListItems.SubItems.Add(phoneNumT.Text);

                //add the line to the listView
                currentRow[0] = mainListItems;

                //copy each modified subitem back into both lists at the same place
                for (int count = 0; count < currentRow[0].SubItems.Count; count++)
                {
                    // MessageBox.Show(listCopy.SelectedItems[0].SubItems[count] + "");
                    listCopy.SelectedItems[0].SubItems[count].Text = currentRow[0].SubItems[count].Text;
                    // MessageBox.Show(listCopy.SelectedItems[0].SubItems[count] + "");
                }

                //assign fullcopy it's value
                fullCopy.Items[fullCopyPos] = (ListViewItem)currentRow[0].Clone();

                resetVariables();

                this.Hide();
            }
            else
            {
                MessageBox.Show("Error: no text entered");
            }
        }

        public void loadValues(List<ListViewItem> lastSelectedRow)
        {
            /* PURPOSE:
             * loads all values into thier respective fields. Then find
             * which item will be modified in fullCopy, and store it in
             * dataModified.
             * */

            currentRow = lastSelectedRow;//soft copy

            //get data from the first row only
            firstNameT.Text = currentRow[0].SubItems[0].Text;
            lastNameT.Text = currentRow[0].SubItems[1].Text;
            ageT.Text = currentRow[0].SubItems[2].Text;

            //need to check which button to click
            if (currentRow[0].SubItems[3].Text.Equals("Female"))
            {
                femaleRadio.PerformClick();
                radioClicked = "Female";
            }
            else if (currentRow[0].SubItems[3].Text.Equals("Male"))
            {
                maleRadio.PerformClick();
                radioClicked = "Male";
            }
            else //error handling
            {
                MessageBox.Show("Error: gender should be in the form \"Male\" or \"Female\".");
                this.Hide();//user must try again
            }

            universityYearT.Text = currentRow[0].SubItems[4].Text;
            phoneNumT.Text = currentRow[0].SubItems[5].Text;
 
            //now get the position being modified in fullCopy
            for (int count = 0; count < fullCopy.Items.Count; count++)
            {
                if (fullCopy.Items[count].Text.Equals(firstNameT.Text))
                {
                    fullCopyPos = count;

                    MessageBox.Show("Success: " + fullCopy.Items[fullCopyPos].Text);
                }
            }
        }

    }
}
