﻿namespace ContactList
{
    partial class mainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.tabs = new System.Windows.Forms.TabControl();
            this.contacts = new System.Windows.Forms.TabPage();
            this.ageNumsT = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.ageTrackBar = new System.Windows.Forms.TrackBar();
            this.listContacts = new System.Windows.Forms.ListView();
            this.listFirstN = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listLastN = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listAge = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listGender = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listUniversityY = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listPhoneNum = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.deleteButton = new System.Windows.Forms.Button();
            this.editButton = new System.Windows.Forms.Button();
            this.newButton = new System.Windows.Forms.Button();
            this.graph = new System.Windows.Forms.TabPage();
            this.dataList = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.menuStrip1.SuspendLayout();
            this.tabs.SuspendLayout();
            this.contacts.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ageTrackBar)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(607, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loadToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // loadToolStripMenuItem
            // 
            this.loadToolStripMenuItem.Name = "loadToolStripMenuItem";
            this.loadToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.loadToolStripMenuItem.Text = "Load";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // tabs
            // 
            this.tabs.Controls.Add(this.contacts);
            this.tabs.Controls.Add(this.graph);
            this.tabs.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabs.Location = new System.Drawing.Point(12, 27);
            this.tabs.Name = "tabs";
            this.tabs.SelectedIndex = 0;
            this.tabs.Size = new System.Drawing.Size(585, 387);
            this.tabs.TabIndex = 1;
            // 
            // contacts
            // 
            this.contacts.Controls.Add(this.dataList);
            this.contacts.Controls.Add(this.ageNumsT);
            this.contacts.Controls.Add(this.textBox1);
            this.contacts.Controls.Add(this.ageTrackBar);
            this.contacts.Controls.Add(this.listContacts);
            this.contacts.Controls.Add(this.deleteButton);
            this.contacts.Controls.Add(this.editButton);
            this.contacts.Controls.Add(this.newButton);
            this.contacts.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.contacts.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contacts.Location = new System.Drawing.Point(4, 27);
            this.contacts.Name = "contacts";
            this.contacts.Padding = new System.Windows.Forms.Padding(3);
            this.contacts.Size = new System.Drawing.Size(577, 356);
            this.contacts.TabIndex = 0;
            this.contacts.Text = "Contacts";
            this.contacts.UseVisualStyleBackColor = true;
            // 
            // ageNumsT
            // 
            this.ageNumsT.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ageNumsT.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.ageNumsT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ageNumsT.Location = new System.Drawing.Point(66, 104);
            this.ageNumsT.Name = "ageNumsT";
            this.ageNumsT.ReadOnly = true;
            this.ageNumsT.Size = new System.Drawing.Size(446, 15);
            this.ageNumsT.TabIndex = 6;
            this.ageNumsT.Text = "0        10        20        30        40        50        60        70        80" +
                "        90";
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(241, 51);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(100, 17);
            this.textBox1.TabIndex = 5;
            this.textBox1.Text = "Age";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ageTrackBar
            // 
            this.ageTrackBar.LargeChange = 1;
            this.ageTrackBar.Location = new System.Drawing.Point(52, 74);
            this.ageTrackBar.Maximum = 9;
            this.ageTrackBar.Name = "ageTrackBar";
            this.ageTrackBar.Size = new System.Drawing.Size(460, 45);
            this.ageTrackBar.TabIndex = 4;
            // 
            // listContacts
            // 
            this.listContacts.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.listFirstN,
            this.listLastN,
            this.listAge,
            this.listGender,
            this.listUniversityY,
            this.listPhoneNum});
            this.listContacts.FullRowSelect = true;
            this.listContacts.Location = new System.Drawing.Point(24, 149);
            this.listContacts.Name = "listContacts";
            this.listContacts.Size = new System.Drawing.Size(528, 190);
            this.listContacts.TabIndex = 3;
            this.listContacts.UseCompatibleStateImageBehavior = false;
            this.listContacts.View = System.Windows.Forms.View.Details;
            // 
            // listFirstN
            // 
            this.listFirstN.Text = "First Name";
            this.listFirstN.Width = 87;
            // 
            // listLastN
            // 
            this.listLastN.Text = "Last Name";
            this.listLastN.Width = 81;
            // 
            // listAge
            // 
            this.listAge.Text = "Age";
            this.listAge.Width = 48;
            // 
            // listGender
            // 
            this.listGender.Text = "Gender";
            this.listGender.Width = 77;
            // 
            // listUniversityY
            // 
            this.listUniversityY.Text = "University Year";
            this.listUniversityY.Width = 127;
            // 
            // listPhoneNum
            // 
            this.listPhoneNum.Text = "Phone Number";
            this.listPhoneNum.Width = 104;
            // 
            // deleteButton
            // 
            this.deleteButton.Location = new System.Drawing.Point(162, 6);
            this.deleteButton.Name = "deleteButton";
            this.deleteButton.Size = new System.Drawing.Size(72, 30);
            this.deleteButton.TabIndex = 2;
            this.deleteButton.Text = "Delete";
            this.deleteButton.UseVisualStyleBackColor = true;
            // 
            // editButton
            // 
            this.editButton.Location = new System.Drawing.Point(84, 6);
            this.editButton.Name = "editButton";
            this.editButton.Size = new System.Drawing.Size(72, 30);
            this.editButton.TabIndex = 1;
            this.editButton.Text = "Edit";
            this.editButton.UseVisualStyleBackColor = true;
            // 
            // newButton
            // 
            this.newButton.Location = new System.Drawing.Point(6, 6);
            this.newButton.Name = "newButton";
            this.newButton.Size = new System.Drawing.Size(72, 30);
            this.newButton.TabIndex = 0;
            this.newButton.Text = "New";
            this.newButton.UseVisualStyleBackColor = true;
            // 
            // graph
            // 
            this.graph.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.graph.Location = new System.Drawing.Point(4, 27);
            this.graph.Name = "graph";
            this.graph.Padding = new System.Windows.Forms.Padding(3);
            this.graph.Size = new System.Drawing.Size(576, 356);
            this.graph.TabIndex = 1;
            this.graph.Text = "Graph";
            this.graph.UseVisualStyleBackColor = true;
            // 
            // dataList
            // 
            this.dataList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6});
            this.dataList.FullRowSelect = true;
            this.dataList.Location = new System.Drawing.Point(659, 149);
            this.dataList.Name = "dataList";
            this.dataList.Size = new System.Drawing.Size(528, 190);
            this.dataList.TabIndex = 7;
            this.dataList.UseCompatibleStateImageBehavior = false;
            this.dataList.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "First Name";
            this.columnHeader1.Width = 87;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Last Name";
            this.columnHeader2.Width = 81;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Age";
            this.columnHeader3.Width = 48;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Gender";
            this.columnHeader4.Width = 77;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "University Year";
            this.columnHeader5.Width = 127;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Phone Number";
            this.columnHeader6.Width = 104;
            // 
            // mainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(607, 480);
            this.Controls.Add(this.tabs);
            this.Controls.Add(this.menuStrip1);
            this.DoubleBuffered = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "mainForm";
            this.Text = "Contact List";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tabs.ResumeLayout(false);
            this.contacts.ResumeLayout(false);
            this.contacts.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ageTrackBar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.TabControl tabs;
        private System.Windows.Forms.TabPage contacts;
        private System.Windows.Forms.TabPage graph;
        private System.Windows.Forms.Button deleteButton;
        private System.Windows.Forms.Button editButton;
        private System.Windows.Forms.Button newButton;
        private System.Windows.Forms.ListView listContacts;
        private System.Windows.Forms.ColumnHeader listFirstN;
        private System.Windows.Forms.ColumnHeader listLastN;
        private System.Windows.Forms.ColumnHeader listAge;
        private System.Windows.Forms.ColumnHeader listGender;
        private System.Windows.Forms.ColumnHeader listUniversityY;
        private System.Windows.Forms.ColumnHeader listPhoneNum;
        private System.Windows.Forms.TrackBar ageTrackBar;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox ageNumsT;
        private System.Windows.Forms.ListView dataList;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
    }
}

