﻿namespace ContactList
{
    partial class Entry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.firstNameT = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lastNameT = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.ageT = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.phoneNum = new System.Windows.Forms.TextBox();
            this.phoneNumT = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.maleRadio = new System.Windows.Forms.RadioButton();
            this.femaleRadio = new System.Windows.Forms.RadioButton();
            this.cancelButton = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            this.universityYearT = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // firstNameT
            // 
            this.firstNameT.Location = new System.Drawing.Point(125, 15);
            this.firstNameT.Margin = new System.Windows.Forms.Padding(4);
            this.firstNameT.Name = "firstNameT";
            this.firstNameT.Size = new System.Drawing.Size(203, 22);
            this.firstNameT.TabIndex = 0;
            // 
            // textBox2
            // 
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(13, 15);
            this.textBox2.Margin = new System.Windows.Forms.Padding(4);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(104, 14);
            this.textBox2.TabIndex = 1;
            this.textBox2.Text = "First Name";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(13, 50);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(104, 14);
            this.textBox1.TabIndex = 3;
            this.textBox1.Text = "Last Name";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lastNameT
            // 
            this.lastNameT.Location = new System.Drawing.Point(125, 50);
            this.lastNameT.Margin = new System.Windows.Forms.Padding(4);
            this.lastNameT.Name = "lastNameT";
            this.lastNameT.Size = new System.Drawing.Size(203, 22);
            this.lastNameT.TabIndex = 2;
            // 
            // textBox4
            // 
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox4.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.textBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(13, 86);
            this.textBox4.Margin = new System.Windows.Forms.Padding(4);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(104, 14);
            this.textBox4.TabIndex = 5;
            this.textBox4.Text = "Age";
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ageT
            // 
            this.ageT.Location = new System.Drawing.Point(125, 86);
            this.ageT.Margin = new System.Windows.Forms.Padding(4);
            this.ageT.Name = "ageT";
            this.ageT.Size = new System.Drawing.Size(203, 22);
            this.ageT.TabIndex = 4;
            // 
            // textBox6
            // 
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox6.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.textBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox6.Location = new System.Drawing.Point(13, 162);
            this.textBox6.Margin = new System.Windows.Forms.Padding(4);
            this.textBox6.Name = "textBox6";
            this.textBox6.ReadOnly = true;
            this.textBox6.Size = new System.Drawing.Size(104, 14);
            this.textBox6.TabIndex = 7;
            this.textBox6.Text = "University Year";
            this.textBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // phoneNum
            // 
            this.phoneNum.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.phoneNum.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.phoneNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phoneNum.Location = new System.Drawing.Point(13, 201);
            this.phoneNum.Margin = new System.Windows.Forms.Padding(4);
            this.phoneNum.Name = "phoneNum";
            this.phoneNum.ReadOnly = true;
            this.phoneNum.Size = new System.Drawing.Size(104, 14);
            this.phoneNum.TabIndex = 9;
            this.phoneNum.Text = "Phone Number";
            this.phoneNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // phoneNumT
            // 
            this.phoneNumT.Location = new System.Drawing.Point(125, 201);
            this.phoneNumT.Margin = new System.Windows.Forms.Padding(4);
            this.phoneNumT.Name = "phoneNumT";
            this.phoneNumT.Size = new System.Drawing.Size(203, 22);
            this.phoneNumT.TabIndex = 8;
            // 
            // textBox3
            // 
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox3.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(13, 126);
            this.textBox3.Margin = new System.Windows.Forms.Padding(4);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(104, 14);
            this.textBox3.TabIndex = 10;
            this.textBox3.Text = "Gender";
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // maleRadio
            // 
            this.maleRadio.AutoSize = true;
            this.maleRadio.Location = new System.Drawing.Point(138, 124);
            this.maleRadio.Name = "maleRadio";
            this.maleRadio.Size = new System.Drawing.Size(56, 20);
            this.maleRadio.TabIndex = 11;
            this.maleRadio.TabStop = true;
            this.maleRadio.Text = "Male";
            this.maleRadio.UseVisualStyleBackColor = true;
            // 
            // femaleRadio
            // 
            this.femaleRadio.AutoSize = true;
            this.femaleRadio.Location = new System.Drawing.Point(200, 124);
            this.femaleRadio.Name = "femaleRadio";
            this.femaleRadio.Size = new System.Drawing.Size(72, 20);
            this.femaleRadio.TabIndex = 12;
            this.femaleRadio.TabStop = true;
            this.femaleRadio.Text = "Female";
            this.femaleRadio.UseVisualStyleBackColor = true;
            // 
            // cancelButton
            // 
            this.cancelButton.Location = new System.Drawing.Point(274, 237);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(73, 23);
            this.cancelButton.TabIndex = 14;
            this.cancelButton.Text = "Cancel";
            this.cancelButton.UseVisualStyleBackColor = true;
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(195, 237);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(73, 23);
            this.saveButton.TabIndex = 15;
            this.saveButton.Text = "Save";
            this.saveButton.UseVisualStyleBackColor = true;
            // 
            // universityYearT
            // 
            this.universityYearT.FormattingEnabled = true;
            this.universityYearT.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "Master\'s",
            "Ph.D."});
            this.universityYearT.Location = new System.Drawing.Point(125, 159);
            this.universityYearT.Name = "universityYearT";
            this.universityYearT.Size = new System.Drawing.Size(203, 24);
            this.universityYearT.TabIndex = 16;
            // 
            // Entry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(359, 272);
            this.Controls.Add(this.universityYearT);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.femaleRadio);
            this.Controls.Add(this.maleRadio);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.phoneNum);
            this.Controls.Add(this.phoneNumT);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.ageT);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lastNameT);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.firstNameT);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Entry";
            this.Text = "EntryBase";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        protected System.Windows.Forms.TextBox firstNameT;
        protected System.Windows.Forms.TextBox textBox2;
        protected System.Windows.Forms.TextBox textBox1;
        protected System.Windows.Forms.TextBox lastNameT;
        protected System.Windows.Forms.TextBox textBox4;
        protected System.Windows.Forms.TextBox ageT;
        protected System.Windows.Forms.TextBox textBox6;
        protected System.Windows.Forms.TextBox phoneNum;
        protected System.Windows.Forms.TextBox phoneNumT;
        protected System.Windows.Forms.TextBox textBox3;
        protected System.Windows.Forms.RadioButton maleRadio;
        protected System.Windows.Forms.RadioButton femaleRadio;
        protected System.Windows.Forms.Button cancelButton;
        protected System.Windows.Forms.Button saveButton;
        protected System.Windows.Forms.ComboBox universityYearT;
    }
}