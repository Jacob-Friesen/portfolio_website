﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ContactList
{
    public abstract partial class Entry : Form
    {
        protected ListView listCopy;
        protected ListView fullCopy;
        protected String radioClicked;

        //for inheritance
        public Entry()
        {
            InitializeComponent();
        }

        public Entry(ListView listCopy)
        {
            InitializeComponent();

            this.listCopy = listCopy;

            initButtons();
        }

        public void initButtons()
        {
            saveButton.Click += new EventHandler(clickedSaved);
            cancelButton.Click += new EventHandler(clickedCancel);

            maleRadio.Click += new EventHandler(maleClicked);
            femaleRadio.Click += new EventHandler(femaleClicked);
        }

        /* Menu events*/
        virtual public void clickedSaved(object sender, EventArgs e)
        {
        }

        public void clickedCancel(object sender, EventArgs e)
        {
            resetVariables();

            //close the form the safe way
            this.Hide();
        }

        public void femaleClicked(object sender, EventArgs e)
        {
            radioClicked = femaleRadio.Text;
        }

        public void maleClicked(object sender, EventArgs e)
        {
            radioClicked = maleRadio.Text;
        }

        public void resetVariables()
        {
            firstNameT.Text = "";//so thier blanck with next new click
            lastNameT.Text = "";
            ageT.Text = "";
            radioClicked = "";
            universityYearT.Text = "";
            phoneNumT.Text = "";

            femaleRadio.Checked = false;
            maleRadio.Checked = false;
        }
    }
}